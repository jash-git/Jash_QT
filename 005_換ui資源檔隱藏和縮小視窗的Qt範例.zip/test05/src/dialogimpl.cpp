#include "dialogimpl.h"
//
DialogImpl::DialogImpl( QWidget * parent, Qt::WFlags f) 
	: QWidget(parent, f)
{
	setupUi(this);
	PushButton00=pushButton;
}
void DialogImpl::slotclick()
{
	//this->setWindowTitle("test");
	//this->hide();
	this->setWindowState(Qt::WindowMinimized);
}
//
