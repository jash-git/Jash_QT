#ifndef DIALOGIMPL_H
#define DIALOGIMPL_H
//
#include <QWidget>
//#include <QDialog>
//#include "ui_dialog.h"
#include "ui_form.h"
//
class DialogImpl : public QWidget, public Ui::Form
{
Q_OBJECT
public:
	DialogImpl( QWidget * parent = 0, Qt::WFlags f = 0 );
public:
	QPushButton *PushButton00;
private slots:
	void slotclick();
};
#endif




