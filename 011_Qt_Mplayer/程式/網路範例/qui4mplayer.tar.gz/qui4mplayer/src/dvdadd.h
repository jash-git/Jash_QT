/****************************************************************************
** Form interface generated from reading ui file 'dvdadd.ui'
**
** Created: Thu Oct 26 21:23:34 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef DVDADD_H
#define DVDADD_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QPushButton;
class QSpinBox;
class QLabel;

class DVDAdd : public QDialog
{
    Q_OBJECT

public:
    DVDAdd( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~DVDAdd();

    QPushButton* AddDVDButton;
    QPushButton* AddVCDButton;
    QPushButton* CloseButton;
    QSpinBox* TrackBox;
    QLabel* TrackLabel;

    virtual void init();
    virtual void destroy();

public slots:
    virtual void AddDVDButton_clicked();
    virtual void AddVCDButton_clicked();
    virtual void CloseButton_clicked();

signals:
    void AddDVDClicked( int track );
    void AddVCDClicked( int track );

protected:
    QGridLayout* DVDAddLayout;
    QSpacerItem* spacer1;
    QSpacerItem* spacer2;
    QVBoxLayout* layout8;
    QHBoxLayout* layout7;

protected slots:
    virtual void languageChange();

};

#endif // DVDADD_H
