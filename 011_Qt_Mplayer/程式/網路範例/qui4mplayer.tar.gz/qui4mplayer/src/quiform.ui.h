// ***************************************************************************************
// This file copyright 2003 Ben Nemec, distributed under the terms of the GPL, see COPYING
// ***************************************************************************************

/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/
#include <iostream>
#include <stdlib.h>
#include <sstream>
#include <qtimer.h>
#include <qfiledialog.h>
#include <qapplication.h>
#include <qfileinfo.h>
#include <qfile.h>
#include <qdir.h>
#include <qtextstream.h>
#include <qpalette.h>
#include <qpixmap.h>
#include <qiconset.h>
#include <qtabwidget.h>
#include <qlineedit.h>
#include <qradiobutton.h>
#include <qtable.h>
#include <qmessagebox.h>
#include <qspinbox.h>
#include <qcheckbox.h>
#include <qcombobox.h>
#include <qbitmap.h>

#include "PlayFile.h"
#include "PlayList.h"
#include "pldialog.h"
#include "options.h"

#define DOCKID 0

using namespace std;

QTimer *postimer;
QTimer *fstimer;
PlayFile *p;
bool istimer, docked, sliderclicked;
bool timeractive, havefstype;  // timeractive will probably never be used
bool firstshow;
PlayList *pl;
OptionsForm *of;
PLDialog *playld;
QString currentversion;
int currtime;
bool wasfullscreen;
char looprandcol[12];  // A vicious, vicious hack I admit
QPoint clickpos;

bool stopenabled; // Can't use a toggle button because of button images, so
bool fsenabled;   // we keep track of enabled state separately

// Pixmaps for buttons
QPixmap *previmage;
QPixmap *prevclickedimage;
QPixmap *playimage;
QPixmap *playclickedimage;
QPixmap *pauseimage;
QPixmap *pauseclickedimage;
QPixmap *stopimage;
QPixmap *stopclickedimage;
QPixmap *nextimage;
QPixmap *nextclickedimage;
QPixmap *loopimage;
QPixmap *loopclickedimage;
QPixmap *randimage;
QPixmap *randclickedimage;
QPixmap *plimage;
QPixmap *plclickedimage;
QPixmap *fsimage;
QPixmap *fsclickedimage;
QPixmap *optsimage;
QPixmap *optsclickedimage;

struct options
{
   QString defaultdir;
   QString loop;
   QString random;
   QString docked;
   QStringList mparams;
   QColor basecol;
   QColor bgcol;
   QColor fgcol;
   QString debug;
   QString pshown;
   QString usemain;
   QString ao;
   QString vo;
   QString deinterlacer;
   QString stopxs;
   QString notify;
   int notsize;
   int notdelay;
};
options opt;

void quiForm::init()
{
   postimer = new QTimer();
   connect(postimer, SIGNAL(timeout()), this, SLOT(timerDone()));
   fstimer = new QTimer();
   connect(fstimer, SIGNAL(timeout()), this, SLOT(fsGrab()));
   istimer = timeractive = havefstype = false;         // Set some bool variables
   firstshow = true;
   
   p = new PlayFile();  // setup dummy PlayFile object
   of = new OptionsForm();
   currentversion = "1.7b4";  // Current version of defaults.conf, not QUI
   setMouseTracking(true);
   
   // Hmm, do I like the no borders or not...
   playld = new PLDialog(this, 0, false, Qt::WStyle_Customize | Qt::WStyle_NoBorder);
   pl = new PlayList(playld);
   
   // These could have all been connected directly to the playld, but at one point I had
   // thoughts of releasing the playlist and playfile classes standalone, so I wanted all
   // manipulation of the playlist dialog to go on through that.  I no longer intend to do
   // that, so new slots are connected directly.
   connect(pl, SIGNAL(DialogDoubleClicked(int)), this, SLOT(PlayFileNum(int)));
   connect(pl, SIGNAL(NewPlaylistSelected()), this, SLOT(NextButton_clicked()));
   connect(pl, SIGNAL(NewList()), this, SLOT(StopButton_clicked()));
   connect(pl, SIGNAL(RaiseQUI()), this, SLOT(PLClicked()));
   connect(playld, SIGNAL(DockedItemClicked(bool)), this, SLOT(DockedCheck_toggled(bool)));
   
   /* Remove all existing overlaid images in case the background and/or the buttons
   were changed.  This lets us know that we should re-overlay each image as it is
   needed, but prevents us from having to do it every time */
   QDir clean(QDir::homeDirPath() + "/.qui/OverlaidButtons");
   QStringList files = clean.entryList();
   while (!files.isEmpty())
   {
      QFile(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + files.first()).remove();
      files.pop_front();
   }
   
   getDefaults();
   
   pl->Hide();  // Has to be after getDefaults or it will get shown again
   
   stopEnabled(false);  // Also must be after getDefaults or will segfault
   fsEnabled(true);
   
   if (qApp->argc() > 1)
   {
      QFileInfo getabs;
      for (int i = 1; i < qApp->argc(); i++)
      {
         getabs = QFileInfo(qApp->argv()[i]);
         getabs.convertToAbs();
         if (getabs.extension(false).lower() == "m3u")
            pl->Open(getabs.filePath());
         else if (QString(qApp->argv()[i]).find("://") != -1)  // Is a URL, don't mess with it
            pl->Add(qApp->argv()[i]);
         else
            pl->Add(getabs.filePath());
      }
      newPlayFile(pl->GetNextFile());
   }

   // Create ~/.qui/Playlists directory if necessary
   // Assumes if .qui is present then so is Playlists.  PlayList class checks
   // for .qui/Playlists, so this is okay.
   QDir d(QDir::homeDirPath() + "/.qui/");
   if (!d.exists())
   {
      QDir d1(QDir::homeDirPath());
      d1.mkdir(".qui");
      QDir d2(QDir::homeDirPath() + "/.qui");
      d2.mkdir("Playlists");
   }
   
   // Get current volume setting
   QProcess test;
   test.clearArguments();
   test.addArgument("aumix");
   QString s;
   if (opt.usemain == "true")
      s = "-vq";
   else
      s = "-wq";
   test.addArgument(s);
   if (!test.start())   // No aumix:-(
   {
      slider3->setValue(0);  // Slider is upside down, so this is inverted
      cout << "Aumix not found, using MPlayer volume control\n" << flush;
   }
   else 
   {
      // Could conceivably cause a hang, might have to change, so far not a problem
      while (!test.canReadLineStdout() && test.isRunning()); 
      if (test.canReadLineStdout())
      {
         QString buffer = test.readLineStdout();
         buffer = buffer.right(buffer.length() - 4);
         buffer = buffer.left(buffer.find(','));
         slider3->setValue(100 - buffer.toInt());
      }
      else
      {
         cout << "Something went wrong getting the current volume from aumix.\n" << flush;
         slider3->setValue(0);
      }
   }
}


// Don't think this function is useful anymore
void quiForm::showEvent(QShowEvent *se)
{
   se->spontaneous();
}


// Nothing really needs to be done here because this doesn't really do what you'd think it should
// Use the closeEvent slot instead
void quiForm::destroy()
{

}


void quiForm::PlayButton_clicked()
{
   cout << "Play: " << PlayButton->x() << "  " << PlayButton->y() << endl;
   cout << "Stop: " << StopButton->x() << "  " << StopButton->y() << endl;
   cout << "Next: " << NextButton->x() << "  " << NextButton->y() << endl;
   cout << "Prev: " << PrevButton->x() << "  " << PrevButton->y() << endl;
   cout << "FS: " << FullScreenButton->x() << "  " << FullScreenButton->y() << endl;
   cout << "Loop: " << LoopButton->x() << "  " << LoopButton->y() << endl;
   cout << "Rand: " << RandomButton->x() << "  " << RandomButton->y() << endl;
   cout << "PL: " << PLButton->x() << "  " << PLButton->y() << endl;
   cout << "Opts: " << OptionsButton->x() << "  " << OptionsButton->y() << endl;
   cout << width() << "   " << height() << endl;
   if (!pl->isEmpty())
   {
      if (p->isDummy())
      {
         newPlayFile(pl->GetNextFile());
      }
      else if (p->Filename() != "")
      {
         p->Play();
         if (p->isPlaying()) postimer->start(1000);
         else postimer->stop();
         if (p->isPlaying())
         {
            PlayButton->setText("Pause");
            setImage(3, "Pause.png");
            stopEnabled(true);
         }
         else
         {
            PlayButton->setText("Play");
            setImage(3, "Play.png");
            stopEnabled(false);
         }
      }
      else
      {
         if (pl->isRandom())
            NextButton_clicked();
         else
         {
            QString temp;
            temp = pl->GetCurrFile();
            p->OpenFile(temp);
            if (temp == "")
            {
               PlayButton->setText("Play");
               setImage(3, "Play.png");
               stopEnabled(false);
               postimer->stop();
               clearData();
            }
            TimeSlider->setValue(0);
         }
         p->Play();
         if (p->Filename() != "")
         {
            if (p->isPlaying())
            {
               PlayButton->setText("Pause");
               setImage(3, "Pause.png");
               stopEnabled(true);
            }
         }
      }
   }
}


/* It makes things simpler if we disable this button when not playing, but due to
   the way that skins are handled, we can't just disable the button or bad things
   will happen.  So we keep track of the enabled state of the button independently.
   */
void quiForm::StopButton_clicked()
{
   if (stopenabled)
   {
      if (!p->isDummy())
      {
         //p->Stop();
         p->OpenFile("");   // This will do the p->Stop() above
      }
      else  // In case we were called because MPlayer exited
      {
         if (hasMouse())
            releaseMouse();
      }
      stopEnabled(false);
      postimer->stop();
      TimeSlider->setValue(0);
      if (!p->isPlaying())  // Not sure what the point of this was, but it's not hurting anything
      {
         PlayButton->setText("Play");
         setImage(3, "Play.png");
      }
      clearData();
   }
}

QString quiForm::IntToString(int i)
{
   ostringstream s;
   s << i << flush;
   return QString(s.str().c_str());
}

void quiForm::timerDone()
{
   QString temp;
   istimer = true;
    
   if (p->length() != -1) //TimeSlider->value() <= TimeSlider->maxValue() && p->length() != -1)
   {
      if (TimeSlider->value() == TimeSlider->maxValue())
         TimeSlider->setMaxValue(TimeSlider->maxValue() + 1);
         
      TimeSlider->setValue(TimeSlider->value() + 1);
      TimeLabel->setText(FormattedTime(TimeSlider->value()) + "/" + FormattedTime(p->length()));
   }
}

// Actually gets all the file info, originally only got the time
void quiForm::getLength()
{
   if (p->isPlaying())
      postimer->start(1000);
      
   TimeSlider->setMaxValue(p->length());
   
   // Try to make the time slider move an approximately equal distance when it is clicked
   // on, regardless of the length of the file.
   float pagestep = (float)p->length() / (float)TimeSlider->width();
   pagestep *= 10;
   if (pagestep < 1) pagestep = 1;
   int ps = (int)pagestep;
   TimeSlider->setPageStep(ps);
   QString temptime1 = FormattedTime(0);
   QString temptime2 = FormattedTime(p->length());
   TimeLabel->setText(temptime1 + "/" + temptime2);
   pl->SetCurrentTime(temptime2);
   
   QString temp = p->Title();
   if (temp.stripWhiteSpace() != "" && temp != "$!" && temp != " ")
   {
      TitleLabel->setText(temp.simplifyWhiteSpace());
      pl->SetCurrentName(temp.simplifyWhiteSpace());
   }
   else
   {
      QFileInfo fi(p->Filename());
      cout << p->Filename() << endl << flush;
      if (p->Filename().find("://") == -1)
         TitleLabel->setText(fi.baseName(true));
      else TitleLabel->setText(p->Filename());
   }
   
   temp = p->Artist();
   if (temp.stripWhiteSpace() != "" && temp != "$!" && temp != " ")
      ArtistLabel->setText(temp.simplifyWhiteSpace());
   else ArtistLabel->setText("N/A");
   
   temp = p->Album();
   if (temp != "" && temp != "$!" && temp != " ")
      AlbumLabel->setText(temp.simplifyWhiteSpace());
   else AlbumLabel->setText("N/A");
   BitrateLabel->setText(IntToString(p->bitrate()) + " kbps");
   
   // While files are loading, clicking fullscreen results in some nasty race conditions (apparently)
   // so to be safe we just disabled it completely.  Re-enable it here because now we know that
   // the file has been loaded properly and fullscreen toggling will work safely again.
   fsEnabled(true);
   if (wasfullscreen)
      FullscreenToggle();
   
   // Display popup notification if desired
   if (opt.notify != "false")
   {
      QDialog *popup = new QDialog(this, "New File", false, 
                                   Qt::WStyle_Customize | Qt::WStyle_NoBorder | Qt::WDestructiveClose);
      popup->move(0, 0);
      popup->setBackgroundColor(colorGroup().background());
      QLabel *l = new QLabel("Currently playing: " + p->Artist() + " - " + p->Title(), popup);
      l->setFont(QFont("Arial", opt.notsize));
      l->setBackgroundColor(colorGroup().background());
      l->adjustSize();
      QTimer::singleShot(opt.notdelay * 1000, popup, SLOT(close()));
      popup->show();
   }
}
 
void quiForm::TimeSlider_sliderPressed()
{
   sliderclicked = true;
   postimer->stop();
   if (TimeSlider->value() > p->length())
   {
      p->setNotime(true);  // Kludgy, but the safest, easiest way to do it for now
      TimeSlider->setMaxValue(100);
   }
}


void quiForm::TimeSlider_sliderReleased()
{
   sliderclicked = false;
   if (p->isPlaying())
      postimer->start(1000);
   p->Seek(TimeSlider->value());
}


void quiForm::TimeSlider_valueChanged( int newpos )
{
 if (!p->isDummy())
 {
    if (!istimer && !sliderclicked)  // for click on slider bar rather than slider itself
      {
         if (TimeSlider->value() > p->length())
         {
            TimeSlider->setMaxValue(100);
            TimeSlider->setValue(0);
            newpos = 0;
         }
         p->Seek(newpos);
      }
      else if (p->length() != -1)  // prevent the goofy looking 0:00/0:0-1 time between files
         TimeLabel->setText(FormattedTime(TimeSlider->value()) + "/" + FormattedTime(p->length()));
   }
 istimer = false;
}


void quiForm::closeEvent(QCloseEvent * ce)
{
   delete p;
   pl->CloseEditor();

   saveOpts();
   ce->accept();
}


void quiForm::focusInEvent(QFocusEvent *fe)
{
   if (firstshow)
   {
      pl->Show();
      firstshow = false;
      // Dock the thing to begin with just so we don't get random behavior on start
      QRect geo = frameGeometry();
      pl->SetPos(geo.right(), geo.y() + geo.height());
   }
   // Was here for debugging
   //cout << QCursor::pos().x() << "   " << QCursor::pos().y() << "   " 
   //      << x() << "    " << y() << endl << flush;
   int mousex = QCursor::pos().x();
   int mousey = QCursor::pos().y();
   if (mousex > x() - 1 && (mousex < x() + width() + 1))
   {
      if (mousey > y() - 1 && (mousey < y() + height() + 1))
      {
         if (!fe->spontaneous() && docked)
            // If we do this when it is not docked, it resets it back to its 
            // initial position, making it essentially impossible to move
            pl->Show();
      }
   }
}


void quiForm::moveEvent(QMoveEvent *me)
{
   me->spontaneous();
   QRect geo = frameGeometry();
   if (docked)
      pl->SetPos(geo.right(), geo.y() + geo.height());
}


void quiForm::resizeEvent(QResizeEvent *re)
{
   re->spontaneous();
   QRect geo = frameGeometry();
   if (docked)
      pl->SetPos(geo.right(), geo.y() + geo.height());
}



void quiForm::mouseDoubleClickEvent( QMouseEvent *me )
{
   me->spontaneous();
   if (!p->isDummy() && p->isFullscreen())
      FullscreenToggle();
}


void quiForm::mouseMoveEvent( QMouseEvent * me )
{
   if (!p->isDummy() && p->isFullscreen())
   {
      raise();
      pl->Show();
      if (havefstype)
         releaseMouse();
      if (!pl->DialogIsActive())
         setActiveWindow();
   }
   
   
   if (me->state() & Qt::LeftButton)
      move(me->globalPos() - clickpos);
}


void quiForm::mousePressEvent( QMouseEvent *e )
{
   clickpos = e->pos();
}


void quiForm::PLClicked()
{
   if (isShown())
      raise();
   if (!p->isDummy() && p->isFullscreen())
   {
      //timeractive = false;
      releaseMouse();
   }
}



// Slightly different from above because it doesn't want to grab the mouse unless QUI is hidden
void quiForm::fsGrab()
{
   // I guess these are left from debugging
   //cout << "Trying to grab mouse\n" << flush;
   //cout << isActiveWindow() << pl->DialogIsActive() << of->isActiveWindow() << pl->isAdding() << endl << flush;
   if (!isActiveWindow() && !pl->DialogIsActive() && !of->isActiveWindow() && !pl->isAdding())
   {
      releaseMouse(); // Will be called repeatedly, don't want to get AlreadyGrabbed errors
      grabMouse(Qt::BlankCursor);
   }
}


/* It makes things simpler if we disable this button when loading new files, but due to
   the way that skins are handled, we can't just disable the button or bad things
   will happen.  So we keep track of the enabled state of the button independently.
   */
void quiForm::FullScreenButton_clicked()
{
   if (!p->isDummy() && p->isVideo() && fsenabled)
   {
      FullscreenToggle();
   }
}


void quiForm::FullscreenToggle()
{
   p->ToggleFullscreen();
   if (!p->isFullscreen())
   {
      releaseMouse();
      fstimer->stop();
   }
   else
   {
      raise();
      fstimer->start(200);
   }
}


void quiForm::NextButton_clicked()
{
   QString temp;
   if (!p->isDummy() && !pl->isEmpty())
   {
      SaveFSState();
      temp = pl->GetNextFile();
      p->OpenFile(temp);
      stopEnabled(true);
      PlayButton->setText("Pause");
      setImage(3, "Pause.png");
      if (temp == "")
      {
         PlayButton->setText("Play");
         setImage(3, "Play.png");
         stopEnabled(false);
         postimer->stop();
         clearData();
      }
      TimeSlider->setValue(0);
   }
}


void quiForm::PrevButton_clicked()
{
   if (!pl->isRandom())
   {
      QString temp;
      if (!p->isDummy() && !pl->isEmpty())
      {
         SaveFSState();
         temp = pl->GetPrevFile();
         p->OpenFile(temp);
         stopEnabled(true);
         PlayButton->setText("Pause");
         setImage(3, "Pause.png");
         if (temp == "")
         {
            PlayButton->setText("Play");
            setImage(3, "Play.png");
            stopEnabled(false);
            postimer->stop();
            clearData();
         }
         else 
         {
            TimeSlider->setValue(0);
         }
      }
   }
}


// Called before loading a new file so we know whether to put the new on into fullscreen
void quiForm::SaveFSState()
{
   wasfullscreen = false;
   fsEnabled(false);  // See comment in getLength
   if (p->isFullscreen())
   {
      wasfullscreen = true;
      FullscreenToggle();
   }
}


void quiForm::LoopButton_toggled( bool onoff )
{
   pl->SetLoop(onoff);
   if (onoff)
   {
      LoopButton->setPaletteBackgroundColor(opt.bgcol);
      setImage(6, "LoopClicked.png");
   }
   else 
   {
      LoopButton->setPaletteBackgroundColor(opt.basecol);
      setImage(6, "Loop.png");
   }
}


void quiForm::RandomButton_toggled( bool onoff )
{
   pl->SetRandom(onoff);
   if (onoff)
   {
      RandomButton->setPaletteBackgroundColor(opt.bgcol);
      setImage(7, "RandomClicked.png");
   }
   else 
   {
      RandomButton->setPaletteBackgroundColor(opt.basecol);
      setImage(7, "Random.png");
   }
}


void quiForm::DockedCheck_toggled( bool checked )
{
   docked = checked;
   if (docked)
   {
      QRect geo = frameGeometry();
      pl->SetPos(geo.right(), geo.y() + geo.height());
   }
}


void quiForm::PLButton_toggled( bool onoff )
{
   pl->SetShown(onoff);
   if (onoff)
   {
      QRect geo = frameGeometry();
      if (docked)
         pl->SetPos(geo.right(), geo.y() + geo.height());
      pl->Show();
      PLButton->setPaletteBackgroundColor(opt.bgcol);
      PLButton->setPaletteForegroundColor(opt.fgcol);
      setImage(8, "PlaylistClicked.png");
   }
   else
   {
      pl->Hide();
      PLButton->setPaletteBackgroundColor(opt.basecol);
      PLButton->setPaletteForegroundColor(opt.fgcol);
      setImage(8, "Playlist.png");
   }
}


// Plays a file double clicked in the playlist
void quiForm::PlayFileNum( int row )
{
   QString temp = pl->GetFileAt(row);
   if (temp != "")
   {
      stopEnabled(true);
      PlayButton->setText("Pause");
      setImage(3, "Pause.png");
      TimeSlider->setValue(0);
      if (p->isDummy())
      {
         newPlayFile(temp);
      }
      else 
      {
         SaveFSState();
         releaseMouse();
         p->OpenFile(temp);
         /* Probably unnecessary now
         if (!p->isPlaying())
            p->Play();*/
      }
   }
}


QString quiForm::FormattedTime( int t )
{
   int thours = t / 3600;
   int tmin = (t - (thours * 3600)) / 60;
   int tsecs = t - (thours * 3600) - (tmin * 60);
      QString ret = "";
      if (thours > 0)
         ret = IntToString(thours) + ":";
      if (thours > 0 && tmin < 10) ret += "0";
   ret += IntToString(tmin) + ":";
   if (tsecs < 10) ret += "0";
   ret += IntToString(tsecs);
   return ret;
}


// This is the volume slider, remember that it's upside down
void quiForm::slider3_valueChanged( int newval )
{
   p->SetVolume(100 - newval);
}


void quiForm::clearData()
{
   TimeSlider->setMaxValue(0);
   TimeLabel->setText(FormattedTime(0) + "/" + FormattedTime(0));
   TitleLabel->setText("");
   AlbumLabel->setText("");
   ArtistLabel->setText("");
   BitrateLabel->setText("");
}


void quiForm::fileError()
{
   StopButton_clicked();
   QMessageBox nofile("Error: File Failed to Play!", "MPlayer was unable to play the current file.\
   Usually this means that\n the file does not exist or is in a format MPlayer does not support", 
   QMessageBox::Critical, QMessageBox::Ok, QMessageBox::NoButton, QMessageBox::NoButton);
   nofile.exec();
   StopButton_clicked();
}


void quiForm::gotoNextFile()
{
   // Check if we are supposed to be playing to handle a race condition
   // that occurs when the previous file failed to play.
   if (p->isPlaying())
   {
      SaveFSState();
      releaseMouse();
      QString temp = pl->GetNextFile();
      p->OpenFile(temp);
      if (!p->isPlaying())
      {
         PlayButton->setText("Play");
         setImage(3, "Play.png");
         postimer->stop();
      }
      TimeSlider->setValue(0);
   }
}



// Hopefully this will raise the playlist dialog whenever the main window is clicked, not just when
// it gains focus.  Every once in a while the playlist ends up under a video window somehow, hence this function
void quiForm::mouseReleaseEvent( QMouseEvent *e )
{
   e->spontaneous();
   playld->raise();
}


// Need to add some more keys later
// Volume, seeking, etc.
void quiForm::keyPressEvent( QKeyEvent *e )
{
   if (e->key() == Qt::Key_Space)
      PlayButton_clicked();
   else if (e->key() == Qt::Key_Escape)
      qApp->quit();
   else if (e->key() == Qt::Key_Q)
      qApp->quit();
   else if (e->key() == Qt::Key_Left)
      TimeSlider->setValue(TimeSlider->value() - TimeSlider->pageStep());
   else if (e->key() == Qt::Key_Right)
      TimeSlider->setValue(TimeSlider->value() + TimeSlider->pageStep());
   else if (e->key() == Qt::Key_Minus)
      slider3->setValue(slider3->value() + 3);  // Remember, volume slider is inverted
   else if (e->key() == Qt::Key_Equal)
      slider3->setValue(slider3->value() - 3);
   else if (e->key() == Qt::Key_F)
   {
      FullScreenButton_clicked();
      raise(); // For some reason we don't get raised, but are still the active window???
   }
   else if (e->key() == Qt::Key_Backspace)
      PrevButton_clicked();
   else if (e->key() == Qt::Key_Return)
      NextButton_clicked();
   else
      e->ignore();
}


// Creates a new PlayFile object with filename as the new file.
void quiForm::newPlayFile( QString filename )
{
   PlayFile *t = new PlayFile(filename, opt.mparams, opt.ao, opt.vo, opt.stopxs, opt.deinterlacer);
   delete p;
   p = t;
   if (p->isDummy())
   {
      QMessageBox nomplayer("Error: MPlayer Not Found!", "MPlayer failed to start properly.  Check that it is installed and its location is listed in your PATH variable.  QUI will now exit.", QMessageBox::Critical, QMessageBox::Ok, QMessageBox::NoButton,
      QMessageBox::NoButton);
      nomplayer.exec();
      qApp->quit();
   }
   connect(p, SIGNAL(haveFileLength()), this, SLOT(getLength()));
   connect(p, SIGNAL(mplayerExited()), this, SLOT(StopButton_clicked()));
   connect(p, SIGNAL(fileFinished()), this, SLOT(gotoNextFile()));
   connect(p, SIGNAL(fileFailed()), this, SLOT(fileError()));
   PlayButton->setText("Pause");
   setImage(3, "Pause.png");
   stopEnabled(true);
   setPOpts();
}


void quiForm::stopEnabled( bool state )
{
   stopenabled = state;
   if (state)
      setImage(4, "Stop.png");
   else setImage(4, "StopClicked.png");
}


void quiForm::fsEnabled( bool state )
{
   fsenabled = state;
   if (state)
      setImage(9, "Fullscreen.png");
   else setImage(9, "FullscreenClicked.png");
}


// Get default options from defaults.conf, or create a new generic one
void quiForm::getDefaults()
{
   QString dummy;
   // set up configuration options - probably could get its own function
   QFile opts(QDir::homeDirPath() + "/.qui/defaults.conf");
   if (!opts.exists())  // Create basic defaults.conf
   {
      opts.open(IO_WriteOnly);
      QTextStream writeopts(&opts);
      writeopts << currentversion << endl;
      writeopts << "Media Directory:\n";
      writeopts << "/\n";
      writeopts << "Loop:\n";
      writeopts << "false\n";
      writeopts << "Random:\n";
      writeopts << "false\n";
      writeopts << "Playlist Docked:\n";
      writeopts << "true\n";
      writeopts << "Debug Mode:\n";
      writeopts << "false\n";
      writeopts << "Stop XScreensaver:\n";
      writeopts << "true\n";
      writeopts << "Playlist Shown:\n";
      writeopts << "false\n";
      writeopts << "Use Main Volume:\n";
      writeopts << "false\n";
      writeopts << "Audio Out:\n";
      writeopts << "default\n";
      writeopts << "Video Out:\n";
      writeopts << "default\n";
      writeopts << "Deinterlace:\n";
      writeopts << "fd\n";
      writeopts << "New File Notification:\n";
      writeopts << "false\n";
      writeopts << "Notification Font Size:\n";
      writeopts << "12\n";
      writeopts << "Notification Delay:\n";
      writeopts << "5\n";
      writeopts << "Background Color:\n";
      writeopts << "0\n";
      writeopts << "0\n";
      writeopts << "0\n";
      writeopts << "Base Color:\n";
      writeopts << "128\n";
      writeopts << "128\n";
      writeopts << "128\n";
      writeopts << "Foreground Color:\n";
      writeopts << "255\n";
      writeopts << "255\n";
      writeopts << "255\n";
      writeopts << "MPLAYER OPTIONS\n";
      writeopts << "-fstype\n";
      writeopts << "layer,none,fullscreen\n";
      writeopts << "END OPTIONS\n";
      opts.close();
   }
   opts.open(IO_ReadOnly);
   QTextStream getopts(&opts);
   // Check for old config file
   dummy = getopts.readLine();
   if (dummy != currentversion)
   {
      cout << "Renaming old options file...\n";
      QMessageBox::information(this, 
                               "Options file out of date", 
                               "Your options file is not compatible with this version of QUI.\n"
                               "It is being renamed to ~/.qui/defaults.old and all options have\n"
                               "been reset to their defaults.");
      opts.close();
      QDir movefile = QDir(QDir::homeDirPath() + "/.qui");
      movefile.rename("defaults.conf", "defaults.old");
      getDefaults();
   }
   else
   {
      // Read default location for av files
      dummy = getopts.readLine();
      opt.defaultdir = getopts.readLine();
      pl->defaultdir = opt.defaultdir;
      of->pathEdit->setText(opt.defaultdir);
            
      // Read default loop and random settings
      dummy = getopts.readLine();
      opt.loop = getopts.readLine();
      
      // Random
      dummy = getopts.readLine();
      opt.random = getopts.readLine();
            
      // Dock the playlist?
      dummy = getopts.readLine();
      opt.docked = getopts.readLine();
      // Menu item must start out false all the time, including after Options window
      playld->setDocked(false);
      if (opt.docked != "false")
      {
         //docked = true;  // Should be unnecessary - next function emits a signal that does it.
         playld->DockedItem_checked();  // Defaults to false, so this works.
      }
      
      // Debug mode on?
      dummy = getopts.readLine();
      opt.debug = getopts.readLine();
      if (opt.debug != "false")
         of->DebugCheck->setChecked(true);
      
      // Disable XScreensaver?
      dummy = getopts.readLine();
      opt.stopxs = getopts.readLine();
      if (opt.stopxs != "false")
         of->StopXSCheck->setChecked(true);
            
      // Show the playlist on startup?
      dummy = getopts.readLine();
      opt.pshown = getopts.readLine(); // Action taken based on this had to be moved to after setSkin call
      
      // Use the main or pcm volume?
      dummy = getopts.readLine();
      opt.usemain = getopts.readLine();
      if (opt.usemain == "false")
         of->UsePCMVol->setChecked(true);
      else of->UseMainVol->setChecked(true);
      
      // AO setting to use?
      dummy = getopts.readLine();
      opt.ao = getopts.readLine();
      of->Setstoreao(opt.ao);
      
      // VO setting to use?
      dummy = getopts.readLine();
      opt.vo = getopts.readLine();
      of->Setstorevo(opt.vo);
      
      // Deinterlacer?
      dummy = getopts.readLine();
      opt.deinterlacer = getopts.readLine();
      of->Setdeint(opt.deinterlacer);
      
      setPOpts();
      
      // Notification font size
      dummy = getopts.readLine();
      opt.notify = getopts.readLine();
      if (opt.notify != "false")
         of->Notify->setChecked(true);
      
      // Notification font size
      dummy = getopts.readLine();
      opt.notsize = getopts.readLine().toInt();
      of->NotFontSize->setValue(opt.notsize);
      
      // Notification delay
      dummy = getopts.readLine();
      opt.notdelay = getopts.readLine().toInt();
      of->NotDelay->setValue(opt.notdelay);
      
      // Get color scheme info
      dummy = getopts.readLine();      // Should be "Background Color"
      int r = getopts.readLine().toInt();
      int g = getopts.readLine().toInt();
      int b = getopts.readLine().toInt();
      opt.bgcol = QColor(r, g, b);
      of->BackR->setValue(r);
      of->BackG->setValue(g);
      of->BackB->setValue(b);
      dummy = getopts.readLine();
      r = getopts.readLine().toInt();
      g = getopts.readLine().toInt();
      b = getopts.readLine().toInt();
      opt.basecol = QColor(r, g, b);
      of->BaseR->setValue(r);
      of->BaseG->setValue(g);
      of->BaseB->setValue(b);
      dummy = getopts.readLine();
      r = getopts.readLine().toInt();
      g = getopts.readLine().toInt();
      b = getopts.readLine().toInt();
      opt.fgcol = QColor(r, g, b);
      of->ForeR->setValue(r);
      of->ForeG->setValue(g);
      of->ForeB->setValue(b);
      // Read additional MPlayer parameters
      opt.mparams.clear();
      dummy = getopts.readLine();    // Should be MPLAYER OPTIONS
      while (dummy != "END OPTIONS")
      {
         dummy = getopts.readLine();
         if (dummy == "-fstype")
            havefstype = true;
         opt.mparams.append(dummy);
      }
      QStringList temp = opt.mparams;
      temp.remove("END OPTIONS");
      of->MPOpts->setText(temp.join(" "));
      
      
      opts.close();
      setSkin();
      
      // Has to be here so the colors have been loaded
      PLButton->setOn(false);
      if (opt.pshown != "false")
      {
         PLButton_toggled(true);  // Don't mess with this again, moron
         PLButton->setOn(true);
      }
      
      // These too, stupid
      pl->SetLoop(false);
      LoopButton->setOn(false);  // Leave the color alone anyway
      if (opt.loop != "false")
      {
         LoopButton->setOn(true);
         LoopButton_toggled(true);

      }
      
      pl->SetRandom(false);
      RandomButton->setOn(false);
      if (opt.random != "false")
      {
         RandomButton->setOn(true);
         RandomButton_toggled(true);
      }
   }
}


void quiForm::setSkin()
{
   // Set colors
   QColorGroup cg;
   cg.setColor(QColorGroup::Background, opt.bgcol);
   cg.setColor(QColorGroup::Text, opt.fgcol);
   cg.setColor(QColorGroup::Button, opt.basecol);
   cg.setColor(QColorGroup::Base, opt.bgcol);
   cg.setColor(QColorGroup::Highlight, opt.fgcol);
   cg.setColor(QColorGroup::HighlightedText, opt.bgcol);
   cg.setColor(QColorGroup::ButtonText, opt.fgcol);
   cg.setColor(QColorGroup::Foreground, opt.fgcol);
   
   int mr = (opt.bgcol.red() + opt.fgcol.red()) / 2;
   int mg = (opt.bgcol.green() + opt.fgcol.green()) / 2;
   int mb = (opt.bgcol.blue() + opt.fgcol.blue()) / 2;
   cg.setColor(QColorGroup::Mid, QColor(mr, mg, mb));
   mr = (opt.bgcol.red() + opt.fgcol.red() + opt.fgcol.red()) / 3;
   mg = (opt.bgcol.green() + opt.fgcol.green() + opt.fgcol.green()) / 3;
   mb = (opt.bgcol.blue() + opt.fgcol.blue() + opt.fgcol.blue()) / 3;
   cg.setColor(QColorGroup::Midlight, QColor(mr, mg, mb));
   mr = (opt.bgcol.red() + opt.bgcol.red() + opt.fgcol.red()) / 3;
   mg = (opt.bgcol.green() + opt.bgcol.green() + opt.fgcol.green()) / 3;
   mb = (opt.bgcol.blue() + opt.bgcol.blue() + opt.fgcol.blue()) / 3;
   cg.setColor(QColorGroup::Dark, QColor(mr, mg, mb));
   cg.setColor(QColorGroup::Light, opt.fgcol);
   
   QPalette palette(cg, cg, cg);
   pl->pal = palette;
   pl->SetPal();
   setPalette(palette);
   PlayButton->setPalette(palette);
   StopButton->setPalette(palette);
   PrevButton->setPalette(palette);
   NextButton->setPalette(palette);
   PLButton->setPalette(palette);
   FullScreenButton->setPalette(palette);
   LoopButton->setPalette(palette);
   RandomButton->setPalette(palette);
   OptionsButton->setPalette(palette);
   TimeSlider->setPalette(palette);
   slider3->setPalette(palette);  // Volume slider, some moron forgot to rename it ;-)
   TitleLabel->setPalette(palette);
   TimeLabel->setPalette(palette);
   ArtistLabel->setPalette(palette);
   AlbumLabel->setPalette(palette);
   BitrateLabel->setPalette(palette);
   
   setImage(2, "Previous.png");
   if (p->isDummy() || !p->isPlaying())
      setImage(3, "Play.png");
   else setImage(3, "Pause.png");
   // Must be done here or stopEnabled could segfault
   setImage(4, "StopClicked.png");
   setImage(4, "Stop.png");
   setImage(5, "Next.png");
   setImage(6, "Loop.png");
   setImage(7, "Random.png");
   setImage(8, "Playlist.png");
   // Ditto.
   setImage(9, "FullscreenClicked.png");
   setImage(9, "Fullscreen.png");
   // Remember that Background.png is now hard coded as the image to composite with
   // for all of the buttons in SetImage
   setImage(10, "Background.png");
   setImage(11, "Options.png");
   setImage(12, "Slider.png");
   setImage(13, "Slider.png");
}


// Keep in mind, this only works for options that can be changed while QUI is running
void quiForm::setPOpts()
{
   if (opt.debug != "false")
      p->setDebug(true);
   else
   {
      p->setDebug(false);
   }
   
   if (opt.usemain != "false")
      p->setMainVol(true);
   else
   {
      p->setMainVol(false);
   }
}


// Sets the image on the appropriate button, as well as compositing the button image
// and the background image using ImageMagick
void quiForm::setImage( int i, QString filename )
{
   if (QFile(QDir::homeDirPath() + "/.qui/Buttons/" + filename).exists())
   {
      if (!QDir(QDir::homeDirPath() + "/.qui/OverlaidButtons/").exists())
      {
         QDir d(QDir::homeDirPath() + "/.qui");
         d.mkdir("OverlaidButtons");
      }
      
      QIconSet ics;
      QString cmd = "";
      // Only used for background now
      QPixmap pix(QDir::homeDirPath() + "/.qui/Buttons/" + filename);
      QFile currfile(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
            
      switch (i)  // 0 and 1 were removed because they were no longer necessary
      {
         case 2:
            if (!currfile.exists())
            {
               // Note: Can't use the same variable twice in one line
               QString con, con1;
               QString area = con.setNum(PrevButton->width()) + "x" + con1.setNum(PrevButton->height()) + "+";
               area += con.setNum(PrevButton->x()) + "+" + con1.setNum(PrevButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  previmage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  prevclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
            
            if (!filename.contains("Clicked"))
            {
               ics.reset(*previmage, QIconSet::Small);
            }
            else
            {
               ics.reset(*prevclickedimage, QIconSet::Small);
            }
            
            PrevButton->setIconSet(ics);
            PrevButton->setText("");
            break;
         case 3:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(PlayButton->width()) + "x" + con1.setNum(PlayButton->height()) + "+";
               area += con.setNum(PlayButton->x()) + "+" + con1.setNum(PlayButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  if (filename.contains("Play"))
                     playimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
                  else pauseimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  if (filename.contains("Play"))
                     playclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
                  else pauseclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
            
            if (!filename.contains("Clicked"))
            {
               if (filename.contains("Play"))
                  ics.reset(*playimage, QIconSet::Small);
               else ics.reset(*pauseimage, QIconSet::Small);
            }
            else
            {
               if (filename.contains("Play"))
                  ics.reset(*playclickedimage, QIconSet::Small);
               else ics.reset(*pauseclickedimage, QIconSet::Small);
            }
            
            PlayButton->setIconSet(ics);
            PlayButton->setText("");
            break;
         case 4:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(StopButton->width()) + "x" + con1.setNum(StopButton->height()) + "+";
               area += con.setNum(StopButton->x()) + "+" + con1.setNum(StopButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  stopimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  stopclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
                  
            if (!filename.contains("Clicked") && stopenabled)
            {
               ics.reset(*stopimage, QIconSet::Small);
            }
            else
            {
               ics.reset(*stopclickedimage, QIconSet::Small);
            }
            
            StopButton->setIconSet(ics);
            StopButton->setText("");
            break;
         case 5:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(NextButton->width()) + "x" + con1.setNum(NextButton->height()) + "+";
               area += con.setNum(NextButton->x()) + "+" + con1.setNum(NextButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  nextimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  nextclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
                  
            if (!filename.contains("Clicked"))
            {
               ics.reset(*nextimage, QIconSet::Small);
            }
            else
            {
               ics.reset(*nextclickedimage, QIconSet::Small);
            }
            
            NextButton->setIconSet(ics);
            NextButton->setText("");
            break;
         case 6:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(LoopButton->width()) + "x" + con1.setNum(LoopButton->height()) + "+";
               area += con.setNum(LoopButton->x()) + "+" + con1.setNum(LoopButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  loopimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  loopclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
                  
            if (!filename.contains("Clicked"))
            {
               ics.reset(*loopimage, QIconSet::Small);
            }
            else
            {
               ics.reset(*loopclickedimage, QIconSet::Small);
            }
            
            LoopButton->setIconSet(ics);
            LoopButton->setText("");
            break;
         case 7:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(RandomButton->width()) + "x" + con1.setNum(RandomButton->height()) + "+";
               area += con.setNum(RandomButton->x()) + "+" + con1.setNum(RandomButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  randimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  randclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
                  
            if (!filename.contains("Clicked"))
            {
               ics.reset(*randimage, QIconSet::Small);
            }
            else
            {
               ics.reset(*randclickedimage, QIconSet::Small);
            }
            
            RandomButton->setIconSet(ics);
            RandomButton->setText("");
            break;
         case 8:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(PLButton->width()) + "x" + con1.setNum(PLButton->height()) + "+";
               area += con.setNum(PLButton->x()) + "+" + con1.setNum(PLButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  plimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  plclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
                  
            if (!filename.contains("Clicked"))
            {
               ics.reset(*plimage, QIconSet::Small);
            }
            else
            {
               ics.reset(*plclickedimage, QIconSet::Small);
            }
            
            PLButton->setIconSet(ics);
            PLButton->setText("");
            break;
         case 9:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(FullScreenButton->width()) + "x" + con1.setNum(FullScreenButton->height()) + "+";
               area += con.setNum(FullScreenButton->x()) + "+" + con1.setNum(FullScreenButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  fsimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  fsclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
                  
            if (!filename.contains("Clicked") && fsenabled)
            {
               ics.reset(*fsimage, QIconSet::Small);
            }
            else
            {
               ics.reset(*fsclickedimage, QIconSet::Small);
            }
            
            FullScreenButton->setIconSet(ics);
            FullScreenButton->setText("");
            break;
         case 10:
            setPaletteBackgroundPixmap(pix);
            PrevButton->setAutoMask(true);
            // Need to override default theme so that pixmaps show up correctly regardless
            PrevButton->setStyle("MotifPlus");
            PlayButton->setAutoMask(true);
            PlayButton->setStyle("MotifPlus");
            StopButton->setAutoMask(true);
            StopButton->setStyle("MotifPlus");
            NextButton->setAutoMask(true);
            NextButton->setStyle("MotifPlus");
            LoopButton->setAutoMask(true);
            LoopButton->setStyle("MotifPlus");
            RandomButton->setAutoMask(true);
            RandomButton->setStyle("MotifPlus");
            PLButton->setAutoMask(true);
            PLButton->setStyle("MotifPlus");
            FullScreenButton->setAutoMask(true);
            FullScreenButton->setStyle("MotifPlus");
            OptionsButton->setAutoMask(true);
            OptionsButton->setStyle("MotifPlus");
            // Evidently these are not needed and don't work anyway
            //slider3->setAutoMask(true);
            //TimeSlider->setAutoMask(true);
            break;
         case 11:
            if (!currfile.exists())
            {
               QString con, con1;
               QString area = con.setNum(OptionsButton->width()) + "x" + con1.setNum(OptionsButton->height()) + "+";
               area += con.setNum(OptionsButton->x()) + "+" + con1.setNum(OptionsButton->y());
               cmd = "convert ~/.qui/Buttons/Background.png -crop " + area + " +repage ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               cmd = "convert ~/.qui/OverlaidButtons/" + filename + " ~/.qui/Buttons/" + filename + " -composite ~/.qui/OverlaidButtons/" + filename;
               system(cmd.ascii());
               if (!filename.contains("Clicked"))
               {
                  optsimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
               else
               {
                  optsclickedimage = new QPixmap(QDir::homeDirPath() + "/.qui/OverlaidButtons/" + filename);
               }
            }
                  
            if (!filename.contains("Clicked"))
            {
               ics.reset(*optsimage, QIconSet::Small);
            }
            else
            {
               ics.reset(*optsclickedimage, QIconSet::Small);
            }
            
            OptionsButton->setIconSet(ics);
            OptionsButton->setText("");
            break;
         case 12:
            // This doesn't work as expected, but it does at least make the widget blend nicely with
            // the background of the parent window
            TimeSlider->setPaletteBackgroundPixmap(QPixmap(QDir::homeDirPath() + "/.qui/Buttons/" + filename));
            //TimeSlider->setErasePixmap(pix);
            break;
         case 13:
            slider3->setPaletteBackgroundPixmap(QPixmap(QDir::homeDirPath() + "/.qui/Buttons/" + filename));
            //slider3->setErasePixmap(pix);
            break;
      }
   }
}

/*
   QString defaultdir;
   QString loop;
   QString random;
   QString docked;
   QString mparams[100];
   QColor basecol;
   QColor bgcol;
   QColor fgcol;
   QString debug;
   QString pshown;
   QString usemain;
   */
void quiForm::OptionsButton_clicked()
{
   of->exec();
   if (of->accepted())
   {
      opt.defaultdir = of->pathEdit->text();
      opt.bgcol = QColor(of->BackR->value(), of->BackG->value(), of->BackB->value());
      opt.basecol = QColor(of->BaseR->value(), of->BaseG->value(), of->BaseB->value());
      opt.fgcol = QColor(of->ForeR->value(), of->ForeG->value(), of->ForeB->value());
      opt.debug = "false";
      p->setDebug(false);
      if (of->DebugCheck->isChecked())
      {
         opt.debug = "true";
         p->setDebug(true);
      }
      opt.stopxs = "true";
      if (!of->StopXSCheck->isChecked())
          opt.stopxs = "false";
      
      opt.mparams.clear();
      opt.mparams = QStringList::split(" ", of->MPOpts->text());
      opt.mparams.append(QString("END OPTIONS"));
      if (of->UsePCMVol->isChecked())
         opt.usemain = "false";
      else opt.usemain = "true";
      
      opt.ao = of->AOCombo->currentText();
      opt.vo = of->VOCombo->currentText();
      opt.deinterlacer = "none";
      if (of->DeintEnabled->isChecked())
      {
         if (of->FDRadio->isChecked())
            opt.deinterlacer = "fd";
         else if (of->CIRadio->isChecked())
            opt.deinterlacer = "ci";
         else if (of->LIRadio->isChecked())
            opt.deinterlacer = "li";
         else
            opt.deinterlacer = "lb";
      }
      opt.notify = "false";
      if (of->Notify->isChecked())
         opt.notify = "true";
      opt.notsize = of->NotFontSize->value();
      opt.notdelay = of->NotDelay->value();
      
      saveOpts();
   }
   getDefaults();
}


void quiForm::saveOpts()
{
   opt.loop = "false";
   opt.random = "false";
   opt.docked = "false";
   opt.pshown = "false";
   if (pl->isLoop())
      opt.loop = "true";
   if (pl->isRandom())
      opt.random = "true";
   if (docked)
      opt.docked = "true";
   if (pl->Shown())
      opt.pshown = "true";
   QFile opts(QDir::homeDirPath() + "/.qui/defaults.conf");  // Save current options
   opts.open(IO_WriteOnly);
   QTextStream writeopts(&opts);
   writeopts << currentversion << endl;
   writeopts << "Media Directory:\n";
   writeopts << opt.defaultdir << endl;
   writeopts << "Loop:\n";
   writeopts << opt.loop << endl;
   writeopts << "Random:\n";
   writeopts << opt.random << endl;
   writeopts << "Playlist Docked:\n";
   writeopts << opt.docked << endl;
   writeopts << "Debug:\n";
   writeopts << opt.debug << endl;
   writeopts << "Stop XScreensaver:\n";
   writeopts << opt.stopxs << endl;
   writeopts << "Playlist Shown:\n";
   writeopts << opt.pshown << endl;
   writeopts << "Use Main Volume:\n";
   writeopts << opt.usemain << endl;
   writeopts << "Audio Out:\n";
   writeopts << opt.ao << endl;
   writeopts << "Video Out:\n";
   writeopts << opt.vo << endl;
   writeopts << "Deinterlace:\n";
   writeopts << opt.deinterlacer << endl;
   writeopts << "New File Notification:\n";
   writeopts << opt.notify << endl;
   writeopts << "Notification Font Size:\n";
   writeopts << opt.notsize << endl;
   writeopts << "Notification Delay:\n";
   writeopts << opt.notdelay << endl;
   writeopts << "Background Color:\n";
   writeopts << opt.bgcol.red() << endl;
   writeopts << opt.bgcol.green() << endl;
   writeopts << opt.bgcol.blue() << endl;
   writeopts << "Base Color:\n";
   writeopts << opt.basecol.red() << endl;
   writeopts << opt.basecol.green() << endl;
   writeopts << opt.basecol.blue() << endl;
   writeopts << "Foreground Color:\n";
   writeopts << opt.fgcol.red() << endl;
   writeopts << opt.fgcol.green() << endl;
   writeopts << opt.fgcol.blue() << endl;
   writeopts << "MPLAYER OPTIONS\n";
   int i = 0;
   while (opt.mparams[i] != "END OPTIONS")
   {
      writeopts << opt.mparams[i] << endl;
      i++;
   }
   writeopts << "END OPTIONS\n";
   opts.close();
}


/* The following functions handle updating the button images when a button
   is clicked.  The *Button_clicked() handler still does the actual functions
   */

void quiForm::PlayButton_pressed()
{
   if (!p->isPlaying() || p->isDummy())
      setImage(3, "PlayClicked.png");
   else setImage(3, "PauseClicked.png");
}


// This only needs to handle the case where the button is clicked before the playlist
// has been populated.  Otherwise the clicked() handler takes care of it.
void quiForm::PlayButton_released()
{
   if (p->isDummy())
      setImage(3, "Play.png");
}


void quiForm::StopButton_pressed()
{
   setImage(4, "StopClicked.png");
}


void quiForm::StopButton_released()
{
   setImage(4, "Stop.png");
}


void quiForm::NextButton_released()
{
   setImage(5, "Next.png");
}


void quiForm::NextButton_pressed()
{
   setImage(5, "NextClicked.png");
}


void quiForm::PrevButton_released()
{
   setImage(2, "Previous.png");
}


void quiForm::PrevButton_pressed()
{
   setImage(2, "PreviousClicked.png");
}


void quiForm::FullScreenButton_released()
{
   setImage(9, "Fullscreen.png");
}


void quiForm::FullScreenButton_pressed()
{
   setImage(9, "FullscreenClicked.png");
}


void quiForm::OptionsButton_released()
{
   setImage(11, "Options.png");
}


void quiForm::OptionsButton_pressed()
{
   setImage(11, "OptionsClicked.png");
}
