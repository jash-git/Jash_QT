/****************************************************************************
** Form interface generated from reading ui file 'fileinfo.ui'
**
** Created: Thu Oct 26 20:49:30 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FILEINFO_H
#define FILEINFO_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QPushButton;

class FileInfo : public QDialog
{
    Q_OBJECT

public:
    FileInfo( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FileInfo();

    QLabel* FilenameLabel;
    QLineEdit* ArtistText;
    QLineEdit* AlbumText;
    QPushButton* OKButton;
    QPushButton* CancelButton;
    QLineEdit* TitleText;
    QLabel* TitleLabel;
    QLabel* ArtistLabel;
    QLabel* AlbumLabel;

public slots:
    virtual void setFields( QString fn, QString title, QString artist, QString album );
    virtual void OKButton_clicked();
    virtual void CancelButton_clicked();
    virtual QString GetTitle();
    virtual QString GetArtist();
    virtual QString GetAlbum();

protected:
    QGridLayout* FileInfoLayout;
    QSpacerItem* spacer1;

protected slots:
    virtual void languageChange();

private:
    virtual void init();
    virtual void destroy();

};

#endif // FILEINFO_H
