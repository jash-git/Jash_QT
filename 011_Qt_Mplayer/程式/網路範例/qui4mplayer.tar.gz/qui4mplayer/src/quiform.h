/****************************************************************************
** Form interface generated from reading ui file 'quiform.ui'
**
** Created: Thu Oct 26 22:33:45 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef QUIFORM_H
#define QUIFORM_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QSlider;
class QPushButton;
class QLabel;

class quiForm : public QDialog
{
    Q_OBJECT

public:
    quiForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~quiForm();

    QSlider* slider3;
    QPushButton* RandomButton;
    QSlider* TimeSlider;
    QLabel* TitleLabel;
    QLabel* TimeLabel;
    QLabel* ArtistLabel;
    QLabel* AlbumLabel;
    QLabel* BitrateLabel;
    QPushButton* NextButton;
    QPushButton* PrevButton;
    QPushButton* FullScreenButton;
    QPushButton* LoopButton;
    QPushButton* PLButton;
    QPushButton* OptionsButton;
    QPushButton* StopButton;
    QPushButton* PlayButton;

    virtual QString IntToString( int i );
    virtual QString FormattedTime( int t );
    virtual void clearData();
    virtual void newPlayFile( QString filename );
    virtual void getDefaults();

public slots:
    virtual void showEvent( QShowEvent * se );
    virtual void PlayButton_clicked();
    virtual void StopButton_clicked();
    virtual void timerDone();
    virtual void getLength();
    virtual void TimeSlider_sliderPressed();
    virtual void TimeSlider_sliderReleased();
    virtual void TimeSlider_valueChanged( int newpos );
    virtual void closeEvent( QCloseEvent * ce );
    virtual void focusInEvent( QFocusEvent * fe );
    virtual void moveEvent( QMoveEvent * me );
    virtual void resizeEvent( QResizeEvent * re );
    virtual void mouseDoubleClickEvent( QMouseEvent * me );
    virtual void mouseMoveEvent( QMouseEvent * me );
    virtual void PLClicked();
    virtual void fsGrab();
    virtual void FullScreenButton_clicked();
    virtual void FullscreenToggle();
    virtual void NextButton_clicked();
    virtual void PrevButton_clicked();
    virtual void SaveFSState();
    virtual void LoopButton_toggled( bool onoff );
    virtual void RandomButton_toggled( bool onoff );
    virtual void DockedCheck_toggled( bool checked );
    virtual void PLButton_toggled( bool onoff );
    virtual void PlayFileNum( int row );
    virtual void slider3_valueChanged( int newval );
    virtual void fileError();
    virtual void gotoNextFile();
    virtual void mouseReleaseEvent( QMouseEvent * e );
    virtual void setSkin();
    virtual void setPOpts();
    virtual void setImage( int i, QString filename );
    virtual void OptionsButton_clicked();
    virtual void saveOpts();
    virtual void PlayButton_pressed();
    virtual void PlayButton_released();
    virtual void StopButton_pressed();
    virtual void StopButton_released();
    virtual void NextButton_released();
    virtual void NextButton_pressed();
    virtual void PrevButton_released();
    virtual void PrevButton_pressed();
    virtual void FullScreenButton_released();
    virtual void FullScreenButton_pressed();
    virtual void OptionsButton_released();
    virtual void OptionsButton_pressed();

protected:

protected slots:
    virtual void languageChange();

    virtual void mousePressEvent( QMouseEvent * e );
    virtual void keyPressEvent( QKeyEvent * e );
    virtual void stopEnabled( bool state );
    virtual void fsEnabled( bool state );


private:
    void init();
    void destroy();

};

#endif // QUIFORM_H
