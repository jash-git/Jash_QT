/****************************************************************************
** Form implementation generated from reading ui file 'quiform.ui'
**
** Created: Wed Jan 24 19:35:41 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "quiform.h"

#include <qvariant.h>
#include <qslider.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "quiform.ui.h"
/*
 *  Constructs a quiForm as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
quiForm::quiForm( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "quiForm" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 400, 170 ) );
    setMaximumSize( QSize( 400, 170 ) );
    setSizeIncrement( QSize( 0, 0 ) );
    setBaseSize( QSize( 0, 0 ) );
    setPaletteBackgroundColor( QColor( 0, 0, 0 ) );
    setMouseTracking( TRUE );
    setFocusPolicy( QDialog::StrongFocus );
    setModal( FALSE );

    slider3 = new QSlider( this, "slider3" );
    slider3->setGeometry( QRect( 278, 66, 19, 77 ) );
    slider3->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Button, QColor( 168, 168, 168) );
    cg.setColor( QColorGroup::Light, QColor( 252, 252, 252) );
    cg.setColor( QColorGroup::Midlight, QColor( 210, 210, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 84, 84, 84) );
    cg.setColor( QColorGroup::Mid, QColor( 112, 112, 112) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Button, QColor( 168, 168, 168) );
    cg.setColor( QColorGroup::Light, QColor( 252, 252, 252) );
    cg.setColor( QColorGroup::Midlight, QColor( 193, 193, 193) );
    cg.setColor( QColorGroup::Dark, QColor( 84, 84, 84) );
    cg.setColor( QColorGroup::Mid, QColor( 112, 112, 112) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 168, 168, 168) );
    cg.setColor( QColorGroup::Light, QColor( 252, 252, 252) );
    cg.setColor( QColorGroup::Midlight, QColor( 193, 193, 193) );
    cg.setColor( QColorGroup::Dark, QColor( 84, 84, 84) );
    cg.setColor( QColorGroup::Mid, QColor( 112, 112, 112) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    slider3->setPalette( pal );
    slider3->setMinValue( 0 );
    slider3->setMaxValue( 100 );
    slider3->setValue( 0 );
    slider3->setOrientation( QSlider::Vertical );

    RandomButton = new QPushButton( this, "RandomButton" );
    RandomButton->setGeometry( QRect( 303, 112, 30, 30 ) );
    RandomButton->setMinimumSize( QSize( 30, 30 ) );
    RandomButton->setMaximumSize( QSize( 30, 30 ) );
    QFont RandomButton_font(  RandomButton->font() );
    RandomButton->setFont( RandomButton_font ); 
    RandomButton->setToggleButton( TRUE );
    RandomButton->setOn( TRUE );
    RandomButton->setAutoDefault( FALSE );

    TimeSlider = new QSlider( this, "TimeSlider" );
    TimeSlider->setGeometry( QRect( 10, 148, 380, 19 ) );
    TimeSlider->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    TimeSlider->setPaletteBackgroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Button, QColor( 168, 168, 168) );
    cg.setColor( QColorGroup::Light, QColor( 252, 252, 252) );
    cg.setColor( QColorGroup::Midlight, QColor( 210, 210, 210) );
    cg.setColor( QColorGroup::Dark, QColor( 84, 84, 84) );
    cg.setColor( QColorGroup::Mid, QColor( 112, 112, 112) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Button, QColor( 168, 168, 168) );
    cg.setColor( QColorGroup::Light, QColor( 252, 252, 252) );
    cg.setColor( QColorGroup::Midlight, QColor( 193, 193, 193) );
    cg.setColor( QColorGroup::Dark, QColor( 84, 84, 84) );
    cg.setColor( QColorGroup::Mid, QColor( 112, 112, 112) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Button, QColor( 168, 168, 168) );
    cg.setColor( QColorGroup::Light, QColor( 252, 252, 252) );
    cg.setColor( QColorGroup::Midlight, QColor( 193, 193, 193) );
    cg.setColor( QColorGroup::Dark, QColor( 84, 84, 84) );
    cg.setColor( QColorGroup::Mid, QColor( 112, 112, 112) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    TimeSlider->setPalette( pal );
    TimeSlider->setCursor( QCursor( 0 ) );
    TimeSlider->setMaxValue( 0 );
    TimeSlider->setTracking( TRUE );
    TimeSlider->setOrientation( QSlider::Horizontal );

    TitleLabel = new QLabel( this, "TitleLabel" );
    TitleLabel->setGeometry( QRect( 11, 11, 253, 22 ) );
    TitleLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, TitleLabel->sizePolicy().hasHeightForWidth() ) );
    TitleLabel->setMinimumSize( QSize( 1, 0 ) );
    TitleLabel->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    QFont TitleLabel_font(  TitleLabel->font() );
    TitleLabel_font.setBold( TRUE );
    TitleLabel->setFont( TitleLabel_font ); 
    TitleLabel->setFrameShape( QLabel::StyledPanel );
    TitleLabel->setFrameShadow( QLabel::Sunken );
    TitleLabel->setLineWidth( 2 );
    TitleLabel->setAlignment( int( QLabel::AlignCenter ) );

    TimeLabel = new QLabel( this, "TimeLabel" );
    TimeLabel->setGeometry( QRect( 269, 12, 120, 20 ) );
    TimeLabel->setMinimumSize( QSize( 120, 20 ) );
    TimeLabel->setMaximumSize( QSize( 120, 20 ) );
    TimeLabel->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    QFont TimeLabel_font(  TimeLabel->font() );
    TimeLabel_font.setBold( TRUE );
    TimeLabel->setFont( TimeLabel_font ); 
    TimeLabel->setFrameShape( QLabel::StyledPanel );
    TimeLabel->setFrameShadow( QLabel::Sunken );
    TimeLabel->setLineWidth( 2 );
    TimeLabel->setAlignment( int( QLabel::AlignCenter ) );

    ArtistLabel = new QLabel( this, "ArtistLabel" );
    ArtistLabel->setGeometry( QRect( 11, 41, 144, 20 ) );
    ArtistLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, ArtistLabel->sizePolicy().hasHeightForWidth() ) );
    ArtistLabel->setMinimumSize( QSize( 1, 0 ) );
    ArtistLabel->setMaximumSize( QSize( 32767, 20 ) );
    ArtistLabel->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    QFont ArtistLabel_font(  ArtistLabel->font() );
    ArtistLabel_font.setBold( TRUE );
    ArtistLabel->setFont( ArtistLabel_font ); 
    ArtistLabel->setFrameShape( QLabel::StyledPanel );
    ArtistLabel->setFrameShadow( QLabel::Sunken );
    ArtistLabel->setLineWidth( 2 );
    ArtistLabel->setScaledContents( TRUE );
    ArtistLabel->setAlignment( int( QLabel::AlignCenter ) );

    AlbumLabel = new QLabel( this, "AlbumLabel" );
    AlbumLabel->setGeometry( QRect( 160, 41, 144, 20 ) );
    AlbumLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, AlbumLabel->sizePolicy().hasHeightForWidth() ) );
    AlbumLabel->setMinimumSize( QSize( 1, 0 ) );
    AlbumLabel->setMaximumSize( QSize( 32767, 20 ) );
    AlbumLabel->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    QFont AlbumLabel_font(  AlbumLabel->font() );
    AlbumLabel_font.setBold( TRUE );
    AlbumLabel->setFont( AlbumLabel_font ); 
    AlbumLabel->setFrameShape( QLabel::StyledPanel );
    AlbumLabel->setFrameShadow( QLabel::Sunken );
    AlbumLabel->setLineWidth( 2 );
    AlbumLabel->setScaledContents( TRUE );
    AlbumLabel->setAlignment( int( QLabel::AlignCenter ) );

    BitrateLabel = new QLabel( this, "BitrateLabel" );
    BitrateLabel->setGeometry( QRect( 309, 41, 80, 20 ) );
    BitrateLabel->setMinimumSize( QSize( 80, 20 ) );
    BitrateLabel->setMaximumSize( QSize( 80, 20 ) );
    BitrateLabel->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    QFont BitrateLabel_font(  BitrateLabel->font() );
    BitrateLabel_font.setBold( TRUE );
    BitrateLabel->setFont( BitrateLabel_font ); 
    BitrateLabel->setFrameShape( QLabel::StyledPanel );
    BitrateLabel->setFrameShadow( QLabel::Sunken );
    BitrateLabel->setLineWidth( 2 );
    BitrateLabel->setAlignment( int( QLabel::AlignCenter ) );

    NextButton = new QPushButton( this, "NextButton" );
    NextButton->setGeometry( QRect( 231, 86, 40, 40 ) );
    NextButton->setMinimumSize( QSize( 40, 40 ) );
    NextButton->setMaximumSize( QSize( 40, 40 ) );
    NextButton->setAutoDefault( FALSE );

    PrevButton = new QPushButton( this, "PrevButton" );
    PrevButton->setGeometry( QRect( 66, 86, 40, 40 ) );
    PrevButton->setMinimumSize( QSize( 40, 40 ) );
    PrevButton->setMaximumSize( QSize( 40, 40 ) );
    PrevButton->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    PrevButton->setAutoDefault( FALSE );

    FullScreenButton = new QPushButton( this, "FullScreenButton" );
    FullScreenButton->setGeometry( QRect( 31, 91, 30, 30 ) );
    FullScreenButton->setMinimumSize( QSize( 30, 30 ) );
    FullScreenButton->setMaximumSize( QSize( 30, 30 ) );
    FullScreenButton->setPaletteBackgroundColor( QColor( 49, 49, 49 ) );
    FullScreenButton->setAutoDefault( FALSE );

    LoopButton = new QPushButton( this, "LoopButton" );
    LoopButton->setGeometry( QRect( 303, 72, 30, 30 ) );
    LoopButton->setMinimumSize( QSize( 30, 30 ) );
    LoopButton->setMaximumSize( QSize( 30, 30 ) );
    QFont LoopButton_font(  LoopButton->font() );
    LoopButton->setFont( LoopButton_font ); 
    LoopButton->setToggleButton( TRUE );
    LoopButton->setOn( TRUE );
    LoopButton->setAutoDefault( FALSE );

    PLButton = new QPushButton( this, "PLButton" );
    PLButton->setGeometry( QRect( 338, 67, 40, 40 ) );
    PLButton->setMinimumSize( QSize( 40, 40 ) );
    PLButton->setMaximumSize( QSize( 40, 40 ) );
    PLButton->setToggleButton( TRUE );
    PLButton->setAutoDefault( FALSE );
    PLButton->setDefault( FALSE );

    OptionsButton = new QPushButton( this, "OptionsButton" );
    OptionsButton->setGeometry( QRect( 338, 112, 40, 30 ) );
    OptionsButton->setMinimumSize( QSize( 40, 30 ) );
    OptionsButton->setMaximumSize( QSize( 40, 30 ) );
    OptionsButton->setAutoDefault( FALSE );

    StopButton = new QPushButton( this, "StopButton" );
    StopButton->setEnabled( TRUE );
    StopButton->setGeometry( QRect( 186, 86, 40, 40 ) );
    StopButton->setMinimumSize( QSize( 40, 40 ) );
    StopButton->setMaximumSize( QSize( 40, 40 ) );
    StopButton->setAutoDefault( FALSE );

    PlayButton = new QPushButton( this, "PlayButton" );
    PlayButton->setGeometry( QRect( 111, 71, 70, 70 ) );
    PlayButton->setMinimumSize( QSize( 70, 70 ) );
    PlayButton->setMaximumSize( QSize( 70, 70 ) );
    PlayButton->setPaletteBackgroundColor( QColor( 49, 49, 49 ) );
    PlayButton->setBackgroundOrigin( QPushButton::WidgetOrigin );
    PlayButton->setAutoDefault( FALSE );
    PlayButton->setFlat( FALSE );
    languageChange();
    resize( QSize(400, 170).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( PlayButton, SIGNAL( clicked() ), this, SLOT( PlayButton_clicked() ) );
    connect( StopButton, SIGNAL( clicked() ), this, SLOT( StopButton_clicked() ) );
    connect( TimeSlider, SIGNAL( sliderPressed() ), this, SLOT( TimeSlider_sliderPressed() ) );
    connect( TimeSlider, SIGNAL( sliderReleased() ), this, SLOT( TimeSlider_sliderReleased() ) );
    connect( TimeSlider, SIGNAL( valueChanged(int) ), this, SLOT( TimeSlider_valueChanged(int) ) );
    connect( NextButton, SIGNAL( clicked() ), this, SLOT( NextButton_clicked() ) );
    connect( PrevButton, SIGNAL( clicked() ), this, SLOT( PrevButton_clicked() ) );
    connect( PLButton, SIGNAL( toggled(bool) ), this, SLOT( PLButton_toggled(bool) ) );
    connect( slider3, SIGNAL( valueChanged(int) ), this, SLOT( slider3_valueChanged(int) ) );
    connect( FullScreenButton, SIGNAL( clicked() ), this, SLOT( FullScreenButton_clicked() ) );
    connect( OptionsButton, SIGNAL( clicked() ), this, SLOT( OptionsButton_clicked() ) );
    connect( LoopButton, SIGNAL( toggled(bool) ), this, SLOT( LoopButton_toggled(bool) ) );
    connect( RandomButton, SIGNAL( toggled(bool) ), this, SLOT( RandomButton_toggled(bool) ) );
    connect( PlayButton, SIGNAL( pressed() ), this, SLOT( PlayButton_pressed() ) );
    connect( PlayButton, SIGNAL( released() ), this, SLOT( PlayButton_released() ) );
    connect( StopButton, SIGNAL( pressed() ), this, SLOT( StopButton_pressed() ) );
    connect( StopButton, SIGNAL( released() ), this, SLOT( StopButton_released() ) );
    connect( NextButton, SIGNAL( released() ), this, SLOT( NextButton_released() ) );
    connect( NextButton, SIGNAL( pressed() ), this, SLOT( NextButton_pressed() ) );
    connect( PrevButton, SIGNAL( released() ), this, SLOT( PrevButton_released() ) );
    connect( PrevButton, SIGNAL( pressed() ), this, SLOT( PrevButton_pressed() ) );
    connect( FullScreenButton, SIGNAL( released() ), this, SLOT( FullScreenButton_released() ) );
    connect( FullScreenButton, SIGNAL( pressed() ), this, SLOT( FullScreenButton_pressed() ) );
    connect( OptionsButton, SIGNAL( released() ), this, SLOT( OptionsButton_released() ) );
    connect( OptionsButton, SIGNAL( pressed() ), this, SLOT( OptionsButton_pressed() ) );

    // tab order
    setTabOrder( PlayButton, StopButton );
    setTabOrder( StopButton, PrevButton );
    setTabOrder( PrevButton, NextButton );
    setTabOrder( NextButton, PLButton );
    setTabOrder( PLButton, TimeSlider );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
quiForm::~quiForm()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void quiForm::languageChange()
{
    setCaption( tr( "QUI for MPlayer" ) );
    RandomButton->setText( tr( "132" ) );
    QToolTip::add( RandomButton, tr( "Toggle Random" ) );
    TitleLabel->setText( tr( "Title" ) );
    QToolTip::add( TitleLabel, tr( "Title" ) );
    TimeLabel->setText( tr( "Time" ) );
    ArtistLabel->setText( tr( "Artist" ) );
    AlbumLabel->setText( tr( "Album" ) );
    BitrateLabel->setText( tr( "0 kbps" ) );
    NextButton->setText( tr( ">>" ) );
    PrevButton->setText( tr( "<<" ) );
    FullScreenButton->setText( tr( "FS" ) );
    LoopButton->setText( tr( "Loop" ) );
    QToolTip::add( LoopButton, tr( "Toggle Loop" ) );
    PLButton->setText( tr( "PL" ) );
    OptionsButton->setText( tr( "Opts" ) );
    StopButton->setText( tr( "Stop" ) );
    PlayButton->setText( tr( "Play" ) );
}

