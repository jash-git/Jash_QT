// ***************************************************************************************
// This file copyright 2003 Ben Nemec, distributed under the terms of the GPL, see COPYING
// ***************************************************************************************
#include "PlayFile.h"
#include <qprocess.h>
#include <qtimer.h>
#include <qfileinfo.h>
#include <qfile.h>
#include <qtextstream.h>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <time.h>

using namespace std;

PlayFile::PlayFile()
{
   isdummy = true;
   QProcess test;
   test.clearArguments();
   test.addArgument("aumix");
   test.addArgument("-wq");
   if (!test.start())
      foundaumix = false;
   else foundaumix = true;
}

PlayFile::PlayFile(QString filename, QStringList getparams, QString aoin, QString voin, QString stopxs,
                  QString deinterlacer)
{
   createList(filename);

   int i = 0;
   while (getparams[i] != "END OPTIONS")
   {
      mparams[i] = getparams[i];
      i++;
   }
   mparams[i] = getparams[i];  // Also include END OPTIONS to facilitate detection later
   ao = aoin;
   vo = voin;
   deint = deinterlacer;
   stopxscreensaver = true;
   if (stopxs == "false")
      stopxscreensaver = false;
   QFile mlog(QDir::homeDirPath() + "/.qui/qui.log");
   if (mlog.exists())  // Has to be done before MPlayer is started because startMPlayer
      mlog.remove();   // writes to it now
   m = new QProcess();
   startMPlayer();
   fn = filename;
   playing = true;
   debug = false;
   fullscreen = false;
   foundbr = false;
   dummyfound = false;
   video = true;
   notime = false;
   filelength = -1;
   
   // Determine whether aumix is available
   QProcess test;
   test.clearArguments();
   test.addArgument("aumix");
   test.addArgument("-wq");
   if (!test.start())
      foundaumix = false;
   else foundaumix = true;
   
   // How about lsdvd?
   test.clearArguments();
   test.addArgument("lsdvd");
   test.addArgument("-V");
   if (!test.start())
      foundlsdvd = false;
   else foundlsdvd = true;
   lsdvd = new QProcess();  // Do it regardless so we can delete it later
}

PlayFile::~PlayFile()
{
   if (!isDummy())
   {
      if (m->isRunning())
      {
         m->tryTerminate();   // Try to get rid of MPlayer nicely
         cout << "Trying to exit MPlayer...";
         time_t start = time(NULL);
         time_t current = time(NULL);
         while (current - start < 1 && m->isRunning())
            current = time(NULL);
         if (m->isRunning())   // If it isn't closed yet, be more insistent
         {
            cout << "MPlayer failed to exit quickly enough, killing\n";
            m->kill();
         }
         else cout << "Successful.\n";
      }
      delete m;
      
      // Don't particularly expect the following code to get used much, but it is theoretically possible
      if (lsdvd->isRunning())
      {
         lsdvd->tryTerminate();
         cout << "Trying to exit lsdvd...";
         time_t start = time(NULL);
         time_t current = time(NULL);
         while (current - start < 1 && m->isRunning())
            current = time(NULL);
         if (lsdvd->isRunning())
         {
            cout << "lsdvd failed to exit quickly enough, killing\n";
            lsdvd->kill();
         }
         else cout << "Successful.\n";
      }
      delete lsdvd;

      // Pretty sure the following is no longer necessary, but I'd hate to find out it was...:-)
      /*if (QFile::exists(QDir::homeDirPath() + "/.mplayer/quibakinput.conf"))
      {
         QFile removefile(QDir::homeDirPath() + "/.mplayer/input.conf");
         removefile.remove();
         QFile quibakinput(QDir::homeDirPath() + "/.mplayer/quibakinput.conf");
         QFile original(QDir::homeDirPath() + "/.mplayer/input.conf");
         original.open(IO_WriteOnly);
         quibakinput.open(IO_ReadOnly);
         QTextStream in(&quibakinput);
         QTextStream out(&original);
         QString temp = in.readLine();
         while (temp != NULL)
         {
            out << temp << endl;
            temp = in.readLine();
         }
      }*/
   }
}

void PlayFile::startMPlayer()
{
// I don't believe that editing the input.conf file should be necessary anymore, but I'm leaving the code
// just in case.  You never know.
   /*if (QFile::exists(QDir::homeDirPath() + "/.mplayer/input.conf"))  // Backup the user's input.conf
   {
      QFile original(QDir::homeDirPath() + "/.mplayer/input.conf");
      QFile quibakinput(QDir::homeDirPath() + "/.mplayer/quibakinput.conf");
      original.open(IO_ReadOnly);
      quibakinput.open(IO_WriteOnly);
      QTextStream out(&quibakinput);
      QTextStream in(&original);
      QString temp = in.readLine();
      while (temp != NULL)
      {
         out << temp << endl;
         temp = in.readLine();
      }
   }
   QFile newfile(QDir::homeDirPath() + "/.mplayer/input1.conf"); // Create QUI's input.conf
   newfile.open(IO_WriteOnly);
   QTextStream writeinput(&newfile);
   writeinput << "# MPlayer input.conf created by QUI\n";
   writeinput << "MOUSE_BTN0 vo_fullscreen\n";
   newfile.close();*/
   QFile log(QDir::homeDirPath() + "/.qui/qui.log");
   log.open(IO_WriteOnly | IO_Append);
   QTextStream logout(&log);
   
   m->clearArguments();  // Setup interface with MPlayer
   m->addArgument("mplayer");   // Every argument must have it's own addArgument
   m->addArgument("-slave");
   m->addArgument("-identify");
   m->addArgument("-quiet");
   if (ao != "default")
   {
      m->addArgument("-ao");
      m->addArgument(ao);
   }
   if (vo != "default")
   {
      m->addArgument("-vo");
      m->addArgument(vo);
   }
   if (stopxscreensaver)
      m->addArgument("-stop-xscreensaver");
   int i = 0;   // add extra MPlayer parameters from defaults.conf
   while (mparams[i] != "END OPTIONS")
   {
      m->addArgument(mparams[i]);
      i++;
   }
   if (deint != "none")
   {
      m->addArgument("-vf-add");
      m->addArgument("pp=" + deint);
   }
   m->addArgument("-playlist");
   m->addArgument(plloc);
   
   // Output the command used to start MPlayer for debugging purposes
   cout << "MPlayer command-line: " << m->arguments().join(" ") << endl << flush;
   logout << "MPlayer command-line: " <<  m->arguments().join(" ") << endl;

   if (!m->start())  // If MPlayer fails to start (i.e. not found) isdummy stays true, allowing error handling
   {
      cout << "MPlayer failed to start properly.  Make sure that the path to MPlayer is\n";
      cout << "listed in your path variable.\n";
      isdummy = true;
   }
   else
   {
      isdummy = false;
      filelength = -1;
      br = 0;
      title = "$!";
      artist = "$!";
      album = "$!";
      connect(m, SIGNAL(readyReadStdout()),   // detect when mplayer has information ready for us
         this, SLOT(readFromStdout()) );
      connect(m, SIGNAL(processExited()), this, SLOT(exited()));
      //connect(m, SIGNAL(readyReadStderr()), this, SLOT(debugslot())); // Same as below
      //connect(m, SIGNAL(wroteToStdin()), this, SLOT(debugslot()));  // Just for debugging
   }
}


// Play or pause
void PlayFile::Play()
{
   if (!isdummy && m->isRunning() && fn != "")
   {
         m->writeToStdin("pause\n");
         playing = !playing;
   }
}


// Just stop it
void PlayFile::Stop()
{
   if (!isdummy && m->isRunning())
   {
      if (!playing)
         m->writeToStdin("pause\n");
      m->writeToStdin("seek 0 1\n");
      m->writeToStdin("pause\n");
      playing = false;
   }
}



void PlayFile::OpenFile(QString filename)
{
   createList(filename);
   fn = filename;
   cout << "Filename: " << filename << endl << flush;

   if (!m->isRunning() && filename != "") // if the last file couldn't be played so mplayer exited
   {
      startMPlayer();
      if (!playing)
         m->writeToStdin("pause\n");
   }
   else if (filename != "")
   {
      filelength = -1;  // clear filelength so that we know we need to get the length of the new file
      br = 0;
      foundbr = false;
      dummyfound = false;
      video = true;
      notime = false;
      title = "$!";
      artist = "$!";
      album = "$!";
      getfn = "";
      fullscreen = false;
      /* Fine, if we load a file it plays.  Other methods don't work well.
      if (!playing)
         m->writeToStdin("pause\n");  // For some goofy reason it has to be playing before loading a file
                                      // I'm not sure this is still true, but it doesn't hurt and keeps
                                      // compatibility with old versions.*/
      if (!playing) Play();
      m->writeToStdin("loadlist \"" + plloc + "\"\n");
      /*if (!playing)
         m->writeToStdin("pause\n");*/
   }
   else Stop();
}


void PlayFile::Seek(int n)
{
   if (!isdummy && m->isRunning())
   {
      if (!playing)
         m->writeToStdin("pause\n");  // Apparently we need to be playing before seeking
      
      // Is this even necessary anymore?   
      QString ext = QFileInfo(fn).extension(false);
      
      // Adjust for sorta weird MPlayer behavior seeking in DVD's
      if ((foundlsdvd && fn.left(3) == "dvd") && !notime)  
         m->writeToStdin("seek " + IntToString((int)(n * ((float)wrongfilelength / (float)filelength))) + " 2\n");
      else if (notime)
         m->writeToStdin("seek " + IntToString(n) + " 1\n");
      else
         m->writeToStdin("seek " + IntToString(n) + " 2\n");
         
      if (!playing)
         m->writeToStdin("pause\n");
   }
}


void PlayFile::SetVolume(int n)
{
   if (foundaumix)
   {
      QProcess v;
      v.clearArguments();
      v.addArgument("aumix");
      QString s;
      if (mainvol)
         s = "-v";
      else
         s = "-w";
      s += IntToString(n);
      v.addArgument(s);
      if (!v.start())
      {
         cout << "There was an error running aumix.\n";
      }
   }
   else if (!isdummy && m->isRunning())
   {
      for (int i = 0; i < 33; i++)
         m->writeToStdin("volume " + IntToString(-1) + "\n");
      for (int j = 0; j < n / 3.0; j++)
         m->writeToStdin("volume " + IntToString(1) + "\n");
      if (!playing)
         m->writeToStdin("pause\n");
   }
}


void PlayFile::ToggleFullscreen()
{
   if (!isdummy && m->isRunning() && video)
   {
      if (!playing)
         m->writeToStdin("pause\n");
      m->writeToStdin("vo_fullscreen\n");
      if (!playing)
         m->writeToStdin("pause\n");
      fullscreen = !fullscreen;
   }
}


// Calculates the length of the file to be played.  It uses some math wizardry (nothing too tough though), to
// get a somewhat accurate value even for files that MPlayer does not correctly report.  It still manually
// calculates mp3's because it gives more error control for var. rate files that MPlayer doesn't really like.
// This also gets the file info (filename, bitrate etc) for the gui to display

/* Note: This function is Very Bad(tm).  It should really be rewritten to be more flexible and
   less error-prone, but it works just well enough that I haven't mustered the energy to do it.
   Nonetheless, if for any reason significant changes are necessary at some point, don't bother
   messing with this, just rewrite it.
*/
void PlayFile::calculateLength()
{
   QFileInfo fi(fn);
   uint filesize = 0;
   QString ext = fi.extension(false).lower();
   QFile log(QDir::homeDirPath() + "/.qui/qui.log");
   log.open(IO_WriteOnly | IO_Append);
   QTextStream logout(&log);
   // Get to the correct file info before getting
   if (getfn == "")
   {
      getfn = getFromStdout(QString("Playing ") + fn, "$!");
      if (getfn != "Error")
         getfn = "";
      else 
      {
         cout << "Getting file info...\n";
         logout << "Getting file info...\n";
      }
   }
   if (getfn != "")
   {
      if (ext.lower() == "mp3")
      {
         // Get file info.  Make sure we haven't already gotten a field (and therefore wouldn't find it again)
         if (title == "$!")
         {
            title = getFromStdout("Title", ": ");
            if (title == "-1valnamenotfound") title = "$!";
            else if (title == "$notfound$")
            {
               title = " ";
               artist = " ";
               album = " ";
            }
            else if (title == "$filefailed$")   // File didn't play
            {
               notime = true;
               filelength = 0;
               title = "";
               emit fileFailed();
            }
            else cout << "Found Title\n";
         }
         if (artist == "$!")
         {
            artist = getFromStdout("Artist", ": ");
            if (artist == "-1valnamenotfound") artist = "$!";
            else if (artist == "$notfound$")
            {
               artist = " ";
               album = " ";
            }
            else cout << "Found Artist\n";
         }
         if (album == "$!")
         {
            album = getFromStdout("Album", ": ");
            if (album == "-1valnamenotfound") album = "$!";
            else if (album == "$notfound$") album = " ";
            else cout << "Found Album\n";
         }
      }
      if (ext.lower() == "wma")
      {
         if (title == "$!")
            title = getFromStdout("name", ": ");
         if (title == "$notfound$")
         {
            title = " ";
            artist = " ";
         }
         else if (title == "$filefailed$")   // File didn't play
         {
            notime = true;
            filelength = 0;
            title = "";
            emit fileFailed();
         }
         else if (title == "-1valnamenotfound") title = "$!";
         else cout << "Found Title\n";
         if (artist == "$!")
            artist = getFromStdout("author", ": ");
         if (artist == "$notfound$")
            artist = " ";
         else if (artist == "-1valnamenotfound") artist = "$!";
         else cout << "Found Artist\n";
      }
      if (!foundbr)
      {
         if (video)
         {
            QString temp = "$notfound$";
            while (temp == "$notfound$")
            {
               temp = getFromStdout("ID_VIDEO_BITRATE", "=");
               if (temp == "$foundaudio$")   // No video
                  video = false;
               else if (temp == "$filefailed$")   // File didn't play
               {
                  notime = true;
                  filelength = 0;
                  emit fileFailed();
               }
               else if (temp != "-1valnamenotfound" && temp != "$notfound$")
               {
                  br = temp.toInt() / 1000;
                  foundbr = true;
               }
            }
         }
         // The $notfound$ check is not necessary like above because it _should_ be impossible to get that here
         if (!video)  // Not else because we could want to go to both the first one and this one
         {
            QString temp = getFromStdout("ID_AUDIO_BITRATE", "=");
            if (temp != "-1valnamenotfound")// && temp != "$notfound$")
            {
               br = temp.toInt() / 1000;
               foundbr = true;
            }
            fullscreen = false;
         }
      }
      if (ext == "mp3" && foundbr)
      {
         filesize = fi.size();

// If the bitrate is reported to be <= 48 that typically means it is variable bitrate, but since this will mess
// up the length calculation, 128 is used instead to come up with a value that is hopefully close enough to keep
// things within reason.  > 16 is included to allow for extremely low bitrate files such
// as streams, since I haven't seen any var. bit. files with lower than that reported anyway (in fact, I haven't
// seen any with less than 40, and most are exactly 48).
         if (br <= 48 && br > 16)
         {
            br = 128;
            cout << "********************************************************************************\n";
            cout << "Warning, possible variable bitrate file detected.  Assuming (probably incorrect)\n";
            cout << "rate of 128 kbps.  Because mplayer does not read the bitrate or length of these\n";
            cout << "files correctly, the length will be incorrectly reported in QUI, which could\n";
            cout << "result in errors.  It is suggested that you re-encode this file if you want to\n";
            cout << "play it in QUI.*****************************************************************\n";
            logout << "********************************************************************************\n";
            logout << "Warning, possible variable bitrate file detected.  Assuming (probably incorrect)\n";
            logout << "rate of 128 kbps.  Because mplayer does not read the bitrate or length of these\n";
            logout << "files correctly, the length will be incorrectly reported in QUI, which could\n";
            logout << "result in errors.  It is suggested that you re-encode this file if you want to\n";
            logout << "play it in QUI.*****************************************************************\n";
         }

         // probably excessive parenthesizing in the following expression, 
         // but float/int math errors are tough to debug, so let's just avoid them altogether.
         if (br != 0)  // Hopefully unnecessary, but to absolutely avoid div by 0 errors
            filelength = (int)( ( ((float)filesize) / ((float)br) ) / 125.3764);   // yay for math skills
         else  // I don't believe that it should ever get here, but it's theoretically possible
         {
            cout << "0 kbps mp3 found (according to MPlayer).  The size could not be calculated, so \n";
            cout << "QUI may not function correctly.\n";
            logout << "0 kbps mp3 found (according to MPlayer).  The size could not be calculated, so \n";
            logout << "QUI may not function correctly.\n";
            filelength = 100;
            notime = true;
         }
      }
      else if (foundbr)
      {
         QString slength = getFromStdout("ID_LENGTH", "=");
         float declength = slength.toFloat();
         filelength = (int)declength;
         if (filelength <= 0 && slength != "-1valnamenotfound")
         {
            cout << "0 length file reported by MPlayer.  All seeking will be done by percentage postition\n";
            cout << "from 0 to 100%\n";
            logout << "0 length file reported by MPlayer.  All seeking will be done by percentage postition\n";
            logout << "from 0 to 100%\n";
            notime = true;
            filelength = 100;
         }
      }
   }
   //if (filelength != 0)
     // getFromStdout("Dummy Length", "$");   // clear stdout, since we should be done with what it's telling us - wrong
}


/* Attempts to retrieve a value from stdout
returns -1valnamenotfound if valname is not found in stdout, returns error if divider is not found
on the same line as valname.  Returns $notfound$ if it finds the ID_FILENAME field before valname
and thus didn't find info such as artist and album.  Returns $foundaudio$ if it detects that a file
does not have any video, and $filefailed$ if the file appears to have failed to play
this can also be used to clear mplayer's stdout (which I don't recommend doing anymore:-)*/
QString PlayFile::getFromStdout(QString valname, QString divider)
{
   bool found = false;
   bool foundfilename = false;
   bool foundaudio = false;
   bool filefailed = false;
   QString temp, val;
   int pos;
   QFileInfo fi(fn);
   QFile log(QDir::homeDirPath() + "/.qui/qui.log");
   log.open(IO_WriteOnly | IO_Append);
   QTextStream logout(&log);
   while (m->canReadLineStdout() && !found)
   {
      temp = m->readLineStdout();
      if (debug)
      {
         cout << "Looking for string: " << valname << endl;
         logout << "Looking for string: " << valname << endl;
      }

      cout << "MPlayer: " << temp << endl << flush;
      // Don't write unnecessary junk to log file, with -quiet switch this shouldn't be necessary
      if (temp.left(2) != "A:" && temp.left(2) != "V:" && temp.left(7) != "  =====")
         logout << "MPlayer: " << temp << endl << flush;
         
      if (temp.find(valname) != -1)
      {
         temp = temp.mid(temp.find(valname), 80);
	      found = true;
      }
      else if (temp.find("ID_FILENAME") != -1)
      {
         //temp = temp.mid(temp.find("ID_FILENAME"), 80);
         found = true;
         foundfilename = true;
      }
      else if (valname == "ID_VIDEO_BITRATE" && temp.find("ID_AUDIO_FORMAT") != -1)
      {
         found = true;
         foundaudio = true;
      }
      // This needs to be fixed
      else if ((valname == "ID_VIDEO_BITRATE" || valname == "Title" || valname == "name")
                && temp.find(".qui/dummy.wav") != -1)
      {
         found = true;
         filefailed = true;
         cout << "The file failed to load.\n" << flush;
         logout << "The file failed to load.\n";
      }
   }
   if (!found)
      return "-1valnamenotfound";
   if (foundfilename)
      return "$notfound$";
   else if (foundaudio)
      return "$foundaudio$";
   else if (filefailed)
      return "$filefailed$";
   pos = temp.find(divider);
   if (pos != -1)
   {
      val = temp.mid(pos + divider.length());
      return val;
   }
   else return "Error";
}

void PlayFile::readFromStdout()
{
   QFile log(QDir::homeDirPath() + "/.qui/qui.log");
   log.open(IO_WriteOnly | IO_Append);
   QTextStream logout(&log);
   
   // If the file is a stream, we're not going to try to parse the output at this time
   if (filelength == -1)
   {
      calculateLength();
      if (filelength != -1)
      {
         if (filelength != 0)
         {
            cout << "QUI has gotten the file length!!!\n" << flush;
            logout << "QUI has gotten the file length!!!\n";
         }
	      emit haveFileLength();
         if ((foundlsdvd && fn.left(3) == "dvd") && !notime)
            getDVDLength();
      }
   }
   else if (!dummyfound)
   {
      QString dummy = getFromStdout(".qui/dummy.wav", "$");
      if (dummy == "Error")
      {
         logout << "File has completed\n";
         cout << "File has completed\n" << flush;
         dummyfound = true;
      }
   }
   
   if (dummyfound)  // Again, we might want to do both the one above and this one.
   {
      QString dummy = "$notfound$";
      while (dummy == "$notfound$")
         dummy = getFromStdout("Starting playback...", "$");
      if (dummy == "Error")
      {
         logout << "Loading next file\n";
         cout << "Loading next file\n" << flush;
         emit fileFinished();
      }
   }
   //else getFromStdout("Dummy Read", "$");
}


// Use lsdvd to get an accurate length for the DVD
void PlayFile::getDVDLength()
{
   QFile log(QDir::homeDirPath() + "/.qui/qui.log");
   log.open(IO_WriteOnly | IO_Append);
   QTextStream logout(&log);
   
   if (foundlsdvd && fn.left(3) == "dvd")  // Pretty sure this is redundant, but what the hey?
   {
      int tracknum = fn.mid(fn.find("//") + 2).toInt();
      lsdvdoutput = "";
      lsdvd->clearArguments();
      lsdvd->addArgument("lsdvd");
      lsdvd->addArgument("-q");
      lsdvd->addArgument("-t");
      lsdvd->addArgument(IntToString(tracknum));
      
      connect(lsdvd, SIGNAL(processExited()), this, SLOT(lsdvdDone()));
      connect(lsdvd, SIGNAL(readyReadStdout()), this, SLOT(readFromlsdvd()));
      if (!lsdvd->start())
      {
         cout << "Error starting lsdvd\n" << flush;
         logout << "Error starting lsdvd\n" << flush;
      }
   }
}


void PlayFile::readFromlsdvd()
{
   while(lsdvd->canReadLineStdout())
   {
      lsdvdoutput += lsdvd->readLineStdout();
   }
}


void PlayFile::lsdvdDone()
{
   //process the lsdvd output
   int tstart, tend, lstart;
   tstart = lsdvdoutput.find(':') + 1;
   tend = lsdvdoutput.findRev("Title:");
   title = lsdvdoutput.mid(tstart, tend - tstart).simplifyWhiteSpace();
   
   lstart = lsdvdoutput.find("Length:") + QString("Length:").length();
   QString len = lsdvdoutput.mid(lstart).simplifyWhiteSpace();
   int hours = len.left(2).toInt();
   int minutes = len.mid(3, 2).toInt();
   int seconds = len.right(2).toInt();
   wrongfilelength = filelength;
   filelength = hours * 3600 + minutes * 60 + seconds;
   
   emit haveFileLength();
}


void PlayFile::createList(QString file)
{
   if (!QFile(QDir::homeDirPath() + "/.qui/dummy.wav").exists())  // Comment out to debug
      createDummy();
   plloc = QDir::homeDirPath() + "/.qui/playfile.pla";
   QFile out(plloc);
   out.open(IO_WriteOnly);
   QTextStream outfile(&out);
   outfile << file << endl << flush;
   outfile << QDir::homeDirPath() + "/.qui/dummy.wav\n" << flush;
   out.close();
}


// Pretty much all of this function is ripped from TJ Weber's WAVE class.  At the time of this writing his page
// could be found at www.lightlink.com/tjweber/StripWave/WAVE.html
void PlayFile::createDummy()
{
   // open the file
	FILE *fp = fopen(QDir::homeDirPath() + "/.qui/dummy.wav", "wb");

   // write the file header
	unsigned long wholeLength = 400036;
	unsigned long chunkLength = 16;
   unsigned short formatType = 1;
   unsigned short numChannels = 2;
   unsigned long sampleRate = 44100;
   unsigned long bytesPerSecond = 88200;
   unsigned short bytesPerSample = 2;
   unsigned short bitsPerChannel = 8;
   unsigned long dataLength = 400000;

	if (fputs("RIFF", fp) == EOF
		|| pmsint4(fp, wholeLength) == 1
		|| fputs("WAVE", fp) == EOF
		|| fputs("fmt ", fp) == EOF
		|| pmsint4(fp, chunkLength) == 1
		|| pmsint2(fp, formatType) == 1
		|| pmsint2(fp, numChannels) == 1
		|| pmsint4(fp, sampleRate) == 1
		|| pmsint4(fp, bytesPerSecond) == 1
		|| pmsint2(fp, bytesPerSample) == 1
		|| pmsint2(fp, bitsPerChannel) == 1
		|| fputs("data", fp) == EOF
		|| pmsint4(fp, dataLength) == 1)
	{
		cout << "Problem writing dummy.wav, QUI may not behave well\n";
	}

   // Begin writing the blank data
   unsigned char buffer = 127;
   for (int i = 0; i < 400000; i++)
	   fwrite(&buffer, sizeof(buffer), 1, fp);
   fclose(fp);
   }

void PlayFile::exited()
{
   playing = false;
   isdummy = true;  // Make sure we know MPlayer died
   fn = "";
   emit mplayerExited();
}


// Slot that can have any particular signal connected to it to test various things
void PlayFile::debugslot()
{
   cout << "************************MPlayer error********************************\n" << flush;
   while (m->canReadLineStderr())
      cout << "Error" << m->readLineStderr() << endl << flush;
}


QString PlayFile::IntToString(int i)
{
	ostringstream s;
	s << i << flush;
	return QString(s.str().c_str());
}

// pmsint* functions provided by dchidelf on JustLinux.com forums
/**************************************************
*
 * pmsint2(FILE * fd, int val)
 * -------------------------------------------------
 * [ Print MicroSoft INT 2-byte ]
 * Write val to fd as a 2-byte little-endian int
  **************************************************
*/
#ifdef __STDC__
int PlayFile::pmsint2(FILE * fd, int val)
#else
int PlayFile::pmsint2(fd, val)
   FILE * fd;
   int val;
#endif
{
   fprintf(fd,"%c%c",
          val & 0xFF,
   (val >> 8) & 0xFF );
   return 0;
}

/**************************************************
*
 * pmsint4(FILE * fd, int val)
 * -------------------------------------------------
 * [ Print MicroSoft INT 4-byte ]
 * Write val to fd as a 4-byte little-endian int
  **************************************************
*/
#ifdef __STDC__
int PlayFile::pmsint4(FILE * fd, int val)
#else
int PlayFile::pmsint4(fd, val)
   FILE * fd;
   int val;
#endif
{
   fprintf(fd,"%c%c%c%c",
              val & 0xFF,
      (val >>  8) & 0xFF,
      (val >> 16) & 0xFF,
      (val >> 24) & 0xFF );
   return 0;
}

QString PlayFile::Filename()
{
   return fn;
}

int PlayFile::length()
{
   return filelength;
}

QString PlayFile::Title()
{
   return title;
}

QString PlayFile::Artist()
{
   return artist;
}

QString PlayFile::Album()
{
   return album;
}

uint PlayFile::bitrate()
{
   return br;
}

bool PlayFile::isDummy()
{
   return isdummy;
}

bool PlayFile::isPlaying()
{
   return playing;
}

bool PlayFile::isFullscreen()
{
   return fullscreen;
}

bool PlayFile::isVideo()
{
   return video;
}

void PlayFile::setDebug(bool val)
{
   debug = val;
}

void PlayFile::setMainVol(bool val)
{
   mainvol = val;
}

void PlayFile::setNotime(bool val)
{
   notime = val;
}

bool PlayFile::havelsdvd()
{
   return foundlsdvd;
}
