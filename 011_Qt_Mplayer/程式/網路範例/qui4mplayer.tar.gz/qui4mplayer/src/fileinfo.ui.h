/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you want to add, delete, or rename functions or slots, use
** Qt Designer to update this file, preserving your code.
**
** You should not define a constructor or destructor in this file.
** Instead, write your code in functions called init() and destroy().
** These will automatically be called by the form's constructor and
** destructor.
*****************************************************************************/
#include <qlineedit.h>

void FileInfo::init()
{

}


void FileInfo::destroy()
{

}


void FileInfo::setFields( QString fn, QString title, QString artist, QString album )
{
   FilenameLabel->setText(fn);
   TitleText->setText(title);
   ArtistText->setText(artist);
   AlbumText->setText(album);
}


void FileInfo::OKButton_clicked()
{
   accept();
}


void FileInfo::CancelButton_clicked()
{
   reject();
}


QString FileInfo::GetTitle()
{
   return TitleText->text();
}


QString FileInfo::GetArtist()
{
   return ArtistText->text();
}


QString FileInfo::GetAlbum()
{
   return AlbumText->text();
}
