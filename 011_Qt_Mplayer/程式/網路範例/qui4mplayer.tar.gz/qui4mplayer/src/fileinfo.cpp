/****************************************************************************
** Form implementation generated from reading ui file 'fileinfo.ui'
**
** Created: Thu Oct 26 20:49:37 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "fileinfo.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include "fileinfo.ui.h"

/*
 *  Constructs a FileInfo as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
FileInfo::FileInfo( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "FileInfo" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)1, 0, 0, sizePolicy().hasHeightForWidth() ) );
    FileInfoLayout = new QGridLayout( this, 1, 1, 8, 8, "FileInfoLayout"); 

    FilenameLabel = new QLabel( this, "FilenameLabel" );
    FilenameLabel->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );

    FileInfoLayout->addMultiCellWidget( FilenameLabel, 0, 0, 0, 3 );

    ArtistText = new QLineEdit( this, "ArtistText" );

    FileInfoLayout->addMultiCellWidget( ArtistText, 2, 2, 1, 3 );

    AlbumText = new QLineEdit( this, "AlbumText" );

    FileInfoLayout->addMultiCellWidget( AlbumText, 3, 3, 1, 3 );
    spacer1 = new QSpacerItem( 161, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    FileInfoLayout->addMultiCell( spacer1, 4, 4, 0, 1 );

    OKButton = new QPushButton( this, "OKButton" );

    FileInfoLayout->addWidget( OKButton, 4, 2 );

    CancelButton = new QPushButton( this, "CancelButton" );

    FileInfoLayout->addWidget( CancelButton, 4, 3 );

    TitleText = new QLineEdit( this, "TitleText" );

    FileInfoLayout->addMultiCellWidget( TitleText, 1, 1, 1, 3 );

    TitleLabel = new QLabel( this, "TitleLabel" );
    TitleLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, TitleLabel->sizePolicy().hasHeightForWidth() ) );

    FileInfoLayout->addWidget( TitleLabel, 1, 0 );

    ArtistLabel = new QLabel( this, "ArtistLabel" );
    ArtistLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, ArtistLabel->sizePolicy().hasHeightForWidth() ) );

    FileInfoLayout->addWidget( ArtistLabel, 2, 0 );

    AlbumLabel = new QLabel( this, "AlbumLabel" );
    AlbumLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, AlbumLabel->sizePolicy().hasHeightForWidth() ) );

    FileInfoLayout->addWidget( AlbumLabel, 3, 0 );
    languageChange();
    resize( QSize(431, 166).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( OKButton, SIGNAL( clicked() ), this, SLOT( OKButton_clicked() ) );
    connect( CancelButton, SIGNAL( clicked() ), this, SLOT( CancelButton_clicked() ) );

    // buddies
    TitleLabel->setBuddy( TitleText );
    ArtistLabel->setBuddy( ArtistText );
    AlbumLabel->setBuddy( AlbumText );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
FileInfo::~FileInfo()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FileInfo::languageChange()
{
    setCaption( tr( "File Information" ) );
    FilenameLabel->setText( tr( "Filename" ) );
    OKButton->setText( tr( "OK" ) );
    CancelButton->setText( tr( "Cancel" ) );
    TitleLabel->setText( tr( "Title:" ) );
    ArtistLabel->setText( tr( "Artist:" ) );
    AlbumLabel->setText( tr( "Album:" ) );
}

