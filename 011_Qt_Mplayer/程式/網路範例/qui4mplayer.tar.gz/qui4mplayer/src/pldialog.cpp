/****************************************************************************
** Form implementation generated from reading ui file 'pldialog.ui'
**
** Created: Thu Oct 26 20:49:41 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "pldialog.h"

#include <qvariant.h>
#include <qcombobox.h>
#include <qtable.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "pldialog.ui.h"

/*
 *  Constructs a PLDialog as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
PLDialog::PLDialog( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "PLDialog" );
    setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    setPaletteBackgroundColor( QColor( 0, 0, 0 ) );
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Light, QColor( 255, 127, 127) );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 63, 63) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 0, 0) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 0, 0) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Light, QColor( 255, 127, 127) );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 38, 38) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 0, 0) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 0, 0) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 255, 0, 0) );
    cg.setColor( QColorGroup::Light, QColor( 255, 127, 127) );
    cg.setColor( QColorGroup::Midlight, QColor( 255, 38, 38) );
    cg.setColor( QColorGroup::Dark, QColor( 127, 0, 0) );
    cg.setColor( QColorGroup::Mid, QColor( 170, 0, 0) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    setPalette( pal );
    setFocusPolicy( QDialog::StrongFocus );
    setAcceptDrops( TRUE );
    PLDialogLayout = new QGridLayout( this, 1, 1, 0, 0, "PLDialogLayout"); 

    PLLCombo = new QComboBox( FALSE, this, "PLLCombo" );
    PLLCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, PLLCombo->sizePolicy().hasHeightForWidth() ) );
    PLLCombo->setPaletteBackgroundColor( QColor( 0, 0, 255 ) );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 63, 63, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    PLLCombo->setPalette( pal );
    PLLCombo->setMouseTracking( TRUE );
    PLLCombo->setFocusPolicy( QComboBox::NoFocus );
    PLLCombo->setSizeLimit( 15 );

    PLDialogLayout->addWidget( PLLCombo, 0, 0 );

    FileListBox = new QTable( this, "FileListBox" );
    FileListBox->setNumCols( FileListBox->numCols() + 1 );
    FileListBox->horizontalHeader()->setLabel( FileListBox->numCols() - 1, tr( "Name" ) );
    FileListBox->setNumCols( FileListBox->numCols() + 1 );
    FileListBox->horizontalHeader()->setLabel( FileListBox->numCols() - 1, tr( "Time" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "1" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "2" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "3" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "4" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "5" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "6" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "7" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "8" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "9" ) );
    FileListBox->setNumRows( FileListBox->numRows() + 1 );
    FileListBox->verticalHeader()->setLabel( FileListBox->numRows() - 1, tr( "10" ) );
    FileListBox->setEnabled( TRUE );
    FileListBox->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, FileListBox->sizePolicy().hasHeightForWidth() ) );
    FileListBox->setPaletteForegroundColor( QColor( 0, 0, 255 ) );
    FileListBox->setPaletteBackgroundColor( QColor( 0, 0, 0 ) );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 63, 63, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, black );
    cg.setColor( QColorGroup::HighlightedText, QColor( 0, 255, 0) );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, black );
    cg.setColor( QColorGroup::HighlightedText, QColor( 0, 255, 0) );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::BrightText, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, black );
    cg.setColor( QColorGroup::HighlightedText, QColor( 0, 255, 0) );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setDisabled( cg );
    FileListBox->setPalette( pal );
    QFont FileListBox_font(  FileListBox->font() );
    FileListBox->setFont( FileListBox_font ); 
    FileListBox->setFocusPolicy( QTable::NoFocus );
    FileListBox->setAcceptDrops( FALSE );
    FileListBox->setFrameShape( QTable::StyledPanel );
    FileListBox->setFrameShadow( QTable::Sunken );
    FileListBox->setLineWidth( 0 );
    FileListBox->setMargin( 0 );
    FileListBox->setMidLineWidth( 0 );
    FileListBox->setResizePolicy( QTable::Default );
    FileListBox->setHScrollBarMode( QTable::AlwaysOff );
    FileListBox->setDragAutoScroll( TRUE );
    FileListBox->setNumRows( 10 );
    FileListBox->setNumCols( 2 );
    FileListBox->setShowGrid( FALSE );
    FileListBox->setColumnMovingEnabled( TRUE );
    FileListBox->setReadOnly( TRUE );
    FileListBox->setSelectionMode( QTable::SingleRow );
    FileListBox->setFocusStyle( QTable::FollowStyle );

    PLDialogLayout->addWidget( FileListBox, 1, 0 );

    layout8 = new QHBoxLayout( 0, 0, 6, "layout8"); 

    PLMenuButton = new QPushButton( this, "PLMenuButton" );
    PLMenuButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, PLMenuButton->sizePolicy().hasHeightForWidth() ) );
    PLMenuButton->setMinimumSize( QSize( 70, 0 ) );
    PLMenuButton->setPaletteBackgroundColor( QColor( 0, 0, 255 ) );
    PLMenuButton->setAutoDefault( FALSE );
    layout8->addWidget( PLMenuButton );

    RemoveButton = new QPushButton( this, "RemoveButton" );
    RemoveButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, RemoveButton->sizePolicy().hasHeightForWidth() ) );
    RemoveButton->setMinimumSize( QSize( 70, 0 ) );
    RemoveButton->setMaximumSize( QSize( 70, 30 ) );
    RemoveButton->setPaletteBackgroundColor( QColor( 0, 0, 255 ) );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 63, 63, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, black );
    cg.setColor( QColorGroup::LinkVisited, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, white );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, white );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, white );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 0, 0, 255) );
    cg.setColor( QColorGroup::Light, QColor( 127, 127, 255) );
    cg.setColor( QColorGroup::Midlight, QColor( 38, 38, 255) );
    cg.setColor( QColorGroup::Dark, QColor( 0, 0, 127) );
    cg.setColor( QColorGroup::Mid, QColor( 0, 0, 170) );
    cg.setColor( QColorGroup::Text, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::BrightText, white );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, black );
    cg.setColor( QColorGroup::Background, black );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 0, 0, 128) );
    cg.setColor( QColorGroup::HighlightedText, white );
    cg.setColor( QColorGroup::Link, QColor( 0, 0, 192) );
    cg.setColor( QColorGroup::LinkVisited, QColor( 128, 0, 128) );
    pal.setDisabled( cg );
    RemoveButton->setPalette( pal );
    RemoveButton->setAutoDefault( FALSE );
    layout8->addWidget( RemoveButton );

    MoveUpButton = new QPushButton( this, "MoveUpButton" );
    MoveUpButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, MoveUpButton->sizePolicy().hasHeightForWidth() ) );
    MoveUpButton->setMinimumSize( QSize( 30, 30 ) );
    MoveUpButton->setMaximumSize( QSize( 30, 30 ) );
    MoveUpButton->setPaletteBackgroundColor( QColor( 0, 0, 255 ) );
    MoveUpButton->setAutoDefault( FALSE );
    MoveUpButton->setDefault( FALSE );
    layout8->addWidget( MoveUpButton );

    MoveDownButton = new QPushButton( this, "MoveDownButton" );
    MoveDownButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, MoveDownButton->sizePolicy().hasHeightForWidth() ) );
    MoveDownButton->setMinimumSize( QSize( 30, 30 ) );
    MoveDownButton->setMaximumSize( QSize( 30, 30 ) );
    MoveDownButton->setPaletteBackgroundColor( QColor( 0, 0, 255 ) );
    MoveDownButton->setAutoDefault( FALSE );
    MoveDownButton->setDefault( FALSE );
    layout8->addWidget( MoveDownButton );

    PLDialogLayout->addLayout( layout8, 2, 0 );
    languageChange();
    resize( QSize(256, 364).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( RemoveButton, SIGNAL( clicked() ), this, SLOT( RemoveButton_clicked() ) );
    connect( FileListBox, SIGNAL( doubleClicked(int,int,int,const QPoint&) ), this, SLOT( FileListBox_doubleClicked(int,int,int,const QPoint&) ) );
    connect( PLLCombo, SIGNAL( activated(int) ), this, SLOT( PLLCombo_activated(int) ) );
    connect( MoveUpButton, SIGNAL( clicked() ), this, SLOT( MoveUpButton_clicked() ) );
    connect( MoveDownButton, SIGNAL( clicked() ), this, SLOT( MoveDownButton_clicked() ) );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
PLDialog::~PLDialog()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void PLDialog::languageChange()
{
    setCaption( tr( "Playlist Editor" ) );
    FileListBox->horizontalHeader()->setLabel( 0, tr( "Name" ) );
    FileListBox->horizontalHeader()->setLabel( 1, tr( "Time" ) );
    FileListBox->verticalHeader()->setLabel( 0, tr( "1" ) );
    FileListBox->verticalHeader()->setLabel( 1, tr( "2" ) );
    FileListBox->verticalHeader()->setLabel( 2, tr( "3" ) );
    FileListBox->verticalHeader()->setLabel( 3, tr( "4" ) );
    FileListBox->verticalHeader()->setLabel( 4, tr( "5" ) );
    FileListBox->verticalHeader()->setLabel( 5, tr( "6" ) );
    FileListBox->verticalHeader()->setLabel( 6, tr( "7" ) );
    FileListBox->verticalHeader()->setLabel( 7, tr( "8" ) );
    FileListBox->verticalHeader()->setLabel( 8, tr( "9" ) );
    FileListBox->verticalHeader()->setLabel( 9, tr( "10" ) );
    PLMenuButton->setText( tr( "Menu" ) );
    RemoveButton->setText( tr( "Remove" ) );
    MoveUpButton->setText( tr( "/\\" ) );
    MoveDownButton->setText( tr( "\\/" ) );
}

