// ***************************************************************************************
// This file copyright 2003 Ben Nemec, distributed under the terms of the GPL, see COPYING
// ***************************************************************************************
#ifndef PLAY_FILE_H
#define PLAY_FILE_H

#include <qobject.h>
#include <qprocess.h>
#include <qtimer.h>
#include <qfile.h>
#include <qtextstream.h>

class PlayFile : public QObject
{
        Q_OBJECT
	public:
	   // public variable declarations
      QString mparams[100];
	   // public function declarations
	   PlayFile(QString, QStringList, QString, QString, QString, QString);
	   PlayFile();
	   ~PlayFile();
	   void Play();
	   void Stop();
	   void OpenFile(QString);
	   void Seek(int);
      void SetVolume(int);
      void ToggleFullscreen();
      void setDebug(bool);
      void setMainVol(bool);
      void setNotime(bool);
      void getDVDLength();
	   QString Filename();
	   QString Title();
	   QString Artist();
	   QString Album();
	   uint bitrate();
	   int length();
	   bool isDummy();
	   bool isPlaying();
      bool isFullscreen();
      bool isVideo();
      bool havelsdvd();

	private:
	   // private variable declarations
	   bool playing;
	   bool isdummy;
      bool debug;
      bool fullscreen;
      bool video;
      bool foundbr;
      bool dummyfound;
      bool notime;
      bool foundaumix;
      bool mainvol;
      bool foundlsdvd;
      bool stopxscreensaver;
	   QString fn;
	   QProcess *m;
      QProcess *lsdvd;
	   int filelength, wrongfilelength;
      int winid;
	   uint br;
	   QString title;
	   QString artist;
	   QString album;
	   QString plloc;
      QString getfn;
      QString lsdvdoutput;
      QString ao, vo;
      QString deint;

	   //private function declarations
      void startMPlayer();
	   QString getFromStdout(QString, QString);
	   void calculateLength();
	   QString IntToString(int);
	   void createList(QString);
      void createDummy();
      int pmsint2(FILE*, int);
      int pmsint4(FILE*, int);

	private slots:
	   void readFromStdout();
      void exited();
      void debugslot();
      void lsdvdDone();
      void readFromlsdvd();

	signals:
	   void haveFileLength();
      void mplayerExited();
      void fileFinished();
      void fileFailed();

};

#endif
