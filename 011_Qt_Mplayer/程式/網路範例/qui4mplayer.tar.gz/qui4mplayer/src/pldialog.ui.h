// ***************************************************************************************
// This file copyright 2003 Ben Nemec, distributed under the terms of the GPL, see COPYING
// ***************************************************************************************

/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/

#include "quiform.h"
#include "dvdadd.h"
#include <iostream>
#include <sstream>   // Only included for debugging
#include <qfile.h>
#include <qdir.h>    // Ditto down to here
#include <qdragobject.h>
#include <qpopupmenu.h>

#define DOCKID 0  // Don't forget, must also be changed in quiform

using namespace std;

QPopupMenu *menu;
DVDAdd *dvdadd;

void PLDialog::init()
{
   FileListBox->setColumnStretchable(0, true);
   FileListBox->setColumnMovingEnabled(true);
   FileListBox->setColumnWidth(1, 45);
   FileListBox->setColumnWidth(2, 20);
   for (int i = 0; i < 10; i++)
      FileListBox->setRowHeight(i, 15);
   FileListBox->setDragEnabled(true);
   
   menu = new QPopupMenu();
   menu->insertItem("Add File(s)", this, SLOT(AddButton_clicked()));
   menu->insertItem("Add Directory", this, SLOT(AddDirButton_clicked()));
   menu->insertItem("Add DVD/VCD Tracks", this, SLOT(AddDVDVCD_clicked()));
   menu->insertItem("Add URL", this, SLOT(AddURL_clicked()));
   menu->insertSeparator();
   menu->insertItem("New Playlist", this, SLOT(NewButton_clicked()));
   menu->insertItem("Save Playlist", this, SLOT(SaveButton_clicked()));
   menu->insertItem("Load Playlist", this, SLOT(LoadButton_clicked()));
   menu->insertSeparator();
   menu->insertItem("Docked", this, SLOT(DockedItem_checked()), 0, DOCKID);
   menu->setCheckable(true);
   
   QFile log(QDir::homeDirPath() + "/.qui/qui.log");   // Debug code only
   log.open(IO_WriteOnly | IO_Append);
   QTextStream logout(&log);
   logout << "Debug info: Defining\n" << flush;
   
   menu->setItemChecked(DOCKID, false);  // Defaults to this, but just in case anyway
   PLMenuButton->setPopup(menu);
   
   dvdadd = new DVDAdd();
   connect(dvdadd, SIGNAL(AddDVDClicked(int)), this, SLOT(AddDVDClicked(int)));
   connect(dvdadd, SIGNAL(AddVCDClicked(int)), this, SLOT(AddVCDClicked(int)));
}

void PLDialog::destroy()
{
   
}


void PLDialog::closeEvent( QCloseEvent *ce )
{
   delete menu;
   delete dvdadd;
   
   ce->accept();
}


void PLDialog::AddButton_clicked()
{
   emit AddWasClicked();
}


void PLDialog::RemoveButton_clicked()
{
   emit RemoveWasClicked();
}

void PLDialog::FileListBox_doubleClicked( int row, int col, int button, const QPoint & mousepos )
{
   col++;  // Cheap way to avoid unused parameter warnings
   button++;
   mousepos.x();
   emit DoubleClicked(row);
}


void PLDialog::SaveButton_clicked()
{
   emit SaveClicked();
}


void PLDialog::NewButton_clicked()
{
   emit NewClicked(true);
}

void PLDialog::LoadButton_clicked()
{
   emit LoadClicked();
}

void PLDialog::PLLCombo_activated( int i )
{
   emit NewListSelected(i);
}

void PLDialog::AddDirButton_clicked()
{
   emit AddDirWasClicked();
}

void PLDialog::focusInEvent( QFocusEvent *fe )
{
   if (!fe->spontaneous())
      emit PlayListFocused();
}


void PLDialog::focusOutEvent( QFocusEvent *fe )
{
   if (fe->spontaneous())
   {
      emit PlayListFocusOut();
   }
}


void PLDialog::MoveUpButton_clicked()
{
   emit MoveUpClicked();
}


void PLDialog::MoveDownButton_clicked()
{
   emit MoveDownClicked();
}


void PLDialog::dropEvent( QDropEvent *e )
{
   emit FilesDropped(e);
}


void PLDialog::dragMoveEvent( QDragMoveEvent *e )
{
   if (QUriDrag::canDecode(e)) e->accept();
}


void PLDialog::contextMenuEvent( QContextMenuEvent *e )
{
   QPopupMenu m(this, "Right-click Menu");
   m.insertItem("Edit ID3 Tags", 1);
   int selected = m.exec(QCursor::pos());
      switch (selected)
   {
      case 1:
         emit EditClicked();
         break;
         
      default:
         break;
   }
   
   e->accept();
}


void PLDialog::AddDVDVCD_clicked()
{
   dvdadd->show();
}


void PLDialog::AddDVDClicked( int track )
{
   emit AddDVD(track);
}


void PLDialog::AddVCDClicked( int track )
{
   emit AddVCD(track);
}


void PLDialog::DockedItem_checked()
{
   QFile log(QDir::homeDirPath() + "/.qui/qui.log");  // Debug code only
   log.open(IO_WriteOnly | IO_Append);
   QTextStream logout(&log);
   logout << "Debug info: called\n" << flush;         // End debugging
   
   menu->setItemChecked(DOCKID, !menu->isItemChecked(DOCKID));
   emit DockedItemClicked(menu->isItemChecked(DOCKID));
}


void PLDialog::setDocked( bool dock )
{
   menu->setItemChecked(DOCKID, dock);
   emit DockedItemClicked(menu->isItemChecked(DOCKID));
}


void PLDialog::AddURL_clicked()
{
   emit AddURL();
}
