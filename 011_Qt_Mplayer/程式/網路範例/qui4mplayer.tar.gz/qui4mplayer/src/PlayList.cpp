// ***************************************************************************************
// This file copyright 2003 Ben Nemec, distributed under the terms of the GPL, see COPYING
// ***************************************************************************************

#include "PlayList.h"
#include "pldialog.h"
#include "fileinfo.h"
#include <cstdio>
#include <cstdlib>
#include <time.h>
#include <iostream>
#include <sstream>
#include <qtable.h>
#include <qfileinfo.h>
#include <qfiledialog.h>
#include <qstring.h>
#include <qtextstream.h>
#include <qcombobox.h>
#include <qpalette.h>
#include <qpushbutton.h>
#include <qtimer.h>
#include <qfile.h>
#include <qstrlist.h>
#include <qdragobject.h>
#include <qinputdialog.h>
#include <qpainter.h>
#include <qtable.h>

using namespace std;


// Override default table item so we can have different colored rows
class ColorTableItem : public QTableItem
{
   public:
      ColorTableItem(QTable *table, EditType et = QTableItem::Never, const QString text = "")
      : QTableItem(table, et, text)
      {
         tcol = table->colorGroup().text();
      }
      
      // Shamelessly ripped from the original QT qtable.cpp
      void paint( QPainter *p, const QColorGroup &cg,
                  const QRect &cr, bool selected )
      {
         QColorGroup g(cg);
         g.setColor(QColorGroup::Text, tcol);
         QTableItem::paint(p, g, cr, selected);
      }
      
      void SetCol(QColor col)
      {
         tcol = col;
      }
      
      QColor Col()
      {
         return tcol;
      }
      
   protected:
      QColor tcol;
}; // End ColorTableItem class


PlayList::PlayList(PLDialog *playlistdialog)
{
   size = 10;
   current = 0;
   used = new bool[10];
   filenum = -1;  // no other way to do it, has to be incremented before being returned
   files = new QString[10];
   random = false;
   loop = false;
   totalused = 0;
   pld = playlistdialog;
   shown = false;
   filename = "";
   newselected = false;
   adding = false;
   filter = "*.mp3 *.wma *.avi *.mpg *.mpeg *.asx *.wmv *.asx *.asf *.mov *.qt *.ogg *.ogm";
   filter += filter.upper();  // Some people abuse the caps lock key :-)
   
   // The colors must be set at the end of SetPal() or we don't get the color scheme colors
   for (int i = 0; i < 10; ++i)
   {
      pld->FileListBox->setItem(i, 0, new ColorTableItem(pld->FileListBox));
      pld->FileListBox->setItem(i, 1, new ColorTableItem(pld->FileListBox));
   }
   
   path = QDir::homeDirPath() + "/.qui/Playlists";
   QDir d(path);
   if (!d.exists())
   {
      QDir d1(QDir::homeDirPath());
      d1.mkdir(".qui");
      QDir d2(QDir::homeDirPath() + "/.qui");
      d2.mkdir("Playlists");
   }
   connect(pld, SIGNAL(AddWasClicked()), this, SLOT(AddClicked()));
   connect(pld, SIGNAL(AddDirWasClicked()), this, SLOT(AddDirClicked()));
   connect(pld, SIGNAL(RemoveWasClicked()), this, SLOT(RemoveClicked()));
   connect(pld, SIGNAL(DoubleClicked(int)), this, SLOT(PlayFileNum(int)));
   connect(pld, SIGNAL(NewClicked(bool)), this, SLOT(ClearList(bool)));
   connect(pld, SIGNAL(SaveClicked()), this, SLOT(SaveList()));
   connect(pld, SIGNAL(LoadClicked()), this, SLOT(LoadList()));
   connect(pld, SIGNAL(NewListSelected(int)), this, SLOT(LoadNewList(int)));
   connect(pld, SIGNAL(PlayListFocused()), this, SLOT(FocusIn()));
   connect(pld, SIGNAL(PlayListFocusOut()), this, SLOT(FocusOut()));
   connect(pld, SIGNAL(MoveUpClicked()), this, SLOT(UpClicked()));
   connect(pld, SIGNAL(MoveDownClicked()), this, SLOT(DownClicked()));
   connect(pld, SIGNAL(FilesDropped(QDropEvent *)), this, SLOT(Drop(QDropEvent *)));
   connect(pld, SIGNAL(EditClicked()), this, SLOT(EditClicked()));
   connect(pld, SIGNAL(AddDVD(int)), this, SLOT(AddDVD(int)));
   connect(pld, SIGNAL(AddVCD(int)), this, SLOT(AddVCD(int)));
   connect(pld, SIGNAL(AddURL()), this, SLOT(AddURL()));
}

PlayList::~PlayList()
{
   delete [] files;
   delete [] used;
   pld->close();
}

void PlayList::Add(QString filename)
{
   if (current >= size)
   {
      QString *temp = new QString[size * 2];
      bool *temp2 = new bool[size * 2];
      pld->FileListBox->setNumRows(size * 2);
      for (int i = 0; i < size * 2; i++)
         pld->FileListBox->setRowHeight(i, 15);
      for (int i = 0; i < size; i++)
      {
         temp[i] = files[i];
         temp2[i] = used[i];
      }
      for (int i = size; i < size * 2; i++)
      {
         pld->FileListBox->setItem(i, 0, new ColorTableItem(pld->FileListBox));
         pld->FileListBox->setItem(i, 1, new ColorTableItem(pld->FileListBox));
      }
      size *= 2;
      delete [] files;
      delete [] used;
      files = temp;
      used = temp2;
   }
   files[current] = filename;
   used[current] = false;
   QFileInfo fi(filename);
   if (fi.filePath().find("://") == -1)
      pld->FileListBox->setText(current, 0, fi.fileName());
   else pld->FileListBox->setText(current, 0, fi.filePath());
   
   // Attempt to read id3 tag of MP3's
   if (fi.extension(false) == "mp3" && fi.exists())
   {
      QFile gettag(filename);
      gettag.open(IO_ReadOnly);
      gettag.at(gettag.at() + gettag.size() - 128);
      char temptag[128];
      gettag.readBlock(temptag, 128);
      QString id3tag(temptag);
      if (id3tag.left(3) == "TAG")
      {
         if (id3tag.mid(3, 30).simplifyWhiteSpace() != "")
            pld->FileListBox->setText(current, 0, id3tag.mid(3, 30));
      }
      gettag.close();
   }
   current++;
}

// Working now (I hope).  Removes the ONE file currently selected
void PlayList::Remove(int n)
{
   if (current != 0 && n < current)  // Make sure there is a file in the playlist to remove
   {
      if (used[n]) // keep all the numbers in sync
         totalused--;
      if (filenum >= n) // Including the current file stupid
         filenum--;
         
      if (current != n + 1)
      {
         for (int i = n; i < current; i++)  // move everything up one spot in the playlist
         {
            if (current != i + 1)
            {
               files[i] = files[i + 1];
               used[i] = used[i + 1];
               pld->FileListBox->setText(i, 0, pld->FileListBox->text(i + 1, 0));
               pld->FileListBox->setText(i, 1, pld->FileListBox->text(i + 1, 1));
               QColor textcol = dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i + 1, 0))->Col();
               cout << textcol.red() << endl << flush;
               dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 0))->SetCol(textcol);
               dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 1))->SetCol(textcol);
            }
         }
      }
      current--;
      pld->FileListBox->setText(current, 0, "");
      pld->FileListBox->setText(current, 1, "");
      QColor text = pld->FileListBox->colorGroup().text();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(current, 0))->SetCol(text);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(current, 1))->SetCol(text);
   }
}

// should return empty string if there is not a next file
QString PlayList::GetNextFile()
{
   time_t t;
   if (current == 0)  // we don't have any playlist entries yet
      return "";
   if (((totalused >= current && random) || (filenum == current - 1 && !random)) && loop)  // we've used all the entries, but we're looping so start over
   {
      totalused = 0;
      filenum = -1;  // see original definition for reason for -1
      for (int i = 0; i < current; i++)
         used[i] = false;
   }
   // check if we're not looping or random and we're at the last file
   // or if we are random, have used all the files, and are not looping
   else if ((filenum == current - 1 && !loop && !random) || (totalused >= current && !loop && random))
   {
      totalused = 0;
      filenum = 0;  // Needs to be 0 here so when quiform::Play() does getCurrent it gets the first file.
      for (int i = 0; i < current; i++)
         used[i] = false;
      return "";  // not looping, so we can't return the next file
   }
   if (random)   // want a random play order, so get a random file from the list
   {
      t = time(NULL);
      srand(t);
      filenum = rand() % current;
      while (used[filenum])
         filenum = rand() % current;  // get a random number between 0 and current - 1 inclusive (I hope)
   }
   else  // otherwise just go to the next file
   {
      if (filenum != current - 1)  // in case we switched from random to seq. play
         filenum++;
   }
   if (!used[filenum])
   {
      used[filenum] = true;
      totalused++;
   }
   for (int i = 0; i < current; i++)
   {
      QColor textcol = pld->FileListBox->colorGroup().text();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 0))->SetCol(textcol);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 1))->SetCol(textcol);
   }
   QColor high = pld->FileListBox->colorGroup().midlight();
   dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 0))->SetCol(high);
   dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 1))->SetCol(high);
   pld->FileListBox->updateContents();
   pld->FileListBox->setCurrentCell(filenum, 0);
   return files[filenum];
}

// Actually simpler than getnext because we don't deal with looping or random play
QString PlayList::GetPrevFile()
{
   if (current == 0 || random) // Can't get the previous file in a random playlist or if we don't have a file yet
      return "";
   if (filenum != 0) // Stops at the first file in the playlist and repeatedly returns it
      filenum--;
   if (!used[filenum])
   {
      used[filenum] = true;
      totalused++;
   }
   for (int i = 0; i < current; i++)
   {
      QColor textcol = pld->FileListBox->colorGroup().text();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 0))->SetCol(textcol);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 1))->SetCol(textcol);
   }
   QColor high = pld->FileListBox->colorGroup().midlight();
   dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 0))->SetCol(high);
   dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 1))->SetCol(high);
   pld->FileListBox->updateContents();
   pld->FileListBox->setCurrentCell(filenum, 0);
   return files[filenum];
}

void PlayList::AddClicked()
{
   adding = true;
   QStringList files = QFileDialog::getOpenFileNames(
	QString("AV Files (") + filter + QString(");;All Files (*.*)"),
	defaultdir, pld, QString("add file to playlist dialog"),
	QString("Select File(s) to Add"));
   adding = false;
	while(!files.isEmpty())
	{
	   Add(files.first());
	   files.pop_front();
	}
}

void PlayList::AddDirClicked()
{
   adding = true;
   QString dirselected = QFileDialog::getExistingDirectory(defaultdir);
   adding = false;
   QDir d(dirselected);
   d.setNameFilter(filter);
   for (uint i = 0; i < d.count(); i++)
   {
      Add(d.absPath() + "/" + d[i]);
   }
}

void PlayList::UpClicked()
{
   if (swap(pld->FileListBox->currentRow(), pld->FileListBox->currentRow() - 1))
      pld->FileListBox->setCurrentCell(pld->FileListBox->currentRow() - 1, 0);
}

void PlayList::DownClicked()
{
   if (swap(pld->FileListBox->currentRow(), pld->FileListBox->currentRow() + 1))
      pld->FileListBox->setCurrentCell(pld->FileListBox->currentRow() + 1, 0);
}

bool PlayList::swap(int one, int two)
{
   if (one >= 0 && one < current && two >= 0 && two < current)
   {
      QString title = pld->FileListBox->text(one, 0);
      QString time = pld->FileListBox->text(one, 1);
      QColor col = dynamic_cast<ColorTableItem*> (pld->FileListBox->item(one, 0))->Col();
      QString file = files[one];
      
      pld->FileListBox->setText(one, 0, pld->FileListBox->text(two, 0));
      pld->FileListBox->setText(one, 1, pld->FileListBox->text(two, 1));
      QColor textcol = dynamic_cast<ColorTableItem*> (pld->FileListBox->item(two, 0))->Col();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(one, 0))->SetCol(textcol);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(one, 1))->SetCol(textcol);
      
      files[one] = files[two];
      pld->FileListBox->setText(two, 0, title);
      pld->FileListBox->setText(two, 1, time);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(two, 0))->SetCol(col);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(two, 1))->SetCol(col);
      
      files[two] = file;
      if (filenum == one)
         filenum = two;
      else if (filenum == two)
         filenum = one;
      return true;
   }
   return false;
}

void PlayList::RemoveClicked()
{
   Remove(pld->FileListBox->currentRow());
}

void PlayList::SetRandom(bool onoff)
{
   random = onoff;
}

void PlayList::SetLoop(bool onoff)
{
   loop = onoff;
}

bool PlayList::isEmpty()
{
   return current == 0;
}

void PlayList::CloseEditor()
{
   pld->close();
}

void PlayList::PlayFileNum(int row)
{
   emit DialogDoubleClicked(row);
}

QString PlayList::GetFileAt(int row)
{
   if (row < current)
   {
      if (!used[row])
      {
         used[row] = true;
         totalused++;
      }
      for (int i = 0; i < current; i++)
      {
         QColor textcol = pld->FileListBox->colorGroup().text();
         dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 0))->SetCol(textcol);
         dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 1))->SetCol(textcol);
      }
      QColor high = pld->FileListBox->colorGroup().midlight();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(row, 0))->SetCol(high);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(row, 1))->SetCol(high);
      pld->FileListBox->updateContents();
      pld->FileListBox->setCurrentCell(row, 0);
      filenum = row;
      return files[row];
   }
   else return "";
}

void PlayList::SetCurrentName(QString n)
{
   pld->FileListBox->setText(filenum, 0, n);
}

void PlayList::SetCurrentTime(QString t)
{
   pld->FileListBox->setText(filenum, 1, t);
}

void PlayList::ClearList(bool clearpll)
{
   if (clearpll)
      pld->PLLCombo->setCurrentItem(0);
   for (int i = 0; i < current; i++)
   {
      files[i] = "";
      used[i] = false;
      pld->FileListBox->setText(i, 0, "");
      pld->FileListBox->setText(i, 1, "");
   }
   totalused = 0;
   filenum = 0;
   current = 0;
   filename = "";
   size = 10;
   pld->FileListBox->setNumRows(10);
   if (!newselected)
      emit NewList();
   newselected = false;
}

void PlayList::SaveList()
{
   bool fileListChanged = false;
   if (filename == "")
   {
      adding = true;
      filename = QFileDialog::getSaveFileName(
         path,
         QString("All Files (*);;M3U Playlists (*.m3u)"),
         pld, QString("save playlist dialog"),
         QString("Select Playlist to Save"));
      adding = false;
      fileListChanged = true;
   }
   if (filename != "")  // NOT else!
   {
      QFile o(filename);
      o.open(IO_WriteOnly);
      QTextStream ofile(&o);
      QString ext = QFileInfo(o).extension(false).lower();
      
      for (int i = 0; i < current; i++)
      {
         ofile << files[i] << endl;
         if (ext == "m3u")  // Clever, just use comments to make it an m3u:-)
            ofile << "#";
         ofile << pld->FileListBox->text(i, 0) << endl;
         if (ext == "m3u")
            ofile << "#";
         ofile << pld->FileListBox->text(i, 1) << endl;
      }
      o.close();
   }
   if (fileListChanged)
      refreshPLL();
}

void PlayList::LoadList()
{
   adding = true;
   QString temp = QFileDialog::getOpenFileName(
        path,
	QString("All Files (*);;M3U Playlists (*.m3u)"),
	pld, QString("open playlist dialog"),
	QString("Select Playlist to Open"));
   adding = false;
   if (temp != "")
   {
      Open(temp);
   }
}

void PlayList::refreshPLL()
{
   int currpl = pld->PLLCombo->currentItem();
   pld->PLLCombo->clear();
   pll.clear();
   QDir getlists(path);
   pld->PLLCombo->insertItem("");
   for (uint i = 0; i < getlists.count(); i++)
   {
      QFileInfo fi(getlists, getlists[i]);
      if (!fi.isDir())
      {
         pld->PLLCombo->insertItem(fi.baseName());
         pll.append(fi.filePath());
      }
   }
   pld->PLLCombo->setCurrentItem(currpl);
}


// Reads filenames from a playlist file.  
void PlayList::Open(QString o)
{
   int j = 0;
   newselected = true;
   ClearList(false);
   QFile i(o);    // Hmm, using i was probably a poor choice.  Oh well.
   i.open(IO_ReadOnly);
   QTextStream ifile(&i);
   QString buffer = ifile.readLine();
   filename = o;
   filenum = -1;
   QString ext = QFileInfo(filename).extension(false).lower();
   
   if (ext != "m3u")  // Load a QUI formatted playlist
   {
      while (!ifile.atEnd())
      {
         Add(buffer);  // Add filename
         buffer = ifile.readLine();  // Read title
         if (pld->FileListBox->text(j, 0).simplifyWhiteSpace() == "" ||
             QFileInfo(buffer).extension(false).lower() != "mp3")
            pld->FileListBox->setText(j, 0, buffer);
         buffer = ifile.readLine();  // Read time
         pld->FileListBox->setText(j, 1, buffer);
         buffer = ifile.readLine();  // Read next filename
         j++;
      }
   }
   else if (ext == "m3u")  // Load an m3u playlist, possibly more formats later
   {
      while (!ifile.atEnd())
      {
         if (buffer.left(1) != "#" && buffer.simplifyWhiteSpace() != "")
         {
            Add(buffer);
            if (pld->FileListBox->text(j, 0).simplifyWhiteSpace() == "")
               pld->FileListBox->setText(j, 0, buffer);
         }
         buffer = ifile.readLine();
      }
   }
   i.close();
   emit NewPlaylistSelected();
}

void PlayList::LoadNewList(int i)
{
   if (i > 0)
      Open(pll[i - 1]);  // - 1 because of the first blank line in PLLCombo
}


void PlayList::Drop(QDropEvent *e)
{
   QStrList uris;
   if (QUriDrag::decode(e, uris))
   {
      QString geturi = "";
      geturi = uris.first();
      while (!uris.isEmpty())
      {
         Add(QUriDrag::uriToLocalFile(geturi));
         uris.remove();
         geturi = uris.first();
      }
      e->accept();
   }
}


bool PlayList::isRandom()
{
   return random;
}


bool PlayList::isLoop()
{
   return loop;
}


QString PlayList::GetCurrFile()
{
   if (current == 0)
      return "";
   for (int i = 0; i < current; i++)
   {
      QColor textcol = pld->FileListBox->colorGroup().text();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 0))->SetCol(textcol);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 1))->SetCol(textcol);
   }
   QColor high = pld->FileListBox->colorGroup().midlight();
   dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 0))->SetCol(high);
   dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 1))->SetCol(high);
   pld->FileListBox->updateContents();
   pld->FileListBox->setCurrentCell(filenum, 0);
   
   return files[filenum];
}



void PlayList::FocusIn()
{
   refreshPLL();
   emit RaiseQUI();
}

void PlayList::FocusOut()
{
   emit NeedMouse();
}

void PlayList::SetPal()
{
   pld->PLLCombo->setPalette(pal);
   pld->FileListBox->setPalette(pal);
   //pld->AddButton->setPalette(pal);  // All obsoleted by new menu button
   //pld->AddDirButton->setPalette(pal);
   pld->RemoveButton->setPalette(pal);
   //pld->NewButton->setPalette(pal);
   //pld->SaveButton->setPalette(pal);
   //pld->LoadButton->setPalette(pal);
   pld->MoveUpButton->setPalette(pal);
   pld->MoveDownButton->setPalette(pal);
   pld->PLMenuButton->setPalette(pal);
   
   // This has to happen in SetPal because otherwise the color scheme hasn't been set yet.
   // Also, if the user changes the scheme having this here will properly update the playlist.
   for (int i = 0; i < size; i++)
   {
      QColor textcol = pld->FileListBox->colorGroup().text();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 0))->SetCol(textcol);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(i, 1))->SetCol(textcol);
   }
   if (filenum != -1)  // First time through nothing should be highlighted
   {
      QColor high = pld->FileListBox->colorGroup().midlight();
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 0))->SetCol(high);
      dynamic_cast<ColorTableItem*> (pld->FileListBox->item(filenum, 1))->SetCol(high);
      pld->FileListBox->updateContents();
   }
}


void PlayList::EditClicked()
{
   FileInfo f;
   QString fname = files[pld->FileListBox->currentRow()];
   QString title = "None";
   QString artist = "None";
   QString album = "None";
   QFileInfo fi(fname);
   
   // Attempt to read id3 tag of MP3s and open an edit dialog
   if (fi.extension(false).lower() == "mp3")
   {
      QFile gettag(fname);
      gettag.open(IO_ReadOnly);
      gettag.at(gettag.at() + gettag.size() - 128);
      char temptag[34];
      char tempartist[31];
      char tempalbum[31];
      gettag.readBlock(temptag, 33);
      temptag[33] = '\0';
      QString id3tag(temptag);
      gettag.readBlock(tempartist, 30);
      tempartist[30] = '\0';
      QString id3artist(tempartist);
      gettag.readBlock(tempalbum, 30);
      tempalbum[30] = '\0';
      QString id3album(tempalbum);
      if (id3tag.left(3) == "TAG")
      {
         title = id3tag.mid(3, 30);
         artist = id3artist;
         album = id3album;
      }
      gettag.close();
   }
   else title = pld->FileListBox->text(pld->FileListBox->currentRow(), 0);
   
   f.setFields(fname, title, artist, album);
   if (f.exec() == QDialog::Accepted)
   {
      pld->FileListBox->setText(pld->FileListBox->currentRow(), 0, f.GetTitle());
      if (fi.extension(false).lower() == "mp3")
      {
         QFile settag(fname);
         settag.open(IO_ReadWrite);
         settag.at(settag.at() + settag.size() - 128);
         char temptag[4];
         settag.readBlock(temptag, 3);
         temptag[3] = '\0';
         if (QString(temptag) == "TAG")  // Alter existing tags
         {
            QString newtitle = f.GetTitle();
            // Make sure the string fills the space
            newtitle.append('\0');
            newtitle.append(QString().fill(' ', 30));
            newtitle.truncate(30);
            settag.writeBlock(newtitle.ascii(), newtitle.length());
            
            QString newartist = f.GetArtist();
            newartist.append('\0');
            newartist.append(QString().fill(' ', 30));
            newartist.truncate(30);
            settag.writeBlock(newartist.ascii(), newartist.length());
            
            QString newalbum = f.GetAlbum();
            newalbum.append('\0');
            newalbum.append(QString().fill(' ', 30));
            newalbum.truncate(30);
            settag.writeBlock(newalbum.ascii(), newalbum.length());
         }
         else // Add tags to the end of the file
         {
            settag.writeBlock("TAG", 3);
            QString newtitle = f.GetTitle();
            // Make sure the string fills the space
            newtitle.append('\0');
            newtitle.append(QString().fill(' ', 30));
            newtitle.truncate(30);
            settag.writeBlock(newtitle.ascii(), newtitle.length());
            
            QString newartist = f.GetArtist();
            newartist.append('\0');
            newartist.append(QString().fill(' ', 30));
            newartist.truncate(30);
            settag.writeBlock(newartist.ascii(), newartist.length());
            
            QString newalbum = f.GetAlbum();
            newalbum.append('\0');
            newalbum.append(QString().fill(' ', 30));
            newalbum.truncate(30);
            settag.writeBlock(newalbum.ascii(), newalbum.length());
            // Year, Comment, and Genre are left blank for now
            settag.writeBlock(QString().fill(' ', 35).ascii(), 35);
            
         }
      }
   }
}


void PlayList::AddDVD(int track)
{
   Add("dvd://" + IntToString(track));
}


void PlayList::AddVCD(int track)
{
   Add("vcd://" + IntToString(track));
}


void PlayList::AddURL()
{
   QString url = QInputDialog::getText("Enter URL", "URL");
   Add(url);
}


// Just a helper function to cast ints into QStrings
QString PlayList::IntToString(int i)
{
   ostringstream s;
   s << i << flush;
   return QString(s.str().c_str());
}



// *******Following functions deal with properly placing and showing the playlist**********
bool PlayList::DialogIsActive()
{
   return pld->isActiveWindow();
}

void PlayList::SetShown(bool tf)
{
   shown = tf;
}

void PlayList::Hide()
{
   pld->hide();
}

void PlayList::Show()
{
   refreshPLL();
   if (shown)
   {
      pld->show();
      pld->raise();
   }
   // Hack to adjust the window after it has been decorated and dimensions
   // can be properly calculated.  Results in a brief flash when the window
   // is shown, but at least it ends up in the right place.
   QTimer::singleShot(100, this, SLOT(ResetPos()));
}

// Expects to get the lower right corner of the main window
void PlayList::SetPos(int x, int y)
{
   savex = x;
   savey = y;
   QPoint p(x + 1, y - pld->frameGeometry().height());
   pld->move(p);
}

void PlayList::ResetPos()
{
   SetPos(savex, savey);
}

bool PlayList::Shown()
{
   return shown;
}

bool PlayList::isAdding()
{
   return adding;
}


