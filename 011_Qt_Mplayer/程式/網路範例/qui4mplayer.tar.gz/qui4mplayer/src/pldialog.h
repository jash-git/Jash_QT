/****************************************************************************
** Form interface generated from reading ui file 'pldialog.ui'
**
** Created: Thu Oct 26 20:49:30 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef PLDIALOG_H
#define PLDIALOG_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QComboBox;
class QTable;
class QPushButton;

class PLDialog : public QDialog
{
    Q_OBJECT

public:
    PLDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~PLDialog();

    QComboBox* PLLCombo;
    QTable* FileListBox;
    QPushButton* PLMenuButton;
    QPushButton* RemoveButton;
    QPushButton* MoveUpButton;
    QPushButton* MoveDownButton;

public slots:
    virtual void closeEvent( QCloseEvent * ce );
    virtual void AddButton_clicked();
    virtual void RemoveButton_clicked();
    virtual void FileListBox_doubleClicked( int row, int col, int button, const QPoint & mousepos );
    virtual void SaveButton_clicked();
    virtual void NewButton_clicked();
    virtual void LoadButton_clicked();
    virtual void PLLCombo_activated( int i );
    virtual void AddDirButton_clicked();
    virtual void focusInEvent( QFocusEvent * fe );
    virtual void focusOutEvent( QFocusEvent * fe );
    virtual void MoveUpButton_clicked();
    virtual void MoveDownButton_clicked();
    virtual void dropEvent( QDropEvent * e );
    virtual void dragMoveEvent( QDragMoveEvent * e );
    virtual void contextMenuEvent( QContextMenuEvent * e );
    virtual void AddDVDVCD_clicked();
    virtual void AddDVDClicked( int track );
    virtual void AddVCDClicked( int track );
    virtual void DockedItem_checked();
    virtual void setDocked( bool dock );
    virtual void AddURL_clicked();

signals:
    void AddWasClicked();
    void RemoveWasClicked();
    void DoubleClicked(int);
    void SaveClicked();
    void LoadClicked();
    void NewListSelected(int);
    void NewClicked(bool);
    void AddDirWasClicked();
    void PlayListFocused();
    void PlayListFocusOut();
    void Shown();
    void MoveUpClicked();
    void MoveDownClicked();
    void FilesDropped(QDropEvent *);
    void EditClicked();
    void AddDVD( int );
    void AddVCD( int );
    void DockedItemClicked( bool );
    void AddURL();

protected:
    QGridLayout* PLDialogLayout;
    QHBoxLayout* layout8;

protected slots:
    virtual void languageChange();

private:
    void init();
    void destroy();

};

#endif // PLDIALOG_H
