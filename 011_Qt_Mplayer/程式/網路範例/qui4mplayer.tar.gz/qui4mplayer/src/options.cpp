/****************************************************************************
** Form implementation generated from reading ui file 'options.ui'
**
** Created: Sun Apr 1 00:14:45 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "options.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qtabwidget.h>
#include <qwidget.h>
#include <qgroupbox.h>
#include <qlineedit.h>
#include <qcheckbox.h>
#include <qspinbox.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qcombobox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include "options.ui.h"

/*
 *  Constructs a OptionsForm as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
OptionsForm::OptionsForm( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "OptionsForm" );
    setModal( TRUE );
    OptionsFormLayout = new QGridLayout( this, 1, 1, 3, 0, "OptionsFormLayout"); 

    CancelButton = new QPushButton( this, "CancelButton" );
    CancelButton->setAutoDefault( FALSE );

    OptionsFormLayout->addWidget( CancelButton, 1, 3 );

    OKButton = new QPushButton( this, "OKButton" );
    OKButton->setAutoDefault( FALSE );

    OptionsFormLayout->addWidget( OKButton, 1, 2 );

    restartrequired = new QLabel( this, "restartrequired" );
    restartrequired->setAlignment( int( QLabel::AlignCenter ) );

    OptionsFormLayout->addWidget( restartrequired, 1, 1 );
    spacer4_2 = new QSpacerItem( 70, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    OptionsFormLayout->addItem( spacer4_2, 1, 0 );

    Tab = new QTabWidget( this, "Tab" );
    Tab->setTabShape( QTabWidget::Rounded );

    options = new QWidget( Tab, "options" );
    optionsLayout = new QGridLayout( options, 1, 1, 11, 6, "optionsLayout"); 

    MiscOpts = new QGroupBox( options, "MiscOpts" );
    MiscOpts->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, 0, 0, MiscOpts->sizePolicy().hasHeightForWidth() ) );

    pathEdit = new QLineEdit( MiscOpts, "pathEdit" );
    pathEdit->setGeometry( QRect( 10, 40, 190, 22 ) );

    BrowseButton = new QPushButton( MiscOpts, "BrowseButton" );
    BrowseButton->setGeometry( QRect( 200, 40, 80, 24 ) );
    BrowseButton->setAutoDefault( FALSE );

    DebugCheck = new QCheckBox( MiscOpts, "DebugCheck" );
    DebugCheck->setGeometry( QRect( 300, 30, 110, 20 ) );

    StopXSCheck = new QCheckBox( MiscOpts, "StopXSCheck" );
    StopXSCheck->setGeometry( QRect( 420, 30, 170, 23 ) );

    PathLabel = new QLabel( MiscOpts, "PathLabel" );
    PathLabel->setGeometry( QRect( 10, 20, 160, 20 ) );

    optionsLayout->addWidget( MiscOpts, 0, 0 );

    groupBox6 = new QGroupBox( options, "groupBox6" );

    NotDelay = new QSpinBox( groupBox6, "NotDelay" );
    NotDelay->setGeometry( QRect( 250, 20, 57, 23 ) );

    NotDelayLabel = new QLabel( groupBox6, "NotDelayLabel" );
    NotDelayLabel->setGeometry( QRect( 210, 20, 39, 18 ) );

    NotFontSizeLabel = new QLabel( groupBox6, "NotFontSizeLabel" );
    NotFontSizeLabel->setGeometry( QRect( 350, 20, 64, 18 ) );

    NotFontSize = new QSpinBox( groupBox6, "NotFontSize" );
    NotFontSize->setGeometry( QRect( 420, 20, 57, 23 ) );
    NotFontSize->setMaxValue( 72 );
    NotFontSize->setMinValue( 1 );

    Notify = new QCheckBox( groupBox6, "Notify" );
    Notify->setGeometry( QRect( 10, 20, 159, 23 ) );

    optionsLayout->addWidget( groupBox6, 1, 0 );

    MPlayerOpts = new QGroupBox( options, "MPlayerOpts" );
    MPlayerOpts->setCheckable( FALSE );

    MPOpts = new QLineEdit( MPlayerOpts, "MPOpts" );
    MPOpts->setGeometry( QRect( 10, 30, 591, 22 ) );

    optionsLayout->addWidget( MPlayerOpts, 2, 0 );
    spacer10 = new QSpacerItem( 20, 80, QSizePolicy::Minimum, QSizePolicy::Expanding );
    optionsLayout->addItem( spacer10, 3, 0 );
    Tab->insertTab( options, QString::fromLatin1("") );

    TabPage = new QWidget( Tab, "TabPage" );
    TabPageLayout = new QGridLayout( TabPage, 1, 1, 11, 6, "TabPageLayout"); 

    VolOpts = new QButtonGroup( TabPage, "VolOpts" );

    UsePCMVol = new QRadioButton( VolOpts, "UsePCMVol" );
    UsePCMVol->setGeometry( QRect( 12, 19, 150, 20 ) );
    UsePCMVol->setChecked( TRUE );

    UseMainVol = new QRadioButton( VolOpts, "UseMainVol" );
    UseMainVol->setGeometry( QRect( 12, 49, 150, 20 ) );

    TabPageLayout->addWidget( VolOpts, 0, 0 );

    aovobox = new QGroupBox( TabPage, "aovobox" );

    textLabel2_2 = new QLabel( aovobox, "textLabel2_2" );
    textLabel2_2->setGeometry( QRect( 10, 60, 86, 20 ) );

    AOCombo = new QComboBox( FALSE, aovobox, "AOCombo" );
    AOCombo->setGeometry( QRect( 100, 20, 105, 31 ) );

    VOCombo = new QComboBox( FALSE, aovobox, "VOCombo" );
    VOCombo->setGeometry( QRect( 100, 60, 105, 31 ) );

    textLabel1_2 = new QLabel( aovobox, "textLabel1_2" );
    textLabel1_2->setGeometry( QRect( 10, 20, 86, 20 ) );

    TabPageLayout->addWidget( aovobox, 0, 1 );
    spacer4 = new QSpacerItem( 20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    TabPageLayout->addItem( spacer4, 0, 3 );

    deintgroup = new QButtonGroup( TabPage, "deintgroup" );

    DeintEnabled = new QCheckBox( deintgroup, "DeintEnabled" );
    DeintEnabled->setGeometry( QRect( 10, 20, 100, 23 ) );
    DeintEnabled->setChecked( TRUE );

    LIRadio = new QRadioButton( deintgroup, "LIRadio" );
    LIRadio->setGeometry( QRect( 10, 110, 150, 23 ) );

    LBRadio = new QRadioButton( deintgroup, "LBRadio" );
    LBRadio->setGeometry( QRect( 10, 140, 110, 23 ) );

    CIRadio = new QRadioButton( deintgroup, "CIRadio" );
    CIRadio->setGeometry( QRect( 10, 80, 150, 23 ) );
    CIRadio->setChecked( FALSE );

    FDRadio = new QRadioButton( deintgroup, "FDRadio" );
    FDRadio->setGeometry( QRect( 8, 49, 160, 23 ) );
    FDRadio->setChecked( TRUE );

    TabPageLayout->addWidget( deintgroup, 0, 2 );
    spacer3 = new QSpacerItem( 20, 130, QSizePolicy::Minimum, QSizePolicy::Expanding );
    TabPageLayout->addItem( spacer3, 1, 1 );
    Tab->insertTab( TabPage, QString::fromLatin1("") );

    colors = new QWidget( Tab, "colors" );
    colorsLayout = new QGridLayout( colors, 1, 1, 11, 6, "colorsLayout"); 

    Colors = new QGroupBox( colors, "Colors" );

    textLabel3 = new QLabel( Colors, "textLabel3" );
    textLabel3->setGeometry( QRect( 220, 20, 20, 17 ) );

    textLabel4 = new QLabel( Colors, "textLabel4" );
    textLabel4->setGeometry( QRect( 290, 20, 20, 17 ) );

    textLabel2 = new QLabel( Colors, "textLabel2" );
    textLabel2->setGeometry( QRect( 150, 20, 16, 17 ) );

    BackgroundColorLabel = new QLabel( Colors, "BackgroundColorLabel" );
    BackgroundColorLabel->setGeometry( QRect( 10, 40, 120, 20 ) );

    ForeColorLabel = new QLabel( Colors, "ForeColorLabel" );
    ForeColorLabel->setGeometry( QRect( 10, 120, 120, 20 ) );

    BaseColorLabel = new QLabel( Colors, "BaseColorLabel" );
    BaseColorLabel->setGeometry( QRect( 10, 80, 80, 20 ) );

    FGLabel = new QLabel( Colors, "FGLabel" );
    FGLabel->setGeometry( QRect( 340, 120, 50, 20 ) );
    FGLabel->setPaletteBackgroundColor( QColor( 0, 0, 0 ) );

    BaseLabel = new QLabel( Colors, "BaseLabel" );
    BaseLabel->setGeometry( QRect( 340, 80, 50, 20 ) );
    BaseLabel->setPaletteBackgroundColor( QColor( 0, 0, 0 ) );

    BGLabel = new QLabel( Colors, "BGLabel" );
    BGLabel->setGeometry( QRect( 340, 40, 50, 20 ) );
    BGLabel->setPaletteBackgroundColor( QColor( 0, 0, 0 ) );

    BackR = new QSpinBox( Colors, "BackR" );
    BackR->setGeometry( QRect( 130, 40, 50, 22 ) );
    BackR->setMaxValue( 255 );

    BackG = new QSpinBox( Colors, "BackG" );
    BackG->setGeometry( QRect( 200, 40, 50, 22 ) );
    BackG->setMaxValue( 255 );

    BackB = new QSpinBox( Colors, "BackB" );
    BackB->setGeometry( QRect( 270, 40, 50, 22 ) );
    BackB->setMaxValue( 255 );

    BaseR = new QSpinBox( Colors, "BaseR" );
    BaseR->setGeometry( QRect( 130, 80, 50, 22 ) );
    BaseR->setMaxValue( 255 );

    BaseG = new QSpinBox( Colors, "BaseG" );
    BaseG->setGeometry( QRect( 200, 80, 50, 22 ) );
    BaseG->setMaxValue( 255 );

    BaseB = new QSpinBox( Colors, "BaseB" );
    BaseB->setGeometry( QRect( 270, 80, 50, 22 ) );
    BaseB->setMaxValue( 255 );

    ForeR = new QSpinBox( Colors, "ForeR" );
    ForeR->setGeometry( QRect( 130, 120, 50, 22 ) );
    ForeR->setMaxValue( 255 );

    ForeG = new QSpinBox( Colors, "ForeG" );
    ForeG->setGeometry( QRect( 200, 120, 50, 22 ) );
    ForeG->setMaxValue( 255 );

    ForeB = new QSpinBox( Colors, "ForeB" );
    ForeB->setGeometry( QRect( 270, 120, 50, 22 ) );
    ForeB->setMaxValue( 255 );

    colorsLayout->addWidget( Colors, 0, 0 );
    Tab->insertTab( colors, QString::fromLatin1("") );

    about = new QWidget( Tab, "about" );
    aboutLayout = new QGridLayout( about, 1, 1, 11, 6, "aboutLayout"); 

    AboutBox = new QGroupBox( about, "AboutBox" );
    AboutBox->setColumnLayout(0, Qt::Vertical );
    AboutBox->layout()->setSpacing( 6 );
    AboutBox->layout()->setMargin( 11 );
    AboutBoxLayout = new QGridLayout( AboutBox->layout() );
    AboutBoxLayout->setAlignment( Qt::AlignTop );

    TitleLabel = new QLabel( AboutBox, "TitleLabel" );

    AboutBoxLayout->addWidget( TitleLabel, 0, 0 );

    aboutLayout->addWidget( AboutBox, 0, 0 );
    Tab->insertTab( about, QString::fromLatin1("") );

    OptionsFormLayout->addMultiCellWidget( Tab, 0, 0, 0, 3 );
    languageChange();
    resize( QSize(640, 417).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( OKButton, SIGNAL( clicked() ), this, SLOT( OKButton_clicked() ) );
    connect( CancelButton, SIGNAL( clicked() ), this, SLOT( CancelButton_clicked() ) );
    connect( BrowseButton, SIGNAL( clicked() ), this, SLOT( BrowseButton_clicked() ) );
    connect( BackR, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( BackG, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( BackB, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( BaseR, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( BaseG, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( BaseB, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( ForeR, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( ForeG, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    connect( ForeB, SIGNAL( valueChanged(int) ), this, SLOT( ColorChanged(int) ) );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
OptionsForm::~OptionsForm()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void OptionsForm::languageChange()
{
    setCaption( tr( "QUI Options" ) );
    CancelButton->setText( tr( "Cancel" ) );
    OKButton->setText( tr( "OK" ) );
    restartrequired->setText( tr( "A restart may be required before some options take effect." ) );
    MiscOpts->setTitle( tr( "Miscellaneous" ) );
    BrowseButton->setText( tr( "Browse..." ) );
    DebugCheck->setText( tr( "Debug Mode" ) );
    QToolTip::add( DebugCheck, tr( "Turn on some extra verbose logging" ) );
    StopXSCheck->setText( tr( "Disable XScreensaver" ) );
    QToolTip::add( StopXSCheck, tr( "Disable XScreensaver during video playback" ) );
    PathLabel->setText( tr( "Default Multimedia Path" ) );
    groupBox6->setTitle( tr( "Notifications" ) );
    NotDelayLabel->setText( tr( "Delay" ) );
    QToolTip::add( NotDelayLabel, tr( "In seconds" ) );
    NotFontSizeLabel->setText( tr( "Font Size" ) );
    Notify->setText( tr( "New File Notification" ) );
    QToolTip::add( Notify, tr( "When enabled, QUI will pop up a small notification each time a new file loads" ) );
    MPlayerOpts->setTitle( tr( "MPlayer Options" ) );
    Tab->changeTab( options, tr( "Options" ) );
    VolOpts->setTitle( tr( "Volume" ) );
    UsePCMVol->setText( tr( "Use PCM Volume" ) );
    UseMainVol->setText( tr( "Use Main Volume" ) );
    aovobox->setTitle( tr( "AO/VO" ) );
    textLabel2_2->setText( tr( "Video Output" ) );
    textLabel1_2->setText( tr( "Audio Output" ) );
    deintgroup->setTitle( tr( "Deinterlacing" ) );
    QToolTip::add( deintgroup, tr( "Automatic deinterlacing of DVD and VCD content" ) );
    DeintEnabled->setText( tr( "Enabled" ) );
    LIRadio->setText( tr( "Linear Interpolation" ) );
    LBRadio->setText( tr( "Linear Blend" ) );
    CIRadio->setText( tr( "Cubic Interpolation" ) );
    FDRadio->setText( tr( "FFMPEG Deinterlace" ) );
    Tab->changeTab( TabPage, tr( "Audio/Video" ) );
    Colors->setTitle( tr( "Colors" ) );
    textLabel3->setText( tr( "G" ) );
    textLabel4->setText( tr( "B" ) );
    textLabel2->setText( tr( "R" ) );
    BackgroundColorLabel->setText( tr( "Background Color" ) );
    ForeColorLabel->setText( tr( "Foreground Color" ) );
    BaseColorLabel->setText( tr( "Base Color" ) );
    FGLabel->setText( QString::null );
    BaseLabel->setText( QString::null );
    BGLabel->setText( QString::null );
    Tab->changeTab( colors, tr( "Color Scheme" ) );
    AboutBox->setTitle( tr( "About" ) );
    TitleLabel->setText( tr( "<p align=\"center\">QUI for MPlayer<br>\n"
"Version: 1.71b<br>\n"
"Copyright (c) 2003-2007 Ben Nemec<br>\n"
"Distributed under the GPL.  See COPYING for more information.<br>\n"
"<br>\n"
"Site: http://qui4mplayer.sourceforge.net<br>\n"
"E-Mail: nemecb@gmail.com</p>" ) );
    Tab->changeTab( about, tr( "About" ) );
}

