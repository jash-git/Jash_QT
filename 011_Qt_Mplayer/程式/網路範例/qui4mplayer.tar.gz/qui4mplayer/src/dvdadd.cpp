/****************************************************************************
** Form implementation generated from reading ui file 'dvdadd.ui'
**
** Created: Thu Oct 26 21:23:35 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "dvdadd.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include "dvdadd.ui.h"

/*
 *  Constructs a DVDAdd as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
DVDAdd::DVDAdd( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "DVDAdd" );
    setMaximumSize( QSize( 32767, 175 ) );
    setFocusPolicy( QDialog::ClickFocus );
    DVDAddLayout = new QGridLayout( this, 1, 1, 11, 6, "DVDAddLayout"); 

    layout8 = new QVBoxLayout( 0, 0, 6, "layout8"); 

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 

    AddDVDButton = new QPushButton( this, "AddDVDButton" );
    AddDVDButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, AddDVDButton->sizePolicy().hasHeightForWidth() ) );
    AddDVDButton->setMinimumSize( QSize( 80, 0 ) );
    AddDVDButton->setAutoDefault( FALSE );
    AddDVDButton->setDefault( FALSE );
    layout7->addWidget( AddDVDButton );

    AddVCDButton = new QPushButton( this, "AddVCDButton" );
    AddVCDButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, AddVCDButton->sizePolicy().hasHeightForWidth() ) );
    AddVCDButton->setMinimumSize( QSize( 80, 0 ) );
    AddVCDButton->setAutoDefault( FALSE );
    AddVCDButton->setDefault( FALSE );
    layout7->addWidget( AddVCDButton );
    layout8->addLayout( layout7 );

    CloseButton = new QPushButton( this, "CloseButton" );
    CloseButton->setAutoDefault( FALSE );
    CloseButton->setDefault( FALSE );
    layout8->addWidget( CloseButton );

    DVDAddLayout->addMultiCellLayout( layout8, 2, 2, 0, 2 );

    TrackBox = new QSpinBox( this, "TrackBox" );
    TrackBox->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)1, 0, 0, TrackBox->sizePolicy().hasHeightForWidth() ) );
    TrackBox->setMaximumSize( QSize( 32767, 30 ) );
    TrackBox->setMaxValue( 1024 );
    TrackBox->setMinValue( 1 );

    DVDAddLayout->addWidget( TrackBox, 1, 1 );

    TrackLabel = new QLabel( this, "TrackLabel" );
    TrackLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, TrackLabel->sizePolicy().hasHeightForWidth() ) );
    TrackLabel->setMaximumSize( QSize( 32767, 30 ) );
    TrackLabel->setAlignment( int( QLabel::AlignCenter ) );

    DVDAddLayout->addMultiCellWidget( TrackLabel, 0, 0, 0, 2 );
    spacer1 = new QSpacerItem( 41, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    DVDAddLayout->addItem( spacer1, 1, 2 );
    spacer2 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    DVDAddLayout->addItem( spacer2, 1, 0 );
    languageChange();
    resize( QSize(192, 163).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( AddDVDButton, SIGNAL( clicked() ), this, SLOT( AddDVDButton_clicked() ) );
    connect( AddVCDButton, SIGNAL( clicked() ), this, SLOT( AddVCDButton_clicked() ) );
    connect( CloseButton, SIGNAL( clicked() ), this, SLOT( CloseButton_clicked() ) );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
DVDAdd::~DVDAdd()
{
    destroy();
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void DVDAdd::languageChange()
{
    setCaption( tr( "Add DVD/VCD Tracks" ) );
    AddDVDButton->setText( tr( "Add DVD" ) );
    AddVCDButton->setText( tr( "Add VCD" ) );
    CloseButton->setText( tr( "Close" ) );
    TrackLabel->setText( tr( "Track:" ) );
}

