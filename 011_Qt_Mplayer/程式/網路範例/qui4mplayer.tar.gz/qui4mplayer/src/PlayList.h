// ***************************************************************************************
// This file copyright 2003 Ben Nemec, distributed under the terms of the GPL, see COPYING
// ***************************************************************************************
#ifndef __PLAYLIST_H
#define __PLAYLIST_H

#include <qobject.h>
#include "pldialog.h"

class PlayList : public QObject
{
   Q_OBJECT
   public:
      PlayList(PLDialog *);
      ~PlayList();
      void Add(QString);
      void Remove(int);
      void Open(QString);
      void SetRandom(bool);
      void SetLoop(bool);
      void SetCurrentName(QString);
      void SetCurrentTime(QString);
      QString GetNextFile();
      QString GetPrevFile();
      QString GetCurrFile();
      QString GetFileAt(int);
      bool isEmpty();
      bool isRandom();
      bool isLoop();
      void CloseEditor();
      void SetPal();
      bool DialogIsActive();
      void SetShown(bool);
      void Hide();
      void Show();
      void SetPos(int, int);
      bool Shown();
      bool isAdding();
      
      // Variables for configuration
      QString defaultdir;
      QPalette pal;

   private:
      QString *files;
      int *done;
      int current, size, filenum, totalused;
      int savex, savey;
      bool *used;
      bool random, loop, shown, adding;
      PLDialog *pld;
      QString filename;  // name of the playlist, not the playing file
      QString path;      // ditto for path
      QString filter;
      QStringList pll;
      bool newselected;
      void refreshPLL();
      bool swap(int, int);
      QString IntToString(int);

   public slots:
      void AddClicked();
      void AddDirClicked();
      void RemoveClicked();
      void ClearList(bool);
      void UpClicked();
      void DownClicked();
      void EditClicked();
      void AddDVD(int);
      void AddVCD(int);
      void AddURL();

   private slots:
      void PlayFileNum(int);
      void SaveList();
      void LoadList();
      void LoadNewList(int);
      void FocusIn();
      void FocusOut();
      void ResetPos();
      void Drop(QDropEvent *);

   signals:
      void DialogDoubleClicked(int);
      void NewPlaylistSelected();
      void NewList();
      void RaiseQUI();
      void NeedMouse();


};
#endif
