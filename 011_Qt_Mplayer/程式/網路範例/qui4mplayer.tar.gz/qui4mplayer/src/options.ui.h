// ***************************************************************************************
// This file copyright 2003 Ben Nemec, distributed under the terms of the GPL, see COPYING
// ***************************************************************************************

/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/

#include <qtabwidget.h>
#include <qfiledialog.h>
#include <qdir.h>
#include <qprocess.h>
#include <iostream>

using namespace std;

bool accept;
QProcess *getaovo;
QStringList mpout;
QString storeao, storevo;

void OptionsForm::init()
{
   accept = false;
   
   getaovo = new QProcess();
   connect(getaovo, SIGNAL(readyReadStdout()), this, SLOT(GetOutput()));
   connect(getaovo, SIGNAL(processExited()), this, SLOT(MPlayerFinished()));
   getaovo->addArgument("mplayer");
   getaovo->addArgument("-ao");
   getaovo->addArgument("help");
   getaovo->addArgument("-vo");
   getaovo->addArgument("help");
   getaovo->start();
}


void OptionsForm::OKButton_clicked()
{
   accept = true;
   hide();
}


void OptionsForm::CancelButton_clicked()
{
   accept = false;
   hide();
}


bool OptionsForm::accepted()
{
   return accept;
}


void OptionsForm::BrowseButton_clicked()
{
   QDir d = QFileDialog::getExistingDirectory(pathEdit->text());
   pathEdit->setText(d.absPath());
}


void OptionsForm::ColorChanged( int dummy )
{
   dummy++;
   BGLabel->setPaletteBackgroundColor(QColor(BackR->value(), BackG->value(), BackB->value()));
   BaseLabel->setPaletteBackgroundColor(QColor(BaseR->value(), BaseG->value(), BaseB->value()));
   FGLabel->setPaletteBackgroundColor(QColor(ForeR->value(), ForeG->value(), ForeB->value()));
}


void OptionsForm::GetOutput()
{
   while (getaovo->canReadLineStdout())
   {
      mpout.append(getaovo->readLineStdout());
   }
}


// Populate the ao and vo dropdowns based on MPlayer's output
void OptionsForm::MPlayerFinished()
{
   bool gettingao = false;
   bool gettingvo = false;
   AOCombo->insertItem("default");
   VOCombo->insertItem("default");
   for (uint i = 0; i < mpout.size(); i++)
   {
      if (gettingao)
      {
         QStringList l = QStringList::split("\t", mpout[i]);
         if (l[0].stripWhiteSpace() != "")
            AOCombo->insertItem(l[0]);
      }
      else if (gettingvo)
      {
         if (mpout[i].find("Available audio output drivers") != -1)
            gettingao = true;
         else
         {
            QStringList l = QStringList::split("\t", mpout[i]);
            if (l[0].stripWhiteSpace() != "")
               VOCombo->insertItem(l[0]);
         }
      }
      else
      {
         if (mpout[i].find("Available video output drivers") != -1)
            gettingvo = true;
      }
   }
   AOCombo->setCurrentText(storeao);
   VOCombo->setCurrentText(storevo);
}


void OptionsForm::Setstoreao( QString val )
{
   storeao = val;
}


void OptionsForm::Setstorevo( QString val )
{
   storevo = val;
}


void OptionsForm::Setdeint( QString d )
{
   DeintEnabled->setChecked(true);
   if (d == "none")
      DeintEnabled->setChecked(false);
   else if (d == "fd")
      FDRadio->setChecked(true);
   else if (d == "ci")
      CIRadio->setChecked(true);
   else if (d == "li")
      LIRadio->setChecked(true);
   else if (d == "lb")
      LBRadio->setChecked(true);
}
