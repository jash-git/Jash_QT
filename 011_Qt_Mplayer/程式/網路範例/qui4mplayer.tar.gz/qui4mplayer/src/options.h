/****************************************************************************
** Form interface generated from reading ui file 'options.ui'
**
** Created: Sun Apr 1 00:14:45 2007
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.6   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef OPTIONSFORM_H
#define OPTIONSFORM_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QPushButton;
class QLabel;
class QTabWidget;
class QWidget;
class QGroupBox;
class QLineEdit;
class QCheckBox;
class QSpinBox;
class QButtonGroup;
class QRadioButton;
class QComboBox;

class OptionsForm : public QDialog
{
    Q_OBJECT

public:
    OptionsForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~OptionsForm();

    QPushButton* CancelButton;
    QPushButton* OKButton;
    QLabel* restartrequired;
    QTabWidget* Tab;
    QWidget* options;
    QGroupBox* MiscOpts;
    QLineEdit* pathEdit;
    QPushButton* BrowseButton;
    QCheckBox* DebugCheck;
    QCheckBox* StopXSCheck;
    QLabel* PathLabel;
    QGroupBox* groupBox6;
    QSpinBox* NotDelay;
    QLabel* NotDelayLabel;
    QLabel* NotFontSizeLabel;
    QSpinBox* NotFontSize;
    QCheckBox* Notify;
    QGroupBox* MPlayerOpts;
    QLineEdit* MPOpts;
    QWidget* TabPage;
    QButtonGroup* VolOpts;
    QRadioButton* UsePCMVol;
    QRadioButton* UseMainVol;
    QGroupBox* aovobox;
    QLabel* textLabel2_2;
    QComboBox* AOCombo;
    QComboBox* VOCombo;
    QLabel* textLabel1_2;
    QButtonGroup* deintgroup;
    QCheckBox* DeintEnabled;
    QRadioButton* LIRadio;
    QRadioButton* LBRadio;
    QRadioButton* CIRadio;
    QRadioButton* FDRadio;
    QWidget* colors;
    QGroupBox* Colors;
    QLabel* textLabel3;
    QLabel* textLabel4;
    QLabel* textLabel2;
    QLabel* BackgroundColorLabel;
    QLabel* ForeColorLabel;
    QLabel* BaseColorLabel;
    QLabel* FGLabel;
    QLabel* BaseLabel;
    QLabel* BGLabel;
    QSpinBox* BackR;
    QSpinBox* BackG;
    QSpinBox* BackB;
    QSpinBox* BaseR;
    QSpinBox* BaseG;
    QSpinBox* BaseB;
    QSpinBox* ForeR;
    QSpinBox* ForeG;
    QSpinBox* ForeB;
    QWidget* about;
    QGroupBox* AboutBox;
    QLabel* TitleLabel;

public slots:
    virtual void OKButton_clicked();
    virtual void CancelButton_clicked();
    virtual bool accepted();
    virtual void BrowseButton_clicked();
    virtual void ColorChanged( int dummy );
    virtual void GetOutput();
    virtual void MPlayerFinished();
    virtual void Setstoreao( QString val );
    virtual void Setstorevo( QString val );
    virtual void Setdeint( QString d );

protected:
    QGridLayout* OptionsFormLayout;
    QSpacerItem* spacer4_2;
    QGridLayout* optionsLayout;
    QSpacerItem* spacer10;
    QGridLayout* TabPageLayout;
    QSpacerItem* spacer4;
    QSpacerItem* spacer3;
    QGridLayout* colorsLayout;
    QGridLayout* aboutLayout;
    QGridLayout* AboutBoxLayout;

protected slots:
    virtual void languageChange();

private:
    bool accept;

private slots:
    virtual void init();

};

#endif // OPTIONSFORM_H
