/*  Marx libvlc 0.9.0 Wrapper v0.0.2 - Alpha Release
    
    
    Copyright (C) 2008  Marx Bitware <support@marxbitware.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

using System;
using System.Collections.Generic;
using System.Text;
using Marx_libvlc_wrapper;

namespace Marx_libvlc_wrapper_test
{
    class Program
    {
        static void Main(string[] args)
        {
            string link = "http://160.79.128.61:7244";
            //string link = "dvd://E:";
            //string link = "dvd://E:@1:1";
            //string link = "dvdsimple://E:";
            //string link = "dvdsimple://E:@1:1";
            //string link = "vcd://E:";
            //string link = "cdda://E:";
            //string link = "cdda://E:@21";
            //string link = "hrd.avi";
            //string link = "test.mp3";


            IntPtr hDT = Win32.GetDesktopWindowHandle();
            string[] argv = new string[] { "-I", "dummy", "--ignore-config" };
            libvlc_exception_struct ex = new libvlc_exception_struct();

            //Create new libvlc instance, media instance from file and media player instance from media
            Marx_libvlc_exception exClass = new Marx_libvlc_exception(ref ex);
            Marx_libvlc_core libvlc_core = new Marx_libvlc_core(argv, ref ex);
            Marx_libvlc_media libvlc_media = new Marx_libvlc_media(libvlc_core.Handle, link, ref ex);
            Marx_libvlc_media_player libvlc_media_player = new Marx_libvlc_media_player(libvlc_media.Handle, ref ex);

            //Dispose of media Handle and force garbage collection
            libvlc_media.Handle.Dispose();
            GC.Collect();
            libvlc_media = null;

            //libvlc_media_player.video_set_parent(libvlc_core.Handle, hDT, ref ex);
            libvlc_media_player.play(ref ex);

            try
            {
                libvlc_media_player.video_set_parent(libvlc_core.Handle, hDT, ref ex);
            }
            catch
            {
                exClass.clear(ref ex);
            }

            //Wait for input (play for a while)
            Console.ReadKey();

            GC.Collect();
            GC.WaitForPendingFinalizers();

            Console.ReadKey();
        }
    }
}
