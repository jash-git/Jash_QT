/*  Marx libvlc 0.9.0 Wrapper v0.0.2 - Alpha Release
    
    
    Copyright (C) 2008  Marx Bitware <support@marxbitware.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

using System;
using System.Runtime.InteropServices;
using System.IO;

namespace Marx_libvlc_wrapper
{
    #region Log Structures

    public struct libvlc_log_message_t
    {
        private uint sizeof_msg;
        private int i_severity;
        private string psz_type;
        private string psz_name;
        private string psz_header;
        private string psz_message;
    }

    public struct libvlc_log_t
    {
        private Marx_libvlc_core_handle p_instance;
        private string p_messages;
    }

    public struct libvlc_log_iterator_t
    {
        string p_messages;
        int i_start;
        int i_pos;
        int i_end;
    }

    #endregion

    class Marx_libvlc_log
    {
        #region Constructor

        Marx_libvlc_log()
        {
        }

        #endregion

        #region Methods

        public uint get_log_verbosity(Marx_libvlc_core_handle libvlc_core_handle, ref libvlc_exception_struct ex)
        {
            return libvlc_get_log_verbosity(libvlc_core_handle, ref ex);
        }

        public void set_log_verbosity(Marx_libvlc_core_handle libvlc_core_handle, uint level, ref libvlc_exception_struct ex)
        {
            libvlc_set_log_verbosity(libvlc_core_handle, level, ref ex);
        }

        public libvlc_log_t open(Marx_libvlc_core_handle libvlc_core_handle, ref libvlc_exception_struct ex)
        {
            return libvlc_log_open(libvlc_core_handle, ref ex);
        }

        public void close(ref libvlc_log_t log_t, ref libvlc_exception_struct ex)
        {
            libvlc_log_close(ref log_t, ref ex);
        }

        public uint count(ref libvlc_log_t log_t, ref libvlc_exception_struct ex)
        {
            return libvlc_log_count(ref log_t, ref ex);
        }

        public void clear(ref libvlc_log_t log_t, ref libvlc_exception_struct ex)
        {
            libvlc_log_clear(ref log_t, ref ex);
        }

        public libvlc_log_iterator_t get_iterator(ref libvlc_log_t log_t, ref libvlc_exception_struct ex)
        {
            return libvlc_log_get_iterator(ref log_t, ref ex);
        }

        public void iterator_free(ref libvlc_log_iterator_t log_iterator_t, ref libvlc_exception_struct ex)
        {
            libvlc_log_iterator_free(ref log_iterator_t, ref ex);
        }

        public int iterator_has_next(ref libvlc_log_iterator_t log_iterator_t, ref libvlc_exception_struct ex)
        {
            return libvlc_log_iterator_has_next(ref log_iterator_t, ref ex);
        }

        public libvlc_log_message_t iterator_next(ref libvlc_log_iterator_t log_iterator_t, ref libvlc_log_message_t log_message_t, ref libvlc_exception_struct ex)
        {
            return libvlc_log_iterator_next(ref log_iterator_t, ref log_message_t, ref ex);
        }

        #endregion

        #region DLL Import

        [DllImport("libvlc")]
        private static extern uint libvlc_get_log_verbosity(Marx_libvlc_core_handle libvlc_core_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_set_log_verbosity(Marx_libvlc_core_handle libvlc_core_handle, uint level, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern libvlc_log_t libvlc_log_open(Marx_libvlc_core_handle libvlc_core_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_log_close(ref libvlc_log_t log_t, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern uint libvlc_log_count(ref libvlc_log_t log_t, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_log_clear(ref libvlc_log_t log_t, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern libvlc_log_iterator_t libvlc_log_get_iterator(ref libvlc_log_t log_t, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_log_iterator_free(ref libvlc_log_iterator_t log_iterator_t, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern int libvlc_log_iterator_has_next(ref libvlc_log_iterator_t log_iterator_t, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern libvlc_log_message_t libvlc_log_iterator_next(ref libvlc_log_iterator_t log_iterator_t, ref libvlc_log_message_t log_message_t, ref libvlc_exception_struct ex);

        #endregion
    }
}
