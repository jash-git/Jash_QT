/*  Marx libvlc 0.9.0 Wrapper v0.0.2 - Alpha Release
    
    
    Copyright (C) 2008  Marx Bitware <support@marxbitware.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

using System;
using System.Runtime.InteropServices;
using System.IO;

namespace Marx_libvlc_wrapper
{
    #region Handle for libvlc_media_handle

    public class Marx_libvlc_media_handle : SafeHandle
    {
        public Marx_libvlc_media_handle()
            : base(IntPtr.Zero, true)
        { }

        public override bool IsInvalid
        {
            get { return handle == IntPtr.Zero; }
        }

        protected override bool ReleaseHandle()
        {
            if (!IsInvalid)
            {
                libvlc_media_release(this);
                handle = IntPtr.Zero;
            }
            return true;
        }

        protected override void Dispose(bool disposing)
        {
            ReleaseHandle();
            base.Dispose(disposing);
        }

        [DllImport("libvlc")]
        private static extern void libvlc_media_release(Marx_libvlc_media_handle libvlc_media_handle);
    }

    #endregion

    public enum libvlc_meta_t
    {
        libvlc_meta_Title, libvlc_meta_Artist, libvlc_meta_Genre, libvlc_meta_Copyright,
        libvlc_meta_Album, libvlc_meta_TrackNumber, libvlc_meta_Description, libvlc_meta_Rating,
        libvlc_meta_Date, libvlc_meta_Setting, libvlc_meta_URL, libvlc_meta_Language,
        libvlc_meta_NowPlaying, libvlc_meta_Publisher, libvlc_meta_EncodedBy, libvlc_meta_ArtworkURL,
        libvlc_meta_TrackID
    }

    public class Marx_libvlc_media
    {
        private Marx_libvlc_media_handle libvlc_media_handle;

        #region Constructor

        public Marx_libvlc_media(Marx_libvlc_core_handle libvlc_core_handle, string filename, ref libvlc_exception_struct ex)
        {
            libvlc_media_handle = libvlc_media_new(libvlc_core_handle, filename, ref ex);
        }

        public Marx_libvlc_media(Marx_libvlc_core_handle libvlc_core_handle, string name, ref libvlc_exception_struct ex, int asNode)
        {
            libvlc_media_handle = libvlc_media_new_as_node(libvlc_core_handle, name, ref ex);
        }

        #endregion

        #region Properties

        public Marx_libvlc_media_handle Handle
        {
            get
            {
                return libvlc_media_handle;
            }
        }

        #endregion

        #region Methods

        public void add_option(string[] options, ref libvlc_exception_struct ex)
        {
            libvlc_media_add_option(libvlc_media_handle, options, ref ex);
        }

        public void retain()
        {
            libvlc_media_retain(libvlc_media_handle);
        }

        public string get_mrl(ref libvlc_exception_struct ex)
        {
            return libvlc_media_get_mrl(libvlc_media_handle, ref ex);
        }

        public Marx_libvlc_media_handle duplicate()
        {
            return libvlc_media_duplicate(libvlc_media_handle);
        }

        public string get_meta(libvlc_meta_t enume, ref libvlc_exception_struct ex)
        {
            return libvlc_media_get_meta(libvlc_media_handle, enume, ref ex);
        }

        public Marx_libvlc_media_list_handle subitems(ref libvlc_exception_struct ex)
        {
            return libvlc_media_subitems(libvlc_media_handle, ref ex);
        }

        public Marx_libvlc_media_handle is_preparsed(ref libvlc_exception_struct ex)
        {
            return libvlc_media_is_preparsed(libvlc_media_handle,  ref ex);
        }
        //TODO: Event Manager


        #endregion

        #region DLL Imports

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_handle libvlc_media_new(Marx_libvlc_core_handle libvlc_core_handle, string mri, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_handle libvlc_media_new_as_node(Marx_libvlc_core_handle libvlc_core_handle, string name, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_media_add_option(Marx_libvlc_media_handle libvlc_media_handle, string[] options, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_media_retain(Marx_libvlc_media_handle libvlc_media_handle);

        [DllImport("libvlc")]
        private static extern string libvlc_media_get_mrl(Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_handle libvlc_media_duplicate(Marx_libvlc_media_handle libvlc_media_handle);

        [DllImport("libvlc")]
        private static extern string libvlc_media_get_meta(Marx_libvlc_media_handle libvlc_media_handle, libvlc_meta_t enume, ref libvlc_exception_struct ex);

        //TODO: libvlc_state

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_list_handle libvlc_media_subitems(Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex);

        //TODO:  libvlc_event_manager

        //TODO:  libvlc_time

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_handle libvlc_media_is_preparsed(Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex);

        //TODO: set_user_data

        //TODO: get_user_data




        #endregion
    }
}
