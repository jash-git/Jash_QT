/*  Marx libvlc 0.9.0 Wrapper v0.0.2 - Alpha Release
    
    
    Copyright (C) 2008  Marx Bitware <support@marxbitware.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

using System;
using System.Runtime.InteropServices;
using System.IO;

namespace Marx_libvlc_wrapper
{
    #region Handle for libvlc_core

    public class Marx_libvlc_core_handle : SafeHandle
    {
        public Marx_libvlc_core_handle()
            : base(IntPtr.Zero, true)
        { }

        public override bool IsInvalid
        {
            get { return handle == IntPtr.Zero; }
        }

        protected override bool ReleaseHandle()
        {
            if (!IsInvalid)
            {
                libvlc_release(this);
                handle = IntPtr.Zero;
            }
            return true;
        }

        protected override void Dispose(bool disposing)
        {
            ReleaseHandle();
            base.Dispose(disposing);
        }

        [DllImport("libvlc")]
        private static extern void libvlc_release(Marx_libvlc_core_handle libvlc_core_handle);
    }

    #endregion

    public class Marx_libvlc_core
    {
        private Marx_libvlc_core_handle libvlc_core_handle;

        #region Constructor

        public Marx_libvlc_core(string[] argv, ref libvlc_exception_struct ex)
        {
            libvlc_core_handle = libvlc_new(argv.Length, argv, ref ex);
        }

        #endregion

        #region Properties

        public Marx_libvlc_core_handle Handle
        {
            get
            {
                return libvlc_core_handle;
            }
        }

        #endregion

        #region Methods

        public int get_vlc_id()
        {
            return libvlc_get_vlc_id(libvlc_core_handle);
        }

        public void release()
        {
            libvlc_release(libvlc_core_handle);
        }

        public void retain()
        {
            libvlc_retain(libvlc_core_handle);
        }

        public void addintf(string instancename, ref libvlc_exception_struct ex)
        {
            libvlc_addintf(libvlc_core_handle, instancename, ref ex);
        }

        public void wait()
        {
            libvlc_wait(libvlc_core_handle);
        }

        public string get_version()
        {
            return libvlc_get_version();
        }

        public string get_compiler()
        {
            return libvlc_get_compiler();
        }

        public string get_changeset()
        {
            return libvlc_get_changeset();
        }

        #endregion

        #region DLL Imports

        [DllImport("libvlc")]
        private static extern Marx_libvlc_core_handle libvlc_new(int argc, string[] args, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern int libvlc_get_vlc_id(Marx_libvlc_core_handle libvlc_core_handle);  //Legacy

        [DllImport("libvlc")]
        private static extern void libvlc_release(Marx_libvlc_core_handle libvlc_core_handle);

        [DllImport("libvlc")]
        private static extern void libvlc_retain(Marx_libvlc_core_handle libvlc_core_handle);

        [DllImport("libvlc")]
        private static extern void libvlc_addintf(Marx_libvlc_core_handle libvlc_core_handle, string instancename, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_wait(Marx_libvlc_core_handle libvlc_core_handle);

        [DllImport("libvlc")]
        private static extern string libvlc_get_version();

        [DllImport("libvlc")]
        private static extern string libvlc_get_compiler();

        [DllImport("libvlc")]
        private static extern string libvlc_get_changeset();

        #endregion
    }
}
