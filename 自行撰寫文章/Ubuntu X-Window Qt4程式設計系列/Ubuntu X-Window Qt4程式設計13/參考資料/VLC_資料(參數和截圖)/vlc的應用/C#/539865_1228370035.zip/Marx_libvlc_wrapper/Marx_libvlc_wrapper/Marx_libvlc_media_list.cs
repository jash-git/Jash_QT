/*  Marx libvlc 0.9.0 Wrapper v0.0.2 - Alpha Release
    
    
    Copyright (C) 2008  Marx Bitware <support@marxbitware.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

using System;
using System.Runtime.InteropServices;
using System.IO;

namespace Marx_libvlc_wrapper
{
    #region Handle for libvlc_media_list

    public class Marx_libvlc_media_list_handle : SafeHandle
    {
        public Marx_libvlc_media_list_handle()
            : base(IntPtr.Zero, true)
        { }

        public override bool IsInvalid
        {
            get { return handle == IntPtr.Zero; }
        }

        protected override bool ReleaseHandle()
        {
            if (!IsInvalid)
            {
                libvlc_media_list_release(this);
                handle = IntPtr.Zero;
            }
            return true;
        }

        protected override void Dispose(bool disposing)
        {
            ReleaseHandle();
            base.Dispose(disposing);
        }

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_release(Marx_libvlc_media_list_handle libvlc_media_list_handle);
    }

    #endregion

    public class Marx_libvlc_media_list
    {         
        private Marx_libvlc_media_list_handle libvlc_media_list_handle;

        #region Constructor

        public Marx_libvlc_media_list(Marx_libvlc_core_handle libvlc_core_handle, ref libvlc_exception_struct ex)
        {
            libvlc_media_list_handle = libvlc_media_list_new(libvlc_core_handle, ref ex);
        }

        #endregion

        #region Properties

        public Marx_libvlc_media_list_handle Handle
        {
            get
            {
                return libvlc_media_list_handle;
            }
        }

        #endregion

        #region Methods

        public void list_retain()
        {
            libvlc_media_list_retain(libvlc_media_list_handle);
        }

        public void set_media(Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex)
        {
            libvlc_media_list_set_media(libvlc_media_list_handle, libvlc_media_handle, ref ex);
        }

        public Marx_libvlc_media_handle media(ref libvlc_exception_struct ex)
        {
            return libvlc_media_list_media(libvlc_media_list_handle, ref ex);
        }

        public void add_media(Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex)
        {
            libvlc_media_list_add_media(libvlc_media_list_handle, libvlc_media_handle, ref ex);
        }

        public void insert_media(Marx_libvlc_media_handle libvlc_media_handle, int SOMETHING, ref libvlc_exception_struct ex)
        {
            libvlc_media_list_insert_media(libvlc_media_list_handle, libvlc_media_handle, SOMETHING, ref ex);
        }

        public void remove_index(int index, ref libvlc_exception_struct ex)
        {
            libvlc_media_list_remove_index(libvlc_media_list_handle, index, ref ex);
        }

        public int count(ref libvlc_exception_struct ex)
        {
           return libvlc_media_list_count(libvlc_media_list_handle, ref ex);
        }

        public Marx_libvlc_media_handle item_at_index(int index, ref libvlc_exception_struct ex)
        {
           return libvlc_media_list_item_at_index(libvlc_media_list_handle, index, ref ex);
        }

        public int index_of_item(Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex)
        {
            return libvlc_media_list_index_of_item(libvlc_media_list_handle, libvlc_media_handle, ref ex);
        }

        public int is_readonly()
        {
            return libvlc_media_list_is_readonly(libvlc_media_list_handle);
        }

        public void llock()
        {
            libvlc_media_list_lock(libvlc_media_list_handle);
        }

        public void lunlock()
        {
            libvlc_media_list_unlock(libvlc_media_list_handle);
        }

        #endregion

        #region DLL Imports

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_list_handle libvlc_media_list_new(Marx_libvlc_core_handle libvlc_core_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_release(Marx_libvlc_media_list_handle libvlc_media_list_handle);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_retain(Marx_libvlc_media_list_handle libvlc_media_list_handle);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_set_media(Marx_libvlc_media_list_handle libvlc_media_list_handle, Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_handle libvlc_media_list_media(Marx_libvlc_media_list_handle libvlc_media_list_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_add_media(Marx_libvlc_media_list_handle libvlc_media_list_handle, Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_insert_media(Marx_libvlc_media_list_handle libvlc_media_list_handle, Marx_libvlc_media_handle libvlc_media_handle, int SOMETHING, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_remove_index(Marx_libvlc_media_list_handle libvlc_media_list_handle, int index, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern int libvlc_media_list_count(Marx_libvlc_media_list_handle libvlc_media_list_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_handle libvlc_media_list_item_at_index(Marx_libvlc_media_list_handle libvlc_media_list_handle, int index, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern int libvlc_media_list_index_of_item(Marx_libvlc_media_list_handle libvlc_media_list_handle, Marx_libvlc_media_handle libvlc_media_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern int libvlc_media_list_is_readonly(Marx_libvlc_media_list_handle libvlc_media_list_handle);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_lock(Marx_libvlc_media_list_handle libvlc_media_list_handle);

        [DllImport("libvlc")]
        private static extern void libvlc_media_list_unlock(Marx_libvlc_media_list_handle libvlc_media_list_handle);
        //private static extern libvlc_media_list_view_t * 	libvlc_media_list_flat_view (VlcMediaListHandle libvlc_media_list_new, libvlc_exception_t *)
        //private static extern libvlc_media_list_view_t * 	libvlc_media_list_hierarchical_view (VlcMediaListHandle libvlc_media_list_new, libvlc_exception_t *)
        //private static extern libvlc_media_list_view_t * 	libvlc_media_list_hierarchical_node_view (VlcMediaListHandle libvlc_media_list_new, libvlc_exception_t *)
        //private static extern libvlc_event_manager_t * 	libvlc_media_list_event_manager (VlcMediaListHandle libvlc_media_list_new, libvlc_exception_t *)
        #endregion
    }
}
