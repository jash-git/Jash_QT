/*  Marx libvlc 0.9.0 Wrapper v0.0.2 - Alpha Release
    
    
    Copyright (C) 2008  Marx Bitware <support@marxbitware.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 */

using System;
using System.Runtime.InteropServices;
using System.IO;

namespace Marx_libvlc_wrapper
{
    #region Handle for libvlc_media_library

    public class Marx_libvlc_media_library_handle : SafeHandle
    {
        public Marx_libvlc_media_library_handle()
            : base(IntPtr.Zero, true)
        { }

        public override bool IsInvalid
        {
            get { return handle == IntPtr.Zero; }
        }

        protected override bool ReleaseHandle()
        {
            if (!IsInvalid)
            {
                libvlc_media_library_release(this);
                handle = IntPtr.Zero;
            }
            return true;
        }

        protected override void Dispose(bool disposing)
        {
            ReleaseHandle();
            base.Dispose(disposing);
        }

        [DllImport("libvlc")]
        private static extern void libvlc_media_library_release(Marx_libvlc_media_library_handle libvlc_media_library_handle);
    }

    #endregion

    public class Marx_libvlc_media_library
    {
        private Marx_libvlc_media_library_handle libvlc_media_library_handle;

        #region Constructor

        public Marx_libvlc_media_library()
        {
        }
        #endregion

        #region Properties

        public Marx_libvlc_media_library_handle Handle
        {
            get
            {
                return libvlc_media_library_handle;
            }
        }

        #endregion

        #region Methods

        public void retain()
        {
            libvlc_media_library_retain(libvlc_media_library_handle);
        }

        public void load(ref libvlc_exception_struct ex)
        {
            libvlc_media_library_load(libvlc_media_library_handle, ref ex);
        }

        public void save(ref libvlc_exception_struct ex)
        {
            libvlc_media_library_save(libvlc_media_library_handle, ref ex);
        }

        public Marx_libvlc_media_list_handle media_list(ref libvlc_exception_struct ex)
        {
            return libvlc_media_library_media_list(libvlc_media_library_handle, ref ex);
        }

        #endregion

        #region DLL Imports
        
        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_library_handle libvlc_media_library_new (Marx_libvlc_core_handle libvlc_core_handle, ref libvlc_exception_struct ex);
        
        [DllImport("libvlc")]
        private static extern void libvlc_media_library_retain(Marx_libvlc_media_library_handle libvlc_media_library_handle);

        [DllImport("libvlc")]
        private static extern void libvlc_media_library_load(Marx_libvlc_media_library_handle libvlc_media_library_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern void libvlc_media_library_save(Marx_libvlc_media_library_handle libvlc_media_library_handle, ref libvlc_exception_struct ex);

        [DllImport("libvlc")]
        private static extern Marx_libvlc_media_list_handle libvlc_media_library_media_list(Marx_libvlc_media_library_handle libvlc_media_library_handle, ref libvlc_exception_struct ex);

        #endregion
    }
}
