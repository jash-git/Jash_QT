#ifndef LAUNCHERPLUGIN_H
#define LAUNCHERPLUGIN_H

#include <QObject>
#include <QtPlugin>
#include <QSettings>
#include <QString>
#include <QProcess>
#include <QDebug>
#include "PluginInterface.h"

class LauncherPlugin : public QObject, PluginInterface
{
    Q_OBJECT
    Q_INTERFACES(PluginInterface)
public:
    explicit LauncherPlugin();

    /**
    * Returns the name of the plugin
    */
    QString Name() const;

    /**
    * Returns the description of the plugin
    */
    QString Description() const;

    /**
    * Returns the status of the plugin
    */
    QString Status() const;

    /**
    * Tells the plugin that it is being installed
    * The plugin should perform any installtion code
    */
    QString Install() const;

    /**
    * Tells the plugin that it is being uninstalled
    * The plugin should perform any uninstalltion code
    */
    QString Uninstall() const;

    /**
    * Called when the plugin is started
    */
    QString Start() const;

    /**
    * Called when the plugin is stopped
    */
    QString Stop() const;

    /**
    * Returns a QStringList of available commands
    */
    QStringList Commands() const;

    /**
    * Askes the plugin to execute a command and returns the results
    * @param command The command to execute
    * @param args A list of arguments for the command
    */
    QString Exec(QString command, QStringList args) const;

public slots:
    /**
    * Called when the Process has an error
    * @param error The error
    */
    void error(QProcess::ProcessError error);

    /**
    * Called when the Process has an error
    * @param exitCode The exit code
    * @param exitStatus The exit status
    */
    void finished(int exitCode, QProcess::ExitStatus exitStatus);

    /**
    * Called the process writes to the standard error channel
    */
    void readyReadStandardError();

    /**
    * Called the process writes to the standard output channel
    */
    void readyReadStandardOutput();

    /**
    * Called the process is started
    */
    void started();

    /**
    * Called when the Process state changes
    * @param newState The new state
    */
    void stateChanged(QProcess::ProcessState newState);

private:
    QSettings *Settings;
    QProcess *Process;
    bool isRunning;
};

#endif // LAUNCHERPLUGIN_H
