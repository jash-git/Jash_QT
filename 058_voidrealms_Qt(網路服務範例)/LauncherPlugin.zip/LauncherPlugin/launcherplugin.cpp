#include "launcherplugin.h"

Q_EXPORT_PLUGIN2( LauncherPlugin, LauncherPlugin )

LauncherPlugin::LauncherPlugin()
{
    isRunning = false;
    Settings = new QSettings();
    Process = new QProcess();
    connect(Process,SIGNAL(error(QProcess::ProcessError)),this,SLOT(error(QProcess::ProcessError)));
    connect(Process,SIGNAL(finished(int,QProcess::ExitStatus)),this,SLOT(finished(int,QProcess::ExitStatus)));
    connect(Process,SIGNAL(readyReadStandardError()), this, SLOT(readyReadStandardError()));
    connect(Process,SIGNAL(readyReadStandardOutput()), this, SLOT(readyReadStandardOutput()));
    connect(Process,SIGNAL(started()), this, SLOT(started()));
    connect(Process,SIGNAL(stateChanged(QProcess::ProcessState)),this, SLOT(stateChanged(QProcess::ProcessState)));
}

QString LauncherPlugin::Name() const
{
    return "Launcher Plugin";
}

QString LauncherPlugin::Description() const
{
    return "Launches other applications";
}

QString LauncherPlugin::Status() const
{
    QString status = "Unknown";
    if(isRunning)
    {
        status = "Running";
    }
    else
    {
        status = "Not Running";
    }
    return status;
}

QString LauncherPlugin::Install() const
{
    return "Complete";
}

QString LauncherPlugin::Uninstall() const
{
    return "Complete";
}

QString LauncherPlugin::Start() const
{

    Settings->beginGroup(Name());
    QVariant value = Settings->value("app","none");
    Settings->endGroup();

    if(value.toString() != "none")
    {
        Process->start("notepad");
        Process->waitForStarted(5000);
    }
    return Status();
}

QString LauncherPlugin::Stop() const
{
    if(isRunning)
    {
        Process->close();
    }

    return Status();
}

QStringList LauncherPlugin::Commands() const
{
    QStringList List;
    List.append("setapp (path to application or 'none')");

    return List;
}

QString LauncherPlugin::Exec(QString command, QStringList args) const
{
    if(args.count() == 0)
    {
        return "Error: please include arguments!";
    }

    if(command == "setapp")
    {
        Settings->beginGroup(Name());
        Settings->setValue("app", args.at(0));
        Settings->endGroup();
    }
    return "Application set to: " + command;
}

void LauncherPlugin::error(QProcess::ProcessError error)
{
    //qDebug() << "Process Error: " << error;
}

void LauncherPlugin::finished(int exitCode, QProcess::ExitStatus exitStatus)
{
    //qDebug() << "Process Finished: " << exitStatus;
}

void LauncherPlugin::readyReadStandardError()
{
    //qDebug() << "Process readyReadStandardError";
}

void LauncherPlugin::readyReadStandardOutput()
{
    //qDebug() << "Process readyReadStandardOutput";
}

void LauncherPlugin::started()
{
    //qDebug() << "Process Started";
}

void LauncherPlugin::stateChanged(QProcess::ProcessState newState)
{
    if(newState == QProcess::NotRunning)
    {
        isRunning = false;
    }

    if(newState == QProcess::Running)
    {
        isRunning = true;
    }
}

