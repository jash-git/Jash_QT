#include <QtCore/QCoreApplication>
#include <QString>
#include <QStringList>
#include <QDebug>

#include <IOStream>
#include "VDrives.h"
#include "VQTConvert.h"

using namespace voidrealms::win32;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //Get the logical drives
    QStringList mList = VDrives::getLogicalDrives();
    qDebug() << "Total Drives: " <<  mList.count();

    //Loop through the logical drives
    for (int i = 0; i < mList.size(); ++i)
    {
        VDrives mDrive(mList.at(i));
        qDebug() << "";
        qDebug() << "Name: " <<  mDrive.Name();
        qDebug() << " - Label: " <<  mDrive.Label();
        qDebug() << " - FileSystem: " <<  mDrive.FileSystem();
        qDebug() << " - DriveType: " <<  mDrive.DriveType();
        qDebug() << " - DriveTypeInt: " <<  mDrive.DriveTypeInt();
        qDebug() << " - Free bytes: " << mDrive.FreeBytesAvailable();
        qDebug() << " - Total Bytes: " << mDrive.TotalNumberOfBytes();
        qDebug() << " - Total Free Bytes: " << mDrive.TotalNumberOfFreeBytes();
        qDebug() << "";
    }

    qDebug() << "Done";

    return a.exec();
}
