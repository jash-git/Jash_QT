/*
Wrapper for the Windows Logocal Drives
Version: 1.0
Modified on: 8-20-2009
Created with: QT 4.5 and QT Creator 1.2
Tested on: Windows XP SP3
Bryan Cairns
*/

#ifndef VDRIVES_H
#define VDRIVES_H

#include "windows.h"
#include <QString>
#include <QStringList>

namespace voidrealms
{
    namespace win32
    {

        class VDrives
        {

        private:
            QString mDrive;
            QString mType;
            int mTypeInt;
            QString mLabel;
            QString mFileSystem;
            long mTotalSpace;
            long mFreeSpace;
            long mUsedSpace;
            quint64 mFreeBytesAvailable;
            quint64 mTotalNumberOfBytes;
            quint64 mTotalNumberOfFreeBytes;

            //Load the drives information
            void LoadDriveInfo();

        public:

            //Returns a QStringList filled with Logical Drive Names
            QStringList static getLogicalDrives();

            //Default constructor
            VDrives(QString LogicalDrive);

            //Returns a QString representing the drive type
            QString DriveType();

            //Returns a Int representing the drive type
            int DriveTypeInt();

            //Returns a QString representing the drive label
            QString Label();

            //Returns a QString representing the drive name
            QString Name();

            //Returns a QString representing the drive file system
            QString FileSystem();

            //Returns a quint64 with the number of free bytes available
            quint64 FreeBytesAvailable();

            //Returns a quint64 with the total size in bytes
            quint64 TotalNumberOfBytes();

            //Returns a quint64 with the number of free bytes
            quint64 TotalNumberOfFreeBytes();
        };



    } //end voidrealms::win32 namespace
} //end voidrealms namespace
#endif // VDRIVES_H
