#ifndef TEST_H
#define TEST_H

#include <QSettings>
#include <QString>
#include <QDir>

class Test : public QSettings
{
    Q_OBJECT
public:
    explicit Test(QObject *parent = 0);

    /*!
    * Gets the application path
    */
    QString ApplicationPath();

    /*!
    * Gets the application QDir
    */
    QDir ApplicationDir();

signals:

public slots:

};

#endif // TEST_H
