#include "tcpclient.h"

TCPClient::TCPClient(int SocketDescriptor,QObject *parent) :
    QObject(parent)
{
    SessionID = SocketDescriptor;
    TransferFilename = QString::null;
    TransferLength = 0;
    TransferedAmount = 0;
    Transfermode = Command;

    Socket = new QTcpSocket(this);
    if(!Socket->setSocketDescriptor(SessionID))
    {
        qDebug() << SessionID << " Error binding socket";
        return;
    }

    //connect the signals
    connect(Socket,SIGNAL(readyRead()),this,SLOT(SocketReadyRead()),Qt::DirectConnection);
    connect(Socket,SIGNAL(disconnected()),this,SLOT(SocketDisconnected()),Qt::DirectConnection);

    qDebug() << SessionID << " session Connected";
}

void TCPClient::SocketReadyRead()
{
    QMetaObject metaObject = this->staticMetaObject;
    QMetaEnum metaEnum = metaObject.enumerator(metaObject.indexOfEnumerator("FileMode"));

    //Idenitfy and handle the command
    switch(metaEnum.value(Transfermode))
    {
    case Command: // Command Mode
        ProcessCommand();
        break;

    case Upload: // Upload Mode
        UploadBytes();
        break;

    case Download: // Download Mode
        qDebug() << "Download Mode";
        break;
    }
}

void TCPClient::ProcessCommand()
{
    //Keep adding to the command buffer
    QByteArray Data = Socket->readAll();

    CommandBuffer.append(Data);

    //Check to see if the CommandBuffer has a command
    if(CommandBuffer.endsWith('\n'))
    {
        //Process the command
        CommandRequest Request;
        Request.FromString(CommandBuffer.trimmed());

        qDebug() << SessionID << " Buffer: " << CommandBuffer.trimmed();

        emit RequestReady(Request);
        CommandBuffer.clear();
    }
}

void TCPClient::SocketDisconnected()
{
    qDebug() << SessionID << " session disconnected";

    //Cleanup
    Socket->deleteLater();
    this->deleteLater();
}

void TCPClient::SendResponse(QByteArray data)
{
    //Send the data to the client
    Socket->write(data);
}

void TCPClient::ResponseReady(CommandResponse &Reponse)
{
    //Send the data to the client
    Socket->write(Reponse.ToString().toAscii());
}

void TCPClient::CloseSocket()
{
    Socket->close();
}

void TCPClient::UploadFile(QString Filename, qint64 Length)
{
    TransferFilename = Filename;
    TransferLength = Length;
    Transfermode = Upload;

    //Wait for data from the client
}

void TCPClient::DownloadFile(QString Filename)
{
    try
    {
        QFile file(Filename);
        TransferFilename = Filename;
        TransferLength = file.size();
        Transfermode = Download;

        if(file.open(QFile::ReadOnly))
        {
            //Send the client the file
            while (!file.atEnd()) {
                Socket->write(file.read(1024 *5));
            }
            file.close();
            ResetTransferState();
            emit DownloadComplete("Transfer was successful");
        }
        else
        {
            ResetTransferState();
            emit DownloadComplete("Download Error " + file.errorString());
        }


    }
    catch(...)
    {
        emit DownloadComplete("An error occured while sending file");
    }
}

void TCPClient::UploadBytes()
{
    QByteArray Buffer = Socket->readAll();
    TransferedAmount += Buffer.size();

    QFile file(TransferFilename);

    if(file.open(QFile::Append))
    {
        //Append the data to the file
        file.write(Buffer);
        file.close();
        if(TransferedAmount >= TransferLength)
        {
            //Transfer is complete
            ResetTransferState();
            emit DownloadComplete("Upload Complete");
        }
    }
    else
    {
        //stop the transfer and give the client back the error
        ResetTransferState();
        emit DownloadComplete("Upload Error " + file.errorString());
    }
}

void TCPClient::ResetTransferState()
{
    TransferFilename = QString::null;
    TransferLength = 0;
    TransferedAmount = 0;
    Transfermode = Command;
}

