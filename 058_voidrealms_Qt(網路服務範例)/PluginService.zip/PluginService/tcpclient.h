/*
* TCPClient
* Represents a connected TCPClient
*
*
* This class uses the following
* CommandManager
*
* Bryan Cairns - 2011
* All rights reserved.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
* PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <QDebug>
#include <QByteArray>
#include <QFile>
#include <QMetaEnum>
#include "pluginmanager.h"
#include "commandmanager.h"
#include "commandrequest.h"
#include "commandresponse.h"

class TCPClient : public QObject
{
    Q_OBJECT
    Q_ENUMS(FileMode)
public:
    explicit TCPClient(int SocketDescriptor,QObject *parent = 0);
    enum FileMode{Command,Upload,Download};
signals:
    /*!
    * Signal to the Command Manager that a rquest is ready
    * @param Request The request data
    */
    void RequestReady(CommandRequest &Request);

    /*!
    * Signal to the Command Manager that the file transfer is complete
    * @param Status The Status
    */
    void UploadComplete(QString Status);

    /*!
    * Signal to the Command Manager that the file transfer is complete
    * @param Status The Status
    */
    void DownloadComplete(QString Status);

public slots:
    /*!
    * Gets the request from the client
    */
    void SocketReadyRead();

    /*!
    * Slot for the TCP socket disconnected() signal
    */
    void SocketDisconnected();

    /*!
    * Sends the response to the client socket
    * @param data The QByteArray to send
    */
    void SendResponse(QByteArray data);

    /*!
    * Called when the CommandManager has data to process
    * @param data The QByteArray to send
    */
    void ResponseReady(CommandResponse &Reponse);

    /*!
    * Closes the socket
    */
    void CloseSocket();

    /*!
    * Called when the client is uploading a file
    * @param filename The name of the file to upload
    * @param Length The size of the file to upload
    */
    void UploadFile(QString Filename,qint64 Length);

    /*!
    * Called when the client is downloading a file
    * @param filename The name of the file to upload
    */
    void DownloadFile(QString Filename);

private:


    int SessionID;
    QTcpSocket *Socket;
    QString CommandBuffer;
    QString TransferFilename;
    qint64 TransferLength;
    qint64 TransferedAmount;
    FileMode Transfermode;

    /*!
    * Called when the client is in upload mode
    */
    void UploadBytes();

    /*!
    * Resets the transfer state and all the variables
    */
    void ResetTransferState();

    /*!
    * Processes incomming commands
    */
    void ProcessCommand();
};

#endif // TCPCLIENT_H
