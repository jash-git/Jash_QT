#include "test.h"

Test::Test(QObject *parent) :
    QSettings(ApplicationPath() + "/Settings.ini",QSettings::IniFormat,parent)
{
}

QString Test::ApplicationPath()
{
    return QDir::currentPath();
}

QDir Test::ApplicationDir()
{
    QDir path(QDir::currentPath());
    return path;
}
