#include <QtCore/QCoreApplication>
#include <QDebug>
#include <QString>
#include "VServices.h"

using namespace voidrealms::win32;

void Do_ListServices()
{
    VServices mManager;
    QStringList mList = mManager.getServicesStringList();

    for (int i = 0; i < mList.size(); ++i)
    {
        QString mName = mList.at(i);
        qDebug() << "Service: " << mName;
        qDebug() << " - Display = " << mManager.getDisplayName(mName);
        qDebug() << " - Status = " << mManager.getStatus(mName);
        qDebug() << " - Startup = " << mManager.getStartType(mName);
    }
}

void Do_StartService()
{
    VServices mManager;

    //Start the Alerter service with arquments
    QStringList mArgs;
    mArgs.append("myarg1");
    mArgs.append("myarg2");
    mArgs.append("myarg3");

    mManager.Start("Alerter",mArgs);
}

void Do_StopService()
{
    VServices mManager;

    //Stop the Alerter service
    mManager.Stop("Alerter");
}

void Do_DeleteService()
{
    VServices mManager;

    //Delete a service
    //mManager.ServiceDelete("TestService");
}

void Do_CreateService()
{
    VServices mManager;

    //Create a entry for a windows service
    //mManager.ServiceCreate("TestService","My Service Name","My Service Description",VServices::StartType_Manual,"C:\\testservice\\TestService.exe","LocalSystem", "");
}

void Do_StartTypeService()
{
    VServices mManager;

    //Set the start type for a service
    mManager.setStartType("Alerter",VServices::StartType_Manual);
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //List the services
    Do_ListServices();

    //Set the start type
    Do_StartTypeService();

    //Stop the service
    Do_StopService();

    //Start the service
    Do_StartService();

    //Delete a service
    Do_DeleteService();

    //Create a service entry
    Do_CreateService();

    qDebug() << "Done";
    return a.exec();
}
