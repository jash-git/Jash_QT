#include "ftpplugin.h"
Q_EXPORT_PLUGIN2( FTPPlugin, FTPPlugin )

FTPPlugin::FTPPlugin()
{
    Server = new FTPServer();
}

QString FTPPlugin::Name() const
{
    return "FTP Server Plugin";
}

QString FTPPlugin::Description() const
{
    return "Allows remote file transfers.";
}

QString FTPPlugin::Status() const
{
    QString ret = "Unknown";

    if(Server->isListening())
    {
        ret = "Started";
    }
    else
    {
        ret = "Stopped";
    }

    return ret;
}

QString FTPPlugin::Install() const
{
    return "Complete";
}

QString FTPPlugin::Uninstall() const
{
    return "Complete";
}

QString FTPPlugin::Start() const
{
    AppSettings Settings;

    Settings.beginGroup(Settings.DefaultGroup());
    QVariant vPort = Settings.value("port",21);
    Settings.endGroup();

    Server->StartServer(vPort.toUInt());

    return Status();
}

QString FTPPlugin::Stop() const
{
    Server->StopServer();

    return Status();
}

QStringList FTPPlugin::Commands() const
{
    QStringList List;
    List.append("setusername (username) - Sets the username for the ftp server.");
    List.append("setpassword (password) - Sets the password for the ftp server.");
    List.append("setport (port) - Sets the port to run the telnet server on.");
    List.append("setanon (true / false) - Sets the anonymous mode.");
    List.append("setroot (path) - Sets the root path.");
    List.append("setip (ipaddress) - Sets the ip address.");
    return List;
}

QString FTPPlugin::Exec(QString command, QStringList args) const
{
    QString lCommand = command.toLower();
    QString ret = "not implimented";

    if(args.count() <= 0)
    {
        return "Please include an argument.";
    }

    QString arg = args.at(0).trimmed();
    AppSettings Settings;
    Settings.beginGroup(Settings.DefaultGroup());

    //Set the username
    if(lCommand == "setusername")
    {
        Settings.setValue("username",arg);
        ret = "Username set.";
    }

    //Set the password
    if(lCommand == "setpassword")
    {
        Settings.setValue("password",Settings.HashPassword(arg));
        ret = "Password set.";
    }

    //Set the ipaddress
    if(lCommand == "setip")
    {
        Settings.setValue("ipaddress",arg);
        ret = "IP Address set.";
    }

    //Set the Root Path
    if(lCommand == "setroot")
    {
        Settings.setValue("rootpath",arg);
        ret = "Root Path set.";
    }

    //Set the Port
    if(lCommand == "setport")
    {
        Settings.setValue("port",arg);
        ret = "Port set.";
    }


    //Set the Anonymous
    if(lCommand == "setanon")
    {
        Settings.setValue("anonymous",arg);
        ret = "Anonymous set.";
    }

    Settings.endGroup();

    return ret;
}

