#include "tcpclient.h"

TCPClient::TCPClient(int SocketDescriptor,QObject *parent) :
    QObject(parent)
{

    Authenticated = false;
    SessionID = SocketDescriptor;

    Socket = new QTcpSocket(this);
    if(!Socket->setSocketDescriptor(SessionID))
    {
        qDebug() << SessionID << " Error binding socket";
        return;
    }

    //connect the signals
    connect(Socket,SIGNAL(readyRead()),this,SLOT(SocketReadyRead()),Qt::DirectConnection);
    connect(Socket,SIGNAL(disconnected()),this,SLOT(SocketDisconnected()),Qt::DirectConnection);

    qDebug() << SessionID << " session Connected";

    //Create a new process for them
    Process = new  QProcess(this);
    Process->setReadChannelMode(QProcess::MergedChannels);
    connect(Process,SIGNAL(readyReadStandardOutput()), this,SLOT(ProcessReadyRead()));
    connect(Process,SIGNAL(readyReadStandardError()), this,SLOT(ProcessReadyRead()));
    connect(Process,SIGNAL(readyRead()), this,SLOT(ProcessReadyRead()));

    Banner = "Enter a password: ";
    SendResponse(Banner.toAscii());
}

void TCPClient::SocketReadyRead()
{

    //Keep adding to the command buffer
    QByteArray Data = Socket->readAll();

    CommandBuffer.append(Data);

    //Check to see if the CommandBuffer has a command
    if(CommandBuffer.endsWith('\n'))
    {
        //Process the command

        if(!Authenticated)
        {
            //check the password
            QString ClientPassword = CommandBuffer.trimmed();

            QSettings Settings;
            Settings.beginGroup("Telnet Plugin");
            QVariant vServerPassword = Settings.value("password","");
            Settings.endGroup();

            QString ServerPassword = vServerPassword.toString();

            //Check to see if they configured a password
            if(ServerPassword == "")
            {
                //Some password is better then none
                ServerPassword = "password";
                QByteArray serverhash = QCryptographicHash::hash(ServerPassword.toAscii(),QCryptographicHash::Sha1);
                ServerPassword = QString(serverhash.toBase64());
            }

            //see if the passwords match
            QByteArray hash = QCryptographicHash::hash(ClientPassword.toAscii(),QCryptographicHash::Sha1);
            QString hashedpass = QString(hash.toBase64());

            CommandBuffer.clear();

            if(hashedpass == ServerPassword)
            {
                Authenticated = true;
                StartProcess();
            }
            else
            {
                SendResponse(Banner.toAscii());
            }
        }
        else
        {
            //process the command
            //See if they are changing directories
            if(CommandBuffer.toUpper().startsWith("CD "))
            {
                QString NewDir = CommandBuffer.mid(3).trimmed();

                QDir dir(NewDir);
                if(dir.exists())
                {
                    Process->setWorkingDirectory(NewDir);
                    Process->close();
                    StartProcess();
                }
            }

            Process->write(CommandBuffer.toAscii());
            Process->waitForBytesWritten();

            qDebug() << SessionID << " Buffer: " << CommandBuffer.trimmed();
            CommandBuffer.clear();
        }
    }
}

void TCPClient::SocketDisconnected()
{
    qDebug() << SessionID << " session disconnected";

    Process->close();
    Process->deleteLater();

    //Cleanup
    Socket->deleteLater();
    this->deleteLater();
}

void TCPClient::SendResponse(QByteArray data)
{
    //Send the data to the client
    Socket->write(data);
}

void TCPClient::ProcessReadyRead()
{
    //Read from the process and write to the socket
    SendResponse(Process->readAll());
}

void TCPClient::StartProcess()
{
#ifdef Q_WS_WIN
    Process->start("cmd");
#endif

#ifdef Q_WS_X11
    Process->start("bash");
#endif

#ifdef Q_WS_MAC
    Process->start("bash");
#endif
}

int TCPClient::ID()
{
   return SessionID;
}

void TCPClient::CloseSocket()
{
    Socket->close();
}
