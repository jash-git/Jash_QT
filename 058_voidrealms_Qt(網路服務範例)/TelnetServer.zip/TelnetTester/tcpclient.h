/*
* TCPClient
* Represents a connected TCPClient
*
*
* This class uses the following
* CommandManager
*
* Bryan Cairns - 2011
* All rights reserved.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
* PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <QDebug>
#include <QDir>
#include <QByteArray>
#include <QCryptographicHash>
#include <QProcess>
#include <QSettings>
#include <QFileInfo>

class TCPClient : public QObject
{
    Q_OBJECT
public:
    explicit TCPClient(int SocketDescriptor,QObject *parent = 0);

    /*!
    * Returns the socket ID
    */
    int ID();
signals:


public slots:
    /*!
    * Gets the request from the client
    */
    void SocketReadyRead();

    /*!
    * Slot for the TCP socket disconnected() signal
    */
    void SocketDisconnected();

    /*!
    * Sends the response to the client socket
    * @param data The QByteArray to send
    */
    void SendResponse(QByteArray data);

    /*!
    * Sends the response to the client socket
    * @param data The QString to send
    */
    void SendResponse(QString data);

    /*!
    * Sends the response to the client socket
    * @param data The char array to send
    */
    void SendResponse(const char* data);

    /*!
    * Slot for the QProcess ReadreadyReadStandardOutput()
    */
    void ProcessReadyRead();

    /*!
    * Closes the socket
    */
    void CloseSocket();

private:
    int SessionID;          //! The Socket ID
    QTcpSocket *Socket;     //! The TCP Socket
    QProcess *Process;      //! The Command line process
    QString CommandBuffer;  //! The buffer holding the command
    bool Authenticated;     //! Determines if the client is authenticated
    QString Banner;         //! The welcome banner and password prompt

    /*!
    * Starts the process
    */
    void StartProcess();

    /*!
    * Sends the response to the client socket
    * @param Buffer The data buffer
    */
    bool Authenticate(QString Buffer);

    /*!
    * Processes the upload
    * @param Command The data buffer
    */
    void Upload(QString Command);

    /*!
    * Processes the download
    * @param Command The data buffer
    */
    void Download(QString Command);

    /*!
    * Returns the name of the file to transfer
    * @param Filename the file the client is requesting
    */
    QString GetFilename(QString Filename);
};

#endif // TCPCLIENT_H
