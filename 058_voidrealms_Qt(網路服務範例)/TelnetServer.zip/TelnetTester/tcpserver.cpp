#include "tcpserver.h"

TCPServer::TCPServer(QObject *parent) :
    QTcpServer(parent)
{

}

void TCPServer::StartServer(qint16 port)
{

    if(!this->listen(QHostAddress::Any,port))
    {
        qDebug() << "Could not start server";
    }
    else
    {
        qDebug() << "Listening...";

        //notify connected objects
        emit OnStarted();
    }
}


void TCPServer::StopServer()
{
     this->close();
     qDebug() << "Server stopped";

     //notify connected objects
     emit OnStopped();

}

void TCPServer::incomingConnection(int socketDescriptor)
{
    qDebug() << socketDescriptor << " Connecting..." << socketDescriptor;

    //Accept the incomming client
    TCPClient *cClient = new TCPClient(socketDescriptor,this);
    connect(this,SIGNAL(OnStopped()),cClient,SLOT(CloseSocket()));
}

