#include "telnetplugin.h"

Q_EXPORT_PLUGIN2( TelnetPlugin, TelnetPlugin )

TelnetPlugin::TelnetPlugin()
{
    Server = new TCPServer();
    Settings = new QSettings();
}

QString TelnetPlugin::Name() const
{
    return "Telnet Plugin";
}

QString TelnetPlugin::Description() const
{
    return "Allows remote command line access. Also adds the UPLOAD (filename) (size) and DOWNLOAD (filename) commands";
}

QString TelnetPlugin::Status() const
{
    QString ret = "Unknown";

    if(Server->isListening())
    {
        ret = "Started";
    }
    else
    {
        ret = "Stopped";
    }

    return ret;
}

QString TelnetPlugin::Install() const
{
    return "Complete";
}

QString TelnetPlugin::Uninstall() const
{
    return "Complete";
}

QString TelnetPlugin::Start() const
{
    Settings->beginGroup(Name());
    QVariant vPort = Settings->value("port",23);
    Settings->endGroup();

    Server->StartServer(vPort.toInt());

    return Status();
}

QString TelnetPlugin::Stop() const
{
    Server->StopServer();

    return Status();
}

QStringList TelnetPlugin::Commands() const
{
    QStringList List;
    List.append("setpassword (password) - Sets the password for the telnet server.");
    List.append("setport (port) - Sets the port to run the telnet server on.");

    return List;
}

QString TelnetPlugin::Exec(QString command, QStringList args) const
{
    if(!args.count() > 1)
    {
        return "Please include the arquments to the command!";
    }

    QString ret = "Not a valid command.";
    Settings->beginGroup(Name());

    //Set the password
    if(command == "setpassword")
    {
        //Hash the password and then base64 encode it
        QByteArray hash = QCryptographicHash::hash(args.at(0).toAscii(),QCryptographicHash::Sha1);
        QString hashedpass = QString(hash.toBase64());

        //Store the password
        Settings->setValue("password", hashedpass);
        ret = "Password has been set.";
    }

    //Set the port
    if(command == "setport")
    {
        Settings->setValue("port",args.at(0));
        ret = "Port has been set, the plugin will need to be restarted.";
    }

    Settings->endGroup();

    return ret;
}


