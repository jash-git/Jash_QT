#include <QtCore/QCoreApplication>
#include "telnetplugin.h"
#include <QDebug>
#include <QFile>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QCoreApplication::setOrganizationName("VoidRealms");
    QCoreApplication::setOrganizationDomain("VoidRealms.com");
    QCoreApplication::setApplicationName("PluginService");

    TelnetPlugin cPlugin;
    qDebug() << cPlugin.Start();

    return a.exec();
}
