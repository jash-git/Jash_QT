#include <QtCore/QCoreApplication>
#include <QDebug>
#include <QByteArray>
#include <QString>
#include <QStringList>
#include "VRegistry.h"
#include "Windows.h"

using namespace voidrealms::win32;

//Write to the Registry
void Do_RegistryWrite()
{
    VRegistry mReg;

    //First step is to open the key
    mReg.OpenKey(HKEY_LOCAL_MACHINE,"Software\\Test");

    //Write a SZ value
    mReg.set_REG_SZ("test_sz", "This is a test form QT");

    //Write an Expand_SZ value
    mReg.set_REG_EXPAND_SZ("test_expand_sz", "%path%\\lol");

    //Write a DWORD value
    mReg.set_REG_DWORD("test_dword", 679928323);

    //Write a Binary value
    QByteArray mArray("Hello from QByteArray");
    mReg.set_REG_BINARY("test_binary",mArray);

    //Write a Multi_SZ value
    QStringList mList;
    mList.append("line 1");
    mList.append("line 2");
    mList.append("line 3");

    mReg.set_REG_MULTI_SZ("test_multi_sz", mList);

    //Be sure to close the key
    mReg.CloseKey();

}

//Read from the Registry
void Do_RegistryRead()
{
    VRegistry mReg;

    //First step is to open the key
    mReg.OpenKey(HKEY_LOCAL_MACHINE,"Software\\Test");

    //Read an SZ value
    qDebug() << mReg.get_REG_SZ("test_sz");

    //Read a DWORD value
    qDebug() << mReg.get_REG_DWORD("test_dword");

    //Read an Expand_SZ value
    qDebug() << mReg.get_REG_EXPAND_SZ("test_expand_sz");

    //Read a Binary value
    qDebug() << mReg.get_REG_BINARY("test_binary");

    //Read a Multi_SZ value
    QStringList mList = mReg.get_MULTI_SZ("test_multi_sz");

    for (int i = 0; i < mList.size(); ++i)
          qDebug() << "Multi Value " << i << " = " << mList.at(i);

    //Be sure to close the key
    mReg.CloseKey();
}

//Enumerate the Registry
void Do_RegistryEnumKey()
{
    VRegistry mReg;

    //First step is to open the key
    mReg.OpenKey(HKEY_LOCAL_MACHINE,"Software\\Test");

    //Get the Keys
    QStringList mKeyList = mReg.enum_Keys();
    qDebug() << "Keys: " <<  mKeyList.count();
    for (int i = 0; i < mKeyList.size(); ++i)
          qDebug() << "Key Name = " << i << " = " << mKeyList.at(i);

    //Get the values

    QStringList mValueList = mReg.enum_Values();
    qDebug() << "Values: " <<  mValueList.count();
    for (int i = 0; i < mValueList.size(); ++i)
          qDebug() << "Value Name = " << i << " = " << mValueList.at(i);

    //Be sure to close the key
    mReg.CloseKey();

}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //Write values to the Registry
    Do_RegistryWrite();

    //Enumerate keys and values in the Registry
    Do_RegistryEnumKey();

    //Reag values from the registry
    Do_RegistryRead();


    return a.exec();
}
