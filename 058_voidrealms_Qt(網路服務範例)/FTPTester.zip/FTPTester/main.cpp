#include <QtCore/QCoreApplication>
#include "ftpplugin.h"
#include "appsettings.h"
#include <QString>
#include <QDir>
#include <QDebug>
#include "ftplistitem.h"
#include "QFileInfo"
#include "ftpmlsitem.h"
#include "ftpport.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QCoreApplication::setOrganizationName("VoidRealms");
    QCoreApplication::setOrganizationDomain("VoidRealms.com");
    QCoreApplication::setApplicationName("PluginService");

    AppSettings Settings;
    Settings.beginGroup(Settings.DefaultGroup());

    Settings.setValue("anonymous",true);
    Settings.setValue("username","admin");
    Settings.setValue("password",Settings.HashPassword("password"));
    Settings.setValue("ipaddress","192.168.1.137");
    Settings.setValue("rootpath","E:/test");

    Settings.endGroup();

    FTPPlugin cPlugin;
    cPlugin.Start();

    return a.exec();
}
