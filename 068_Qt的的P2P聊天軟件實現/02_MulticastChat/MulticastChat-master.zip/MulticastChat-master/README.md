MulticastChat
=============

A UDP multicast chat application in Qt.
